﻿from __future__ import annotations

import argparse
import json
from pathlib import Path

from werewolf_agent_team.agents import UniversalAgent
from werewolf_agent_team.self_evolution import run_games, self_evolve

ROOT = Path(__file__).resolve().parent
DEFAULT_PROFILE = ROOT / "configs" / "universal_agent_profile.md"
DEFAULT_STRATEGY = ROOT / "configs" / "strategy_base.json"
DEFAULT_OUTPUT = ROOT / "outputs"


def cmd_play(args: argparse.Namespace) -> None:
    agent = UniversalAgent(args.profile, args.strategy, seed=args.seed)
    summary = run_games(agent, args.games, args.output, seed=args.seed, prefix=args.prefix)
    print(json.dumps(summary, ensure_ascii=False, indent=2))
    print(f"观战页面: {args.output / 'observer.html'}")


def cmd_evolve(args: argparse.Namespace) -> None:
    report = self_evolve(args.profile, args.strategy, args.output, args.games, seed=args.seed)
    print(json.dumps(report, ensure_ascii=False, indent=2))
    print(f"自演化报告: {args.output / 'self_evolution_report.json'}")
    print(f"Leaderboard: {args.output / 'leaderboard.json'}")
    print(f"观战页面: {args.output / 'observer.html'}")


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="AI 狼人杀多智能体协作与博弈系统")
    sub = parser.add_subparsers(dest="command", required=True)
    play = sub.add_parser("play", help="运行纯 AI 狼人杀对局并生成日志/评测/UI")
    play.add_argument("--games", type=int, default=5)
    play.add_argument("--seed", type=int, default=42)
    play.add_argument("--prefix", default="game")
    play.add_argument("--profile", type=Path, default=DEFAULT_PROFILE)
    play.add_argument("--strategy", type=Path, default=DEFAULT_STRATEGY)
    play.add_argument("--output", type=Path, default=DEFAULT_OUTPUT)
    play.set_defaults(func=cmd_play)

    evolve = sub.add_parser("evolve", help="执行进阶方向1：通用 Agent 自读、自改、自运行")
    evolve.add_argument("--games", type=int, default=8)
    evolve.add_argument("--seed", type=int, default=42)
    evolve.add_argument("--profile", type=Path, default=DEFAULT_PROFILE)
    evolve.add_argument("--strategy", type=Path, default=DEFAULT_STRATEGY)
    evolve.add_argument("--output", type=Path, default=DEFAULT_OUTPUT)
    evolve.set_defaults(func=cmd_evolve)
    return parser


def main() -> None:
    args = build_parser().parse_args()
    args.func(args)


if __name__ == "__main__":
    main()
