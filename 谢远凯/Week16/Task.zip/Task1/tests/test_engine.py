﻿import json
import tempfile
import unittest
from pathlib import Path

from werewolf_agent_team.agents import UniversalAgent
from werewolf_agent_team.engine import WerewolfGameEngine
from werewolf_agent_team.evaluation import replay_attribution

ROOT = Path(__file__).resolve().parents[1]


class WerewolfAgentTeamTests(unittest.TestCase):
    def test_game_runs_and_logs_visibility(self):
        with tempfile.TemporaryDirectory(dir=ROOT / "outputs") as tmp:
            log_path = Path(tmp) / "game.jsonl"
            agent = UniversalAgent(ROOT / "configs" / "universal_agent_profile.md", ROOT / "configs" / "strategy_base.json", seed=7)
            result = WerewolfGameEngine(agent, log_path, seed=7).run()
            self.assertIn(result["winner"], {"good", "werewolf"})
            lines = [json.loads(x) for x in log_path.read_text(encoding="utf-8").splitlines()]
            self.assertTrue(any(str(e["visibility"]).startswith("private:") for e in lines))
            self.assertTrue(any(e["visibility"] == "observer" for e in lines))

    def test_replay_attribution_scores(self):
        with tempfile.TemporaryDirectory(dir=ROOT / "outputs") as tmp:
            log_path = Path(tmp) / "game.jsonl"
            agent = UniversalAgent(ROOT / "configs" / "universal_agent_profile.md", ROOT / "configs" / "strategy_base.json", seed=9)
            WerewolfGameEngine(agent, log_path, seed=9).run()
            report = replay_attribution(log_path)
            self.assertGreater(report["total_events"], 0)
            self.assertIn("private_information_isolation", report["process_scores"])


if __name__ == "__main__":
    unittest.main()
