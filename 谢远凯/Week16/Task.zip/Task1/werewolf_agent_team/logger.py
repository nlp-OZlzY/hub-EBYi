﻿"""Structured JSONL logging with visibility metadata."""
from __future__ import annotations

import json
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Any, Dict, List, Optional


@dataclass
class Event:
    game_id: str
    turn: int
    phase: str
    event: str
    visibility: str
    actor: Optional[int]
    payload: Dict[str, Any]


class GameLogger:
    def __init__(self, path: Path):
        self.path = path
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.events: List[Event] = []
        self.path.write_text("", encoding="utf-8")

    def log(self, game_id: str, turn: int, phase: str, event: str, visibility: str = "public", actor: Optional[int] = None, **payload: Any) -> None:
        record = Event(game_id, turn, phase, event, visibility, actor, payload)
        self.events.append(record)
        with self.path.open("a", encoding="utf-8") as f:
            f.write(json.dumps(asdict(record), ensure_ascii=False) + "\n")

    @staticmethod
    def read_jsonl(path: Path) -> List[Dict[str, Any]]:
        if not path.exists():
            return []
        return [json.loads(line) for line in path.read_text(encoding="utf-8-sig").splitlines() if line.strip()]

