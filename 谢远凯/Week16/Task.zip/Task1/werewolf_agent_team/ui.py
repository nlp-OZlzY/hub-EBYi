﻿"""Static HTML observer UI generator."""
from __future__ import annotations

import html
import json
from pathlib import Path
from typing import Any, Dict, List

from .logger import GameLogger


def generate_observer_html(log_path: Path, summary: Dict[str, Any], output_path: Path) -> None:
    events = GameLogger.read_jsonl(log_path)
    embedded_events = json.dumps(events, ensure_ascii=False)
    embedded_summary = json.dumps(summary, ensure_ascii=False)
    doc = f"""<!doctype html>
<html lang=\"zh-CN\">
<head>
  <meta charset=\"utf-8\" />
  <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\" />
  <title>AI 狼人杀观战台</title>
  <style>
    body {{ margin: 0; font-family: Arial, 'Microsoft YaHei', sans-serif; background: #f6f7f9; color: #20242a; }}
    header {{ padding: 20px 28px; background: #1f2937; color: white; }}
    main {{ display: grid; grid-template-columns: 320px 1fr; gap: 18px; padding: 18px; }}
    .panel {{ background: white; border: 1px solid #d9dee7; border-radius: 8px; padding: 16px; }}
    .metric {{ display: flex; justify-content: space-between; padding: 8px 0; border-bottom: 1px solid #edf0f5; }}
    .event {{ border-left: 4px solid #6b7280; margin: 10px 0; padding: 10px 12px; background: #fff; border-radius: 6px; }}
    .night {{ border-color: #475569; }} .day {{ border-color: #d97706; }} .final {{ border-color: #059669; }}
    .private {{ opacity: .72; }}
    select, input {{ width: 100%; padding: 8px; margin: 6px 0 12px; box-sizing: border-box; }}
    code {{ background: #eef2f7; padding: 2px 5px; border-radius: 4px; }}
    @media (max-width: 860px) {{ main {{ grid-template-columns: 1fr; }} }}
  </style>
</head>
<body>
<header><h1>AI 狼人杀 Agent Team 观战台</h1><div id=\"subtitle\"></div></header>
<main>
  <section class=\"panel\">
    <h2>对局评测</h2>
    <div id=\"metrics\"></div>
    <h2>过滤</h2>
    <label>阶段</label><select id=\"phase\"><option value=\"\">全部</option><option>setup</option><option>night</option><option>day</option><option>final</option></select>
    <label>关键词</label><input id=\"q\" placeholder=\"speech / vote / player id\" />
  </section>
  <section><div id=\"events\"></div></section>
</main>
<script>
const events = {embedded_events};
const summary = {embedded_summary};
document.getElementById('subtitle').textContent = `日志: {html.escape(str(log_path))}`;
const metrics = document.getElementById('metrics');
for (const [k,v] of Object.entries(summary)) {{
  if (typeof v !== 'object') metrics.insertAdjacentHTML('beforeend', `<div class=\"metric\"><span>${{k}}</span><strong>${{v}}</strong></div>`);
}}
function render() {{
  const phase = document.getElementById('phase').value;
  const q = document.getElementById('q').value.toLowerCase();
  const root = document.getElementById('events');
  root.innerHTML = '';
  events.filter(e => (!phase || e.phase === phase) && (!q || JSON.stringify(e).toLowerCase().includes(q))).forEach(e => {{
    const payload = JSON.stringify(e.payload, null, 2);
    const klass = `${{e.phase}} ${{String(e.visibility).startsWith('private') ? 'private' : ''}}`;
    root.insertAdjacentHTML('beforeend', `<article class=\"event ${{klass}}\"><strong>#${{e.turn}} ${{e.phase}} / ${{e.event}}</strong><div>actor: <code>${{e.actor ?? 'system'}}</code> visibility: <code>${{e.visibility}}</code></div><pre>${{payload}}</pre></article>`);
  }});
}}
document.getElementById('phase').addEventListener('change', render);
document.getElementById('q').addEventListener('input', render);
render();
</script>
</body>
</html>"""
    output_path.write_text(doc, encoding="utf-8")
