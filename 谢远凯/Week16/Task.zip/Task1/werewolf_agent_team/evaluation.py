﻿"""Evaluation, replay attribution, and leaderboard utilities."""
from __future__ import annotations

import json
from collections import Counter, defaultdict
from pathlib import Path
from typing import Any, Dict, List

from .logger import GameLogger


def summarize_results(results: List[Dict[str, Any]], strategy_version: str) -> Dict[str, Any]:
    winners = Counter(r["winner"] for r in results)
    total = max(1, len(results))
    return {
        "strategy_version": strategy_version,
        "games": len(results),
        "wolf_wins": winners.get("werewolf", 0),
        "good_wins": winners.get("good", 0),
        "wolf_win_rate": round(winners.get("werewolf", 0) / total, 4),
        "good_win_rate": round(winners.get("good", 0) / total, 4),
        "avg_days": round(sum(r["days"] for r in results) / total, 3),
    }


def replay_attribution(log_path: Path) -> Dict[str, Any]:
    events = GameLogger.read_jsonl(log_path)
    public_speeches = [e for e in events if e["event"] == "speech"]
    votes = [e for e in events if e["event"] == "vote"]
    deaths = [e for e in events if e["event"] == "death"]
    final = next((e for e in reversed(events) if e["event"] == "game_over"), None)
    vote_targets = Counter(e["payload"].get("target") for e in votes)
    death_reasons = Counter(e["payload"].get("reason") for e in deaths)
    claim_counts = Counter(e["payload"].get("claim") for e in public_speeches)
    private_count = sum(1 for e in events if str(e.get("visibility", "")).startswith("private:"))
    return {
        "log_path": str(log_path),
        "winner": final["payload"]["winner"] if final else "unknown",
        "total_events": len(events),
        "private_events": private_count,
        "vote_hotspots": dict(vote_targets),
        "death_reasons": dict(death_reasons),
        "speech_claims": dict(claim_counts),
        "process_scores": {
            "observability": min(1.0, len(events) / 60),
            "private_information_isolation": 1.0 if private_count > 0 else 0.0,
            "interaction_density": round((len(public_speeches) + len(votes)) / max(1, len(deaths) + 1), 3),
        },
    }


def save_json(path: Path, data: Dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")


def update_leaderboard(path: Path, summary: Dict[str, Any]) -> List[Dict[str, Any]]:
    rows: List[Dict[str, Any]] = []
    if path.exists():
        rows = json.loads(path.read_text(encoding="utf-8"))
    rows = [r for r in rows if r.get("strategy_version") != summary.get("strategy_version")]
    score = summary["good_win_rate"] * 0.5 + summary["wolf_win_rate"] * 0.5
    row = dict(summary)
    row["balanced_score"] = round(score, 4)
    rows.append(row)
    rows.sort(key=lambda r: (r["balanced_score"], r.get("games", 0)), reverse=True)
    path.write_text(json.dumps(rows, ensure_ascii=False, indent=2), encoding="utf-8")
    return rows
