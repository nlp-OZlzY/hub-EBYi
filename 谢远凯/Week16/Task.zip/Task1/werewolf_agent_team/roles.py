﻿"""Role constants for the Werewolf Agent Team project."""
from enum import Enum


class Camp(str, Enum):
    WEREWOLF = "werewolf"
    GOOD = "good"


class Role(str, Enum):
    WEREWOLF = "werewolf"
    SEER = "seer"
    WITCH = "witch"
    HUNTER = "hunter"
    VILLAGER = "villager"


ROLE_CAMP = {
    Role.WEREWOLF: Camp.WEREWOLF,
    Role.SEER: Camp.GOOD,
    Role.WITCH: Camp.GOOD,
    Role.HUNTER: Camp.GOOD,
    Role.VILLAGER: Camp.GOOD,
}

DEFAULT_ROLE_DECK = [
    Role.WEREWOLF,
    Role.WEREWOLF,
    Role.SEER,
    Role.WITCH,
    Role.HUNTER,
    Role.VILLAGER,
    Role.VILLAGER,
    Role.VILLAGER,
]
