﻿"""Agents with strict observation boundaries.

UniversalAgent is the advanced-direction-1 component: it reads its own profile and
strategy file, materializes role-specific agents, can update the strategy from
replay metrics, and then runs itself through the engine.
"""
from __future__ import annotations

import json
import random
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional

from .roles import ROLE_CAMP, Camp, Role


@dataclass
class PlayerView:
    player_id: int
    role: Role
    alive: bool = True


@dataclass
class Observation:
    self_id: int
    self_role: Role
    alive_players: List[int]
    public_events: List[Dict[str, Any]]
    private_events: List[Dict[str, Any]]
    known_wolves: List[int] = field(default_factory=list)


class RoleAgent:
    def __init__(self, player_id: int, role: Role, strategy: Dict[str, Any], seed: int):
        self.player_id = player_id
        self.role = role
        self.strategy = strategy
        self.rng = random.Random(seed + player_id * 997)
        self.suspicion: Dict[int, float] = {}
        self.checked: Dict[int, str] = {}

    def observe(self, obs: Observation) -> None:
        for pid in obs.alive_players:
            if pid != self.player_id:
                self.suspicion.setdefault(pid, 0.0)
        for event in obs.private_events:
            if event.get("event") == "seer_result" and event.get("actor") == self.player_id:
                target = event["payload"]["target"]
                camp = event["payload"]["camp"]
                self.checked[target] = camp
                self.suspicion[target] = 1.0 if camp == Camp.WEREWOLF.value else -0.6
        for event in obs.public_events:
            name = event.get("event")
            payload = event.get("payload", {})
            if name == "speech":
                speaker = event.get("actor")
                claim = payload.get("claim")
                target = payload.get("target")
                if speaker != self.player_id and claim == "seer_found_wolf" and target is not None:
                    self.suspicion[target] = self.suspicion.get(target, 0.0) + 0.45
                    self.suspicion[speaker] = self.suspicion.get(speaker, 0.0) - 0.05
            if name == "vote":
                voter = event.get("actor")
                target = payload.get("target")
                if voter != self.player_id and target is not None:
                    self.suspicion[target] = self.suspicion.get(target, 0.0) + 0.04

    def _pick(self, candidates: Iterable[int]) -> Optional[int]:
        pool = list(candidates)
        return self.rng.choice(pool) if pool else None

    def _most_suspicious(self, candidates: Iterable[int]) -> Optional[int]:
        pool = list(candidates)
        if not pool:
            return None
        return max(pool, key=lambda pid: (self.suspicion.get(pid, 0.0), self.rng.random()))

    def _least_suspicious(self, candidates: Iterable[int]) -> Optional[int]:
        pool = list(candidates)
        if not pool:
            return None
        return min(pool, key=lambda pid: (self.suspicion.get(pid, 0.0), self.rng.random()))

    def wolf_kill(self, obs: Observation) -> Optional[int]:
        candidates = [p for p in obs.alive_players if p not in obs.known_wolves]
        if not candidates:
            return None
        if self.rng.random() < self.strategy.get("wolf_focus_suspected_power", 0.35):
            return self._least_suspicious(candidates)
        return self._pick(candidates)

    def seer_check(self, obs: Observation) -> Optional[int]:
        unchecked = [p for p in obs.alive_players if p != self.player_id and p not in self.checked]
        return self._most_suspicious(unchecked) or self._pick(unchecked)

    def witch_action(self, obs: Observation, killed: Optional[int], has_antidote: bool, has_poison: bool) -> Dict[str, Optional[int]]:
        save = None
        poison = None
        if has_antidote and killed is not None:
            save_self_bias = self.strategy.get("witch_save_self_bias", 0.85)
            save_other_bias = self.strategy.get("witch_save_other_bias", 0.35)
            if killed == self.player_id and self.rng.random() < save_self_bias:
                save = killed
            elif killed != self.player_id and self.rng.random() < save_other_bias:
                save = killed
        if has_poison and self.rng.random() < self.strategy.get("witch_poison_aggression", 0.28):
            candidates = [p for p in obs.alive_players if p != self.player_id and p != save]
            target = self._most_suspicious(candidates)
            if target is not None and self.suspicion.get(target, 0.0) > self.strategy.get("poison_threshold", 0.55):
                poison = target
        return {"save": save, "poison": poison}

    def speak(self, obs: Observation, day: int) -> Dict[str, Any]:
        if self.role == Role.SEER:
            wolves = [pid for pid, camp in self.checked.items() if camp == Camp.WEREWOLF.value and pid in obs.alive_players]
            if wolves and self.rng.random() < self.strategy.get("seer_reveal_guilty", 0.85):
                return {"claim": "seer_found_wolf", "target": wolves[0], "text": f"我验到 {wolves[0]} 是狼人，今天优先出他。"}
            goods = [pid for pid, camp in self.checked.items() if camp == Camp.GOOD.value and pid in obs.alive_players]
            if goods and day >= 2:
                return {"claim": "seer_found_good", "target": goods[0], "text": f"我倾向相信 {goods[0]} 是好人。"}
        if self.role == Role.WEREWOLF and self.rng.random() < self.strategy.get("wolf_fake_seer_rate", 0.16):
            target = self._pick([p for p in obs.alive_players if p != self.player_id and p not in obs.known_wolves])
            return {"claim": "seer_found_wolf", "target": target, "text": f"我跳预言家，{target} 查杀。"}
        target = self._most_suspicious([p for p in obs.alive_players if p != self.player_id])
        return {"claim": "suspect", "target": target, "text": f"我目前最怀疑 {target}，发言和票型需要重点看。"}

    def vote(self, obs: Observation) -> Optional[int]:
        candidates = [p for p in obs.alive_players if p != self.player_id]
        if self.role == Role.WEREWOLF:
            candidates = [p for p in candidates if p not in obs.known_wolves]
        guilty = [pid for pid, camp in self.checked.items() if camp == Camp.WEREWOLF.value and pid in candidates]
        if guilty:
            return guilty[0]
        if self.rng.random() < self.strategy.get("vote_randomness", 0.12):
            return self._pick(candidates)
        return self._most_suspicious(candidates)


class UniversalAgent:
    def __init__(self, profile_path: Path, strategy_path: Path, seed: int = 0):
        self.profile_path = profile_path
        self.strategy_path = strategy_path
        self.seed = seed
        self.profile = self.read_self()
        self.strategy = self.read_strategy()

    def read_self(self) -> str:
        return self.profile_path.read_text(encoding="utf-8-sig")

    def read_strategy(self) -> Dict[str, Any]:
        return json.loads(self.strategy_path.read_text(encoding="utf-8-sig"))

    def build_role_agent(self, player_id: int, role: Role) -> RoleAgent:
        merged = dict(self.strategy.get("global", {}))
        merged.update(self.strategy.get("roles", {}).get(role.value, {}))
        return RoleAgent(player_id, role, merged, self.seed)

    def modify_self_from_metrics(self, metrics: Dict[str, Any], output_path: Path) -> Dict[str, Any]:
        new_strategy = json.loads(json.dumps(self.strategy, ensure_ascii=False))
        roles = new_strategy.setdefault("roles", {})
        wolf_win_rate = metrics.get("wolf_win_rate", 0.5)
        good_win_rate = metrics.get("good_win_rate", 0.5)
        wolf = roles.setdefault("werewolf", {})
        seer = roles.setdefault("seer", {})
        witch = roles.setdefault("witch", {})
        if wolf_win_rate < 0.45:
            wolf["wolf_fake_seer_rate"] = min(0.45, wolf.get("wolf_fake_seer_rate", 0.16) + 0.04)
            wolf["wolf_focus_suspected_power"] = min(0.7, wolf.get("wolf_focus_suspected_power", 0.35) + 0.05)
        if good_win_rate < 0.45:
            seer["seer_reveal_guilty"] = min(0.95, seer.get("seer_reveal_guilty", 0.85) + 0.03)
            witch["witch_poison_aggression"] = min(0.55, witch.get("witch_poison_aggression", 0.28) + 0.04)
        new_strategy["version"] = f"{new_strategy.get('version', 'v1')}-evolved"
        output_path.write_text(json.dumps(new_strategy, ensure_ascii=False, indent=2), encoding="utf-8")
        return new_strategy


def camp_of(role: Role) -> Camp:
    return ROLE_CAMP[role]

