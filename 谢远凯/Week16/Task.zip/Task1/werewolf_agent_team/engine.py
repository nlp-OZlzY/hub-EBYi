﻿"""Game engine that drives hidden-information Werewolf matches."""
from __future__ import annotations

import random
import uuid
from collections import Counter
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, List, Optional

from .agents import Observation, RoleAgent, UniversalAgent, camp_of
from .logger import GameLogger
from .roles import Camp, DEFAULT_ROLE_DECK, Role


@dataclass
class PlayerState:
    player_id: int
    role: Role
    alive: bool = True


class WerewolfGameEngine:
    def __init__(self, universal_agent: UniversalAgent, log_path: Path, seed: int = 0, max_days: int = 6):
        self.ua = universal_agent
        self.seed = seed
        self.rng = random.Random(seed)
        self.max_days = max_days
        self.game_id = str(uuid.uuid4())[:8]
        self.logger = GameLogger(log_path)
        roles = list(DEFAULT_ROLE_DECK)
        self.rng.shuffle(roles)
        self.players = [PlayerState(i, role) for i, role in enumerate(roles)]
        self.agents: Dict[int, RoleAgent] = {p.player_id: self.ua.build_role_agent(p.player_id, p.role) for p in self.players}
        self.has_antidote = True
        self.has_poison = True
        self.public_events: List[Dict[str, Any]] = []
        self.private_events: Dict[int, List[Dict[str, Any]]] = {p.player_id: [] for p in self.players}

    def alive_players(self) -> List[int]:
        return [p.player_id for p in self.players if p.alive]

    def get_player(self, pid: int) -> PlayerState:
        return self.players[pid]

    def wolves(self) -> List[int]:
        return [p.player_id for p in self.players if p.alive and p.role == Role.WEREWOLF]

    def _event_dict(self, turn: int, phase: str, event: str, actor: Optional[int], payload: Dict[str, Any]) -> Dict[str, Any]:
        return {"game_id": self.game_id, "turn": turn, "phase": phase, "event": event, "actor": actor, "payload": payload}

    def log_public(self, turn: int, phase: str, event: str, actor: Optional[int] = None, **payload: Any) -> None:
        self.logger.log(self.game_id, turn, phase, event, "public", actor, **payload)
        self.public_events.append(self._event_dict(turn, phase, event, actor, payload))

    def log_private(self, pid: int, turn: int, phase: str, event: str, actor: Optional[int] = None, **payload: Any) -> None:
        self.logger.log(self.game_id, turn, phase, event, f"private:{pid}", actor, **payload)
        self.private_events[pid].append(self._event_dict(turn, phase, event, actor, payload))

    def observe(self, pid: int) -> Observation:
        player = self.get_player(pid)
        known_wolves = self.wolves() if player.role == Role.WEREWOLF else []
        return Observation(
            self_id=pid,
            self_role=player.role,
            alive_players=self.alive_players(),
            public_events=list(self.public_events),
            private_events=list(self.private_events[pid]),
            known_wolves=known_wolves,
        )

    def broadcast_observations(self) -> None:
        for pid in self.alive_players():
            self.agents[pid].observe(self.observe(pid))

    def check_win(self) -> Optional[Camp]:
        alive = [p for p in self.players if p.alive]
        wolves = [p for p in alive if p.role == Role.WEREWOLF]
        goods = [p for p in alive if p.role != Role.WEREWOLF]
        if not wolves:
            return Camp.GOOD
        if len(wolves) >= len(goods):
            return Camp.WEREWOLF
        return None

    def kill(self, pid: Optional[int], reason: str, turn: int, phase: str) -> None:
        if pid is None:
            return
        player = self.get_player(pid)
        if player.alive:
            player.alive = False
            self.log_public(turn, phase, "death", None, target=pid, role=player.role.value, reason=reason)

    def run(self) -> Dict[str, Any]:
        setup = {p.player_id: p.role.value for p in self.players}
        self.logger.log(self.game_id, 0, "setup", "role_assignment_full", "observer", None, roles=setup)
        self.log_public(0, "setup", "game_start", None, players=list(setup.keys()), strategy_version=self.ua.strategy.get("version"))
        winner = self.check_win()
        day = 0
        while winner is None and day < self.max_days:
            day += 1
            self.night(day)
            winner = self.check_win()
            if winner is not None:
                break
            self.day(day)
            winner = self.check_win()
        if winner is None:
            winner = Camp.GOOD
            self.log_public(day, "final", "max_day_reached", None, rule="超过最大天数，好人按防守成功获胜")
        self.log_public(day, "final", "game_over", None, winner=winner.value, alive=self.alive_players())
        return {"game_id": self.game_id, "winner": winner.value, "days": day, "roles": setup, "log_path": str(self.logger.path)}

    def night(self, day: int) -> None:
        self.broadcast_observations()
        wolf_votes: List[int] = []
        for wid in self.wolves():
            target = self.agents[wid].wolf_kill(self.observe(wid))
            if target is not None:
                wolf_votes.append(target)
                self.log_private(wid, day, "night", "wolf_vote", wid, target=target)
        killed = None
        if wolf_votes:
            counts = Counter(wolf_votes)
            killed = max(counts, key=lambda pid: (counts[pid], self.rng.random()))
            self.logger.log(self.game_id, day, "night", "wolf_consensus", "observer", None, target=killed, votes=dict(counts))
        for p in self.players:
            if p.alive and p.role == Role.SEER:
                target = self.agents[p.player_id].seer_check(self.observe(p.player_id))
                if target is not None:
                    camp = camp_of(self.get_player(target).role).value
                    self.log_private(p.player_id, day, "night", "seer_result", p.player_id, target=target, camp=camp)
        witch = next((p for p in self.players if p.alive and p.role == Role.WITCH), None)
        saved = None
        poisoned = None
        if witch:
            action = self.agents[witch.player_id].witch_action(self.observe(witch.player_id), killed, self.has_antidote, self.has_poison)
            saved = action.get("save")
            poisoned = action.get("poison")
            if saved is not None and self.has_antidote:
                self.has_antidote = False
                self.log_private(witch.player_id, day, "night", "witch_save", witch.player_id, target=saved)
            if poisoned is not None and self.has_poison:
                self.has_poison = False
                self.log_private(witch.player_id, day, "night", "witch_poison", witch.player_id, target=poisoned)
        if killed is not None and killed != saved:
            self.kill(killed, "wolf_kill", day, "night")
        else:
            self.log_public(day, "night", "peaceful_night", None, saved=saved)
        self.kill(poisoned, "witch_poison", day, "night")

    def day(self, day: int) -> None:
        self.broadcast_observations()
        order = self.alive_players()
        self.rng.shuffle(order)
        for pid in order:
            speech = self.agents[pid].speak(self.observe(pid), day)
            self.log_public(day, "day", "speech", pid, **speech)
        self.broadcast_observations()
        votes: Dict[int, int] = {}
        for pid in self.alive_players():
            target = self.agents[pid].vote(self.observe(pid))
            if target is not None:
                votes[pid] = target
                self.log_public(day, "day", "vote", pid, target=target)
        if not votes:
            self.log_public(day, "day", "no_execution", None)
            return
        counts = Counter(votes.values())
        executed = max(counts, key=lambda pid: (counts[pid], self.rng.random()))
        self.log_public(day, "day", "vote_result", None, target=executed, tally=dict(counts))
        was_hunter = self.get_player(executed).role == Role.HUNTER
        self.kill(executed, "day_vote", day, "day")
        if was_hunter:
            candidates = [p for p in self.alive_players() if p != executed]
            shot = self.agents[executed]._most_suspicious(candidates)
            if shot is not None:
                self.log_public(day, "day", "hunter_shot", executed, target=shot)
                self.kill(shot, "hunter_shot", day, "day")
