﻿"""Self-evolution loop: play -> evaluate -> modify strategy -> replay."""
from __future__ import annotations

from pathlib import Path
from typing import Any, Dict, List

from .agents import UniversalAgent
from .engine import WerewolfGameEngine
from .evaluation import replay_attribution, save_json, summarize_results, update_leaderboard
from .ui import generate_observer_html


def run_games(agent: UniversalAgent, games: int, output_dir: Path, seed: int = 0, prefix: str = "game") -> Dict[str, Any]:
    output_dir.mkdir(parents=True, exist_ok=True)
    results: List[Dict[str, Any]] = []
    attributions: List[Dict[str, Any]] = []
    for i in range(games):
        log_path = output_dir / f"{prefix}_{i + 1:03d}.jsonl"
        engine = WerewolfGameEngine(agent, log_path, seed=seed + i)
        result = engine.run()
        results.append(result)
        attributions.append(replay_attribution(log_path))
    summary = summarize_results(results, agent.strategy.get("version", "unknown"))
    summary["sample_logs"] = [r["log_path"] for r in results[:5]]
    summary["attribution_samples"] = attributions[:3]
    save_json(output_dir / f"{prefix}_summary.json", summary)
    update_leaderboard(output_dir / "leaderboard.json", summary)
    if results:
        generate_observer_html(Path(results[-1]["log_path"]), summary, output_dir / "observer.html")
    return summary


def self_evolve(profile_path: Path, strategy_path: Path, output_dir: Path, games: int, seed: int = 0) -> Dict[str, Any]:
    base_agent = UniversalAgent(profile_path, strategy_path, seed=seed)
    base_summary = run_games(base_agent, games, output_dir, seed=seed, prefix="base")
    evolved_path = output_dir / "strategy_evolved.json"
    evolved_strategy = base_agent.modify_self_from_metrics(base_summary, evolved_path)
    evolved_agent = UniversalAgent(profile_path, evolved_path, seed=seed + 10_000)
    evolved_summary = run_games(evolved_agent, games, output_dir, seed=seed + 10_000, prefix="evolved")
    report = {
        "advanced_direction": "1 通用 Agent：读懂自己 -> 修改自己 -> 运行自己",
        "self_profile": str(profile_path),
        "base_strategy": str(strategy_path),
        "evolved_strategy": str(evolved_path),
        "base_summary": base_summary,
        "evolved_summary": evolved_summary,
        "changed_strategy": evolved_strategy,
    }
    save_json(output_dir / "self_evolution_report.json", report)
    return report
