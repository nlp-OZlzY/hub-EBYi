﻿# 第十六周作业：AI 狼人杀 Agent Team

本项目从 0 实现了一个纯 Python 标准库的狼人杀多智能体系统，并完成进阶方向 1：通用 Agent 的“读懂自己 -> 修改自己 -> 运行自己”。

## 运行方式

在本目录执行：

```powershell
python main.py play --games 5 --seed 42
python main.py evolve --games 8 --seed 42
```

输出文件会生成在 `outputs/`：

- `*.jsonl`：结构化全程对局日志，含公开/私有/观察者可见性。
- `*_summary.json`：胜率、平均天数、过程评测样例。
- `self_evolution_report.json`：进阶方向 1 报告，展示策略自修改前后结果。
- `strategy_evolved.json`：自演化后的策略文件。
- `leaderboard.json`：不同策略版本同台评测排行。
- `observer.html`：静态前端观战 UI，可直接用浏览器打开。

## 功能对应

- 多 Agent：`werewolf_agent_team/agents.py` 中的 `UniversalAgent` 与 `RoleAgent`。
- 信息隔离：`Observation` 只给 Agent 暴露公开事件和自己的私有事件；狼人才知道狼队友。
- 对局引擎：`werewolf_agent_team/engine.py` 驱动夜晚、白天、发言、投票、死亡、胜负裁决。
- 结构化日志：`werewolf_agent_team/logger.py` 输出 JSONL，并记录 visibility 字段。
- 评测复盘：`werewolf_agent_team/evaluation.py` 统计胜率、过程指标、投票热点、死亡原因。
- 观战 UI：`werewolf_agent_team/ui.py` 生成 `outputs/observer.html`。
- 进阶方向 1：`werewolf_agent_team/self_evolution.py` 完成“对局评测 -> 策略自修改 -> 再运行”。

## 设计说明

项目没有依赖外部大模型 API，原因是课程重点是 Agent Team 协作/对抗机制。这里将推理策略抽象成可解释参数，让每个角色在自己的局部观察下独立决策；这样可以稳定复现、评测和复盘，也便于后续替换为真实 LLM Agent。
