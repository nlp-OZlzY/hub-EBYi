"""全局配置"""
import os

LLM_BASE_URL = os.getenv("LLM_BASE_URL", "https://ark.cn-beijing.volces.com/api/coding/v3")
LLM_API_KEY = os.getenv("LLM_API_KEY", "543f6016-f61f-4f8a-a4e8-8513e2edb20f")
LLM_MODEL = os.getenv("LLM_MODEL", "GLM-5.1")

# 角色配置
ROLE_WEREWOLF = "werewolf"
ROLE_SEER = "seer"
ROLE_WITCH = "witch"
ROLE_HUNTER = "hunter"
ROLE_VILLAGER = "villager"

CAMP_WOLF = "wolf"
CAMP_GOD = "god"
CAMP_VILLAGER = "villager"

# 9人标准局：3狼 + 预言家 + 女巫 + 猎人 + 3平民
ROLE_DISTRIBUTION = [
    ROLE_WEREWOLF, ROLE_WEREWOLF, ROLE_WEREWOLF,
    ROLE_SEER,
    ROLE_WITCH,
    ROLE_HUNTER,
    ROLE_VILLAGER, ROLE_VILLAGER, ROLE_VILLAGER,
]

ROLE_NAMES = {
    ROLE_WEREWOLF: "狼人",
    ROLE_SEER: "预言家",
    ROLE_WITCH: "女巫",
    ROLE_HUNTER: "猎人",
    ROLE_VILLAGER: "平民",
}

ROLE_CAMP = {
    ROLE_WEREWOLF: CAMP_WOLF,
    ROLE_SEER: CAMP_GOD,
    ROLE_WITCH: CAMP_GOD,
    ROLE_HUNTER: CAMP_GOD,
    ROLE_VILLAGER: CAMP_VILLAGER,
}
