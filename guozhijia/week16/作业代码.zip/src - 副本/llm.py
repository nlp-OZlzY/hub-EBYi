"""LLM 客户端封装 — OpenAI 兼容接口"""
from openai import OpenAI
from config import LLM_BASE_URL, LLM_API_KEY, LLM_MODEL

_client = OpenAI(base_url=LLM_BASE_URL, api_key=LLM_API_KEY)


def chat(system_prompt: str, user_prompt: str, temperature: float = 0.7) -> str:
    """调用 LLM，返回文本回复"""
    resp = _client.chat.completions.create(
        model=LLM_MODEL,
        messages=[
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_prompt},
        ],
        temperature=temperature,
        max_tokens=512,
    )
    return resp.choices[0].message.content.strip()
