"""Agent 基类 — 每个玩家一个实例，私有记忆 + 决策"""
import json
from llm import chat
from config import (
    ROLE_WEREWOLF, ROLE_SEER, ROLE_WITCH, ROLE_HUNTER, ROLE_VILLAGER,
    ROLE_NAMES, ROLE_CAMP,
)
from roles import (
    SYSTEM_WEREWOLF, SYSTEM_SEER, SYSTEM_WITCH, SYSTEM_HUNTER, SYSTEM_VILLAGER,
    PROMPT_WOLF_KILL, PROMPT_SEER_CHECK, PROMPT_WITCH_SAVE,
    PROMPT_SPEAK, PROMPT_VOTE, PROMPT_HUNTER_SHOOT, PROMPT_WITCH_POISON_ONLY,
)


class Agent:
    def __init__(self, seat: int, role: str):
        self.seat = seat
        self.role = role
        self.role_name = ROLE_NAMES[role]
        self.camp = ROLE_CAMP[role]
        self.alive = True
        self.private_memory: list[dict] = []  # 私有记忆
        self._system_prompt = self._build_system_prompt()

    def _build_system_prompt(self) -> str:
        if self.role == ROLE_WEREWOLF:
            # teammates 在游戏开始后由 engine 注入
            return SYSTEM_WEREWOLF
        elif self.role == ROLE_SEER:
            return SYSTEM_SEER
        elif self.role == ROLE_WITCH:
            return SYSTEM_WITCH
        elif self.role == ROLE_HUNTER:
            return SYSTEM_HUNTER
        else:
            return SYSTEM_VILLAGER

    def _remember(self, phase: str, info: str):
        self.private_memory.append({"phase": phase, "info": info})

    def _private_info_str(self) -> str:
        if not self.private_memory:
            return "暂无"
        return "\n".join(f"[{m['phase']}] {m['info']}" for m in self.private_memory)

    def _ask_llm(self, user_prompt: str, temperature: float = 0.7) -> str:
        return chat(self._system_prompt, user_prompt, temperature)

    # ── 各阶段决策方法 ──

    def wolf_kill(self, alive_players: list[int], teammates: list[int]) -> tuple[int, str]:
        prompt = PROMPT_WOLF_KILL.format(
            alive_players=self._fmt_players(alive_players),
            teammates=self._fmt_players(teammates),
        )
        resp = self._ask_llm(prompt)
        target = self._extract_number(resp, alive_players)
        self._remember("狼人杀人", f"选择击杀{target}号，理由：{resp}")
        return target, resp

    def seer_check(self, alive_players: list[int], check_history: str) -> tuple[int, str]:
        prompt = PROMPT_SEER_CHECK.format(
            alive_players=self._fmt_players([p for p in alive_players if p != self.seat]),
            check_history=check_history or "暂无",
        )
        resp = self._ask_llm(prompt)
        target = self._extract_number(resp, [p for p in alive_players if p != self.seat])
        self._remember("预言家查验", f"查验{target}号，LLM回复：{resp}")
        return target, resp

    def witch_decide(self, killed_seat: int, alive_players: list[int],
                     has_antidote: bool, has_poison: bool) -> tuple[bool, int | None, str]:
        """返回 (是否救人, 毒杀目标或None, LLM原始回复)"""
        if has_antidote:
            prompt = PROMPT_WITCH_SAVE.format(
                killed_seat=killed_seat,
                alive_players=self._fmt_players(alive_players),
                saved=not has_antidote,
                poisoned=not has_poison,
            )
        else:
            prompt = PROMPT_WITCH_POISON_ONLY.format(
                killed_seat=killed_seat,
                alive_players=self._fmt_players(alive_players),
                poisoned=not has_poison,
            )
        resp = self._ask_llm(prompt)
        # 解析
        save = False
        poison_target = None
        if "解药" in resp and ("是" in resp.split("解药")[1][:5] if "解药" in resp else False):
            save = True
        if "毒药" in resp:
            poison_part = resp.split("毒药")[-1][:20]
            for p in alive_players:
                if str(p) in poison_part:
                    poison_target = p
                    break
        self._remember("女巫决策", f"被杀{killed_seat}号，救人={save}，毒人={poison_target}，回复：{resp}")
        return save, poison_target, resp

    def speak(self, day: int, dead_players: list[int], speech_summary: str) -> str:
        prompt = PROMPT_SPEAK.format(
            day=day,
            dead_players=self._fmt_players(dead_players) if dead_players else "无",
            private_info=self._private_info_str(),
            speech_summary=speech_summary or "暂无发言",
        )
        resp = self._ask_llm(prompt, temperature=0.8)
        self._remember(f"第{day}天发言", resp)
        return resp

    def vote(self, day: int, alive_voters: list[int], suspects: list[int]) -> tuple[int, str]:
        prompt = PROMPT_VOTE.format(
            day=day,
            alive_voters=self._fmt_players(alive_voters),
            suspects=self._fmt_players(suspects),
            private_info=self._private_info_str(),
        )
        resp = self._ask_llm(prompt)
        target = self._extract_number(resp, suspects)
        self._remember(f"第{day}天投票", f"投{target}号，理由：{resp}")
        return target, resp

    def hunter_shoot(self, alive_players: list[int]) -> tuple[int, str]:
        prompt = PROMPT_HUNTER_SHOOT.format(
            alive_players=self._fmt_players(alive_players),
            private_info=self._private_info_str(),
        )
        resp = self._ask_llm(prompt)
        target = self._extract_number(resp, alive_players + [0])
        self._remember("猎人开枪", f"射击{target}号，回复：{resp}")
        return target, resp

    # ── 工具方法 ──

    @staticmethod
    def _fmt_players(players: list[int]) -> str:
        return "、".join(f"{p}号" for p in players)

    @staticmethod
    def _extract_number(text: str, candidates: list[int]) -> int:
        """从 LLM 回复中提取一个候选编号"""
        # 优先找明确的"X号"
        import re
        matches = re.findall(r'(\d+)号?', text)
        for m in matches:
            n = int(m)
            if n in candidates:
                return n
        # 兜底：找文本中任意候选数字
        for m in re.findall(r'\d+', text):
            n = int(m)
            if n in candidates:
                return n
        # 最终兜底：随机选一个
        import random
        return random.choice(candidates) if candidates else 0

    def __repr__(self):
        status = "存活" if self.alive else "死亡"
        return f"<{self.seat}号 {self.role_name} [{status}]>"
