"""结构化日志 — 每局输出一个 JSON 文件"""
import json
import os
from datetime import datetime


class GameLogger:
    def __init__(self, log_dir: str = "logs"):
        self.log_dir = log_dir
        os.makedirs(log_dir, exist_ok=True)
        self.entries: list[dict] = []
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        self.filepath = os.path.join(log_dir, f"game_{timestamp}.json")

    def __call__(self, entry: dict):
        self.entries.append(entry)
        # 追加写入
        with open(self.filepath, "w", encoding="utf-8") as f:
            json.dump(self.entries, f, ensure_ascii=False, indent=2)

    def save(self):
        with open(self.filepath, "w", encoding="utf-8") as f:
            json.dump(self.entries, f, ensure_ascii=False, indent=2)
        return self.filepath
