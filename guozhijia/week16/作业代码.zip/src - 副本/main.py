"""入口 — 运行一局 AI 狼人杀"""
import sys
import os

# 确保 src 目录在 import 路径中
sys.path.insert(0, os.path.dirname(__file__))

from game import GameEngine
from logger import GameLogger


def main():
    logger = GameLogger(log_dir=os.path.join(os.path.dirname(__file__), "..", "logs"))
    engine = GameEngine(log_callback=logger)
    winner = engine.run()

    path = logger.save()
    print(f"\n📄 对局日志已保存：{path}")
    return winner


if __name__ == "__main__":
    main()
