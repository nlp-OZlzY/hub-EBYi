"""对局引擎 — 驱动回合流转与胜负裁决"""
import random
import time
from agent import Agent
from config import (
    ROLE_DISTRIBUTION, ROLE_WEREWOLF, ROLE_SEER, ROLE_WITCH,
    ROLE_HUNTER, ROLE_NAMES, ROLE_CAMP,
)


class GameEngine:
    def __init__(self, log_callback=None):
        self.agents: list[Agent] = []
        self.day = 0
        self.log_callback = log_callback or (lambda _: None)
        self.log: list[dict] = []
        self.winner = None
        # 女巫药水状态
        self.witch_has_antidote = True
        self.witch_has_poison = True
        self.witch_poisoned_this_night = False  # 标记女巫是否当晚用了毒（猎人能否开枪）

    def _emit(self, event: str, data: dict):
        entry = {"day": self.day, "event": event, **data}
        self.log.append(entry)
        self.log_callback(entry)

    def _alive_agents(self) -> list[Agent]:
        return [a for a in self.agents if a.alive]

    def _alive_by_role(self, role: str) -> list[Agent]:
        return [a for a in self._alive_agents() if a.role == role]

    def _alive_seats(self) -> list[int]:
        return [a.seat for a in self._alive_agents()]

    def _agent_by_seat(self, seat: int) -> Agent | None:
        for a in self.agents:
            if a.seat == seat:
                return a
        return None

    def _kill(self, seat: int, cause: str):
        agent = self._agent_by_seat(seat)
        if agent and agent.alive:
            agent.alive = False
            self._emit("death", {"seat": seat, "role": agent.role, "cause": cause})
            print(f"  ☠ {seat}号玩家（{agent.role_name}）{cause}")

    def setup(self):
        """初始化：随机分配角色"""
        seats = list(range(1, 10))
        roles = ROLE_DISTRIBUTION[:]
        random.shuffle(roles)
        for seat, role in zip(seats, roles):
            self.agents.append(Agent(seat, role))
        # 给狼人注入队友信息
        wolves = [a for a in self.agents if a.role == ROLE_WEREWOLF]
        wolf_seats = [w.seat for w in wolves]
        for w in wolves:
            teammates = [s for s in wolf_seats if s != w.seat]
            w._system_prompt = w._system_prompt.format(teammates="、".join(f"{s}号" for s in teammates))
        # 打印初始信息
        print("\n=== 角色分配 ===")
        for a in self.agents:
            print(f"  {a.seat}号：{a.role_name}（{a.camp}方）")
        self._emit("setup", {
            "roles": {a.seat: a.role for a in self.agents}
        })

    def check_win(self) -> str | None:
        """检查胜负，返回获胜阵营或 None"""
        alive = self._alive_agents()
        wolves = [a for a in alive if a.role == ROLE_WEREWOLF]
        goods = [a for a in alive if a.role != ROLE_WEREWOLF]
        if not wolves:
            self.winner = "好人"
            return "好人"
        # 狼人杀光所有神职或所有平民即获胜（简化：好人≤狼人数量时狼人胜）
        gods = [a for a in alive if a.camp == "god"]
        villagers = [a for a in alive if a.camp == "villager"]
        if not gods or not villagers:
            self.winner = "狼人"
            return "狼人"
        if len(wolves) >= len(goods):
            self.winner = "狼人"
            return "狼人"
        return None

    def night_phase(self):
        """夜晚阶段"""
        self.day += 1
        self.witch_poisoned_this_night = False
        print(f"\n{'='*40}")
        print(f"  🌙 第{self.day}天 · 夜晚")
        print(f"{'='*40}")
        self._emit("night_start", {"day": self.day})

        killed_seat = None

        # 1. 狼人杀人
        wolves = self._alive_by_role(ROLE_WEREWOLF)
        if wolves:
            wolf = wolves[0]  # 第一个狼人代表发言选择
            wolf_seats = [w.seat for w in wolves]
            alive_targets = [s for s in self._alive_seats() if s not in wolf_seats]
            if alive_targets:
                target, reason = wolf.wolf_kill(alive_targets, wolf_seats)
                killed_seat = target
                self._emit("wolf_kill", {"killer": wolf.seat, "target": target, "reason": reason})
                print(f"  🐺 狼人选择击杀 {target}号")

        # 2. 预言家查验
        seers = self._alive_by_role(ROLE_SEER)
        if seers:
            seer = seers[0]
            check_history = "\n".join(
                f"查验{m['info']}" for m in seer.private_memory if m["phase"] == "预言家查验"
            ) or "暂无"
            target, reason = seer.seer_check(self._alive_seats(), check_history)
            target_agent = self._agent_by_seat(target)
            is_wolf = target_agent.role == ROLE_WEREWOLF if target_agent else False
            result = "狼人" if is_wolf else "好人"
            seer._remember("预言家查验结果", f"{target}号是{result}")
            self._emit("seer_check", {"seer": seer.seat, "target": target, "result": result})
            print(f"  🔮 预言家查验 {target}号 → {result}")

        # 3. 女巫决策
        witches = self._alive_by_role(ROLE_WITCH)
        if witches and killed_seat is not None:
            witch = witches[0]
            saved, poison_target, reason = witch.witch_decide(
                killed_seat, self._alive_seats(),
                self.witch_has_antidote, self.witch_has_poison,
            )
            if saved and self.witch_has_antidote:
                self.witch_has_antidote = False
                killed_seat = None  # 被救了
                self._emit("witch_save", {"witch": witch.seat, "target": self._agent_by_seat(killed_seat).seat if killed_seat else "?", "reason": reason})
                print(f"  💊 女巫使用解药救人")
            if poison_target is not None and self.witch_has_poison:
                self.witch_has_poison = False
                self.witch_poisoned_this_night = True
                self._emit("witch_poison", {"witch": witch.seat, "target": poison_target, "reason": reason})
                print(f"  ☠ 女巫使用毒药毒杀 {poison_target}号")
                # 毒杀在夜晚结束时结算

        # 结算夜晚死亡
        night_deaths = []
        if killed_seat is not None:
            self._kill(killed_seat, "被狼人杀害")
            night_deaths.append((killed_seat, False))  # (seat, 是否被毒)
        # 女巫毒杀结算
        if witches and self.witch_has_poison is False:
            # 查找毒杀目标
            for entry in self.log:
                if entry.get("event") == "witch_poison" and entry.get("day") == self.day:
                    pseat = entry["target"]
                    pa = self._agent_by_seat(pseat)
                    if pa and pa.alive:
                        self._kill(pseat, "被女巫毒杀")
                        night_deaths.append((pseat, True))  # 被毒

        self._emit("night_end", {"deaths": [d[0] for d in night_deaths]})
        return night_deaths

    def day_phase(self, night_deaths: list):
        """白天阶段：宣布死讯 → 发言 → 投票"""
        print(f"\n{'='*40}")
        print(f"  ☀ 第{self.day}天 · 白天")
        print(f"{'='*40}")

        # 宣布死讯
        death_announcement = "、".join(
            f"{seat}号" for seat, _ in night_deaths
        ) if night_deaths else "昨晚是平安夜"
        print(f"  📢 昨晚死亡：{death_announcement}")

        # 猎人开枪（被狼杀或被投票出局时，非被毒杀）
        for seat, poisoned in night_deaths:
            agent = self._agent_by_seat(seat)
            if agent.role == ROLE_HUNTER and not poisoned:
                self._hunter_shoot(agent)

        # 检查胜负
        if self.check_win():
            return

        # 发言环节
        alive = self._alive_agents()
        speech_summary = ""
        speeches = {}
        for a in alive:
            speech = a.speak(self.day, [d[0] for d in night_deaths], speech_summary)
            speeches[a.seat] = speech
            speech_summary += f"\n{a.seat}号：{speech}"
            print(f"  💬 {a.seat}号发言：{speech}")
            self._emit("speech", {"seat": a.seat, "content": speech})

        # 投票环节
        alive_seats = self._alive_seats()
        vote_count: dict[int, int] = {s: 0 for s in alive_seats}
        vote_detail = {}
        print(f"\n  🗳 投票环节")
        for a in self._alive_agents():
            target, reason = a.vote(self.day, alive_seats, alive_seats)
            if target in vote_count:
                vote_count[target] += 1
            vote_detail[a.seat] = target
            print(f"    {a.seat}号 → {target}号")

        self._emit("vote", {"count": vote_count, "detail": vote_detail})

        # 统计票数，最高票出局
        if vote_count:
            max_votes = max(vote_count.values())
            top_seats = [s for s, v in vote_count.items() if v == max_votes]
            if len(top_seats) == 1:
                exiled = top_seats[0]
                exiled_agent = self._agent_by_seat(exiled)
                print(f"\n  ⚖ {exiled}号（{exiled_agent.role_name}）以{max_votes}票被投出")
                self._kill(exiled, "被投票出局")
                # 猎人被投出可以开枪
                if exiled_agent.role == ROLE_HUNTER:
                    self._hunter_shoot(exiled_agent)
            else:
                print(f"\n  ⚖ 平票（{top_seats}），无人出局")

    def _hunter_shoot(self, hunter: Agent):
        """猎人开枪"""
        alive_seats = self._alive_seats()
        if not alive_seats:
            return
        target, reason = hunter.hunter_shoot(alive_seats)
        if target and target in alive_seats:
            print(f"  🔫 猎人{hunter.seat}号开枪带走 {target}号")
            self._kill(target, f"被猎人{hunter.seat}号开枪带走")

    def run(self):
        """运行完整对局"""
        print("🎮 狼人杀 AI 对局开始！")
        self.setup()

        for _ in range(20):  # 最多20天，防止死循环
            night_deaths = self.night_phase()
            if self.check_win():
                break
            self.day_phase(night_deaths)
            if self.check_win():
                break

        print(f"\n{'='*50}")
        print(f"  🏆 游戏结束！{self.winner}阵营获胜！")
        print(f"{'='*50}")
        for a in self.agents:
            print(f"  {a.seat}号：{a.role_name}（{'存活' if a.alive else '死亡'}）")

        self._emit("game_over", {"winner": self.winner})
        return self.winner
