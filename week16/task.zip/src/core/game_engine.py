import asyncio
import sys
from pathlib import Path

if not any(str(Path(__file__).parent.parent) in p for p in sys.path):
    sys.path.insert(0, str(Path(__file__).parent.parent))

from typing import Dict, Optional
from game_types import (
    GamePhase, Player, Team, NightAction, VoteAction, 
    GameEvent, Role, PlayerStatus, GameConfig
)
from core.player_manager import PlayerManager
from game_logger import StructuredLogger
from communication.message_bus import MessageBus


class GameEngine:
    def __init__(self):
        self.player_manager = PlayerManager()
        self.logger = StructuredLogger()
        self.message_bus = MessageBus()
        self.agents: Dict[str, object] = {}
        self.current_phase = GamePhase.NIGHT_START
        self.current_round = 1
        self.night_actions: list = []
        self.vote_actions: list = []
        self.is_running = False
        self.winner: Optional[Team] = None

    async def start_game(self, player_count: int = 12):
        print("=== AI 狼人杀游戏开始 ===")
        print(f"玩家数量: {player_count}")

        config = self._get_default_config(player_count)
        players = self.player_manager.initialize_players(config)

        self._initialize_agents(players)
        self.is_running = True
        self.current_round = 1

        self._log_event("game_start", GamePhase.NIGHT_START, {"player_count": player_count})

        while self.is_running:
            print(f"\n===== 第 {self.current_round} 天 =====")
            await self._execute_night_phase()
            if not self.is_running:
                break

            await self._execute_day_phase()
            if not self.is_running:
                break

            self.current_round += 1

            if self.current_round > 20:
                print("游戏达到最大回合数限制")
                break

        self._end_game()

    async def _execute_night_phase(self):
        print("\n--- 夜晚阶段 ---")

        self.current_phase = GamePhase.NIGHT_START
        self._log_event("night_start", self.current_phase, {"round": self.current_round})
        await asyncio.sleep(0.5)

        self.current_phase = GamePhase.WEREWOLF_KILL
        print("\n[狼人行动]")
        await self._execute_werewolf_kill()
        await asyncio.sleep(0.5)

        self.current_phase = GamePhase.GUARD_PROTECT
        print("\n[守卫行动]")
        await self._execute_guard_protect()
        await asyncio.sleep(0.5)

        self.current_phase = GamePhase.SEER_CHECK
        print("\n[预言家行动]")
        await self._execute_seer_check()
        await asyncio.sleep(0.5)

        self.current_phase = GamePhase.WITCH_ACTION
        print("\n[女巫行动]")
        await self._execute_witch_action()
        await asyncio.sleep(0.5)

        self.current_phase = GamePhase.DAY_START
        self._log_event("night_end", self.current_phase, {"round": self.current_round})

    async def _execute_day_phase(self):
        print("\n--- 白天阶段 ---")

        self.current_phase = GamePhase.ANNOUNCE_DEATHS
        print("\n[宣布死亡]")
        await self._announce_deaths()
        await asyncio.sleep(0.5)

        winner = self.player_manager.check_win_condition()
        if winner:
            self.winner = winner
            self.is_running = False
            return

        self.current_phase = GamePhase.DISCUSSION
        print("\n[讨论阶段]")
        await self._execute_discussion()
        await asyncio.sleep(0.5)

        self.current_phase = GamePhase.VOTING
        print("\n[投票阶段]")
        await self._execute_voting()
        await asyncio.sleep(0.5)

        self.current_phase = GamePhase.VOTE_RESULT
        print("\n[投票结果]")
        await self._announce_vote_result()
        await asyncio.sleep(0.5)

        winner2 = self.player_manager.check_win_condition()
        if winner2:
            self.winner = winner2
            self.is_running = False

    async def _execute_werewolf_kill(self):
        werewolves = self.player_manager.get_alive_players_by_team(Team.WEREWOLF)
        if not werewolves:
            return

        alive_players = self.player_manager.get_alive_players()
        non_werewolves = [p for p in alive_players if p.team != Team.WEREWOLF]

        if not non_werewolves:
            return

        targets = []
        for werewolf in werewolves:
            agent = self.agents.get(werewolf.id)
            if agent:
                target = await agent.night_action(werewolf, non_werewolves, self.message_bus)
                if target:
                    targets.append(target)

        if targets:
            target_counts = {}
            for t in targets:
                target_counts[t] = target_counts.get(t, 0) + 1

            max_count = max(target_counts.values())
            candidates = [tid for tid, count in target_counts.items() if count == max_count]

            final_target = candidates[0]
            self.night_actions.append(NightAction(
                actor_id=werewolves[0].id,
                target_id=final_target,
                action="kill"
            ))

            target_player = self.player_manager.get_player(final_target)
            print(f"狼人们选择攻击: {target_player.name if target_player else final_target}")
            self._log_event("werewolf_kill", self.current_phase, {"target_id": final_target})

    async def _execute_guard_protect(self):
        guards = [p for p in self.player_manager.get_players_by_role(Role.GUARD) 
                  if self.player_manager.is_alive(p.id)]
        if not guards:
            return

        guard = guards[0]
        agent = self.agents.get(guard.id)
        if not agent:
            return

        alive_players = self.player_manager.get_alive_players()
        targets = [p for p in alive_players if p.id != guard.id]
        target = await agent.night_action(guard, targets, self.message_bus)

        if target:
            self.player_manager.protect_player(target)
            target_player = self.player_manager.get_player(target)
            print(f"守卫守护了: {target_player.name if target_player else target}")
            self._log_event("guard_protect", self.current_phase, {"target_id": target})

    async def _execute_seer_check(self):
        seers = [p for p in self.player_manager.get_players_by_role(Role.SEER) 
                 if self.player_manager.is_alive(p.id)]
        if not seers:
            return

        seer = seers[0]
        agent = self.agents.get(seer.id)
        if not agent:
            return

        alive_players = self.player_manager.get_alive_players()
        targets = [p for p in alive_players if p.id != seer.id]
        target = await agent.night_action(seer, targets, self.message_bus)

        if target:
            target_player = self.player_manager.get_player(target)
            if target_player:
                is_werewolf = target_player.team == Team.WEREWOLF
                await agent.receive_information(seer, {"target_id": target, "is_werewolf": is_werewolf})
                result = "狼人" if is_werewolf else "好人"
                print(f"预言家查验了: {target_player.name}, 结果是: {result}")
                self._log_event("seer_check", self.current_phase, {
                    "target_id": target, 
                    "is_werewolf": is_werewolf
                })

    async def _execute_witch_action(self):
        witches = [p for p in self.player_manager.get_players_by_role(Role.WITCH) 
                   if self.player_manager.is_alive(p.id)]
        if not witches:
            return

        witch = witches[0]
        agent = self.agents.get(witch.id)
        if not agent:
            return

        killed_target = None
        for action in self.night_actions:
            if action.action == "kill":
                killed_target = action.target_id
                break

        alive_players = self.player_manager.get_alive_players()
        targets = [p for p in alive_players if p.id != witch.id]
        
        action_result = await agent.night_action(witch, targets, self.message_bus, killed_target)

        if action_result == "save" and killed_target:
            self.night_actions = [a for a in self.night_actions if a.action != "kill"]
            print("女巫使用了解药")
            self._log_event("witch_save", self.current_phase, {"target_id": killed_target})
        elif action_result and action_result != "save":
            target_id = action_result if isinstance(action_result, str) else None
            if target_id and self.player_manager.is_alive(target_id):
                self.player_manager.kill_player(target_id)
                target_player = self.player_manager.get_player(target_id)
                print(f"女巫毒杀了: {target_player.name if target_player else target_id}")
                self._log_event("witch_poison", self.current_phase, {"target_id": target_id})

    async def _announce_deaths(self):
        killed_ids = [a.target_id for a in self.night_actions 
                      if a.action == "kill" and a.target_id]

        protected_ids = [p.id for p in self.player_manager.get_players() 
                        if p.status == PlayerStatus.PROTECTED]

        actual_deaths = [tid for tid in killed_ids if tid not in protected_ids]

        if not actual_deaths:
            print("昨晚是平安夜")
            self._log_event("peaceful_night", self.current_phase, {})
        else:
            for player_id in actual_deaths:
                player = self.player_manager.get_player(player_id)
                if player:
                    self.player_manager.kill_player(player_id)
                    print(f"{player.name}({player.role.value}) 死亡")
                    self._log_event("player_death", self.current_phase, {
                        "player_id": player_id, 
                        "role": player.role.value
                    })

        self.night_actions.clear()
        for p in self.player_manager.get_players():
            if p.status == PlayerStatus.PROTECTED:
                self.player_manager.reset_protection(p.id)

    async def _execute_discussion(self):
        alive_players = self.player_manager.get_alive_players()

        for player in alive_players:
            agent = self.agents.get(player.id)
            if agent:
                speech = await agent.generate_speech(
                    player, alive_players, self.message_bus, self.current_round
                )
                print(f"[{player.name}]: {speech}")
                self.logger.log_speech({
                    "speaker_id": player.id,
                    "content": speech,
                    "phase": self.current_phase,
                    "round": self.current_round
                })

    async def _execute_voting(self):
        alive_players = self.player_manager.get_alive_players()
        self.vote_actions.clear()

        for voter in alive_players:
            agent = self.agents.get(voter.id)
            if agent:
                candidates = [p for p in alive_players if p.id != voter.id]
                target = await agent.vote(voter, candidates, self.message_bus)
                if target:
                    self.vote_actions.append(VoteAction(voter_id=voter.id, target_id=target))

    async def _announce_vote_result(self):
        if not self.vote_actions:
            print("无人投票")
            return

        vote_counts = {}
        for v in self.vote_actions:
            if v.target_id:
                vote_counts[v.target_id] = vote_counts.get(v.target_id, 0) + 1

        if not vote_counts:
            print("无人投票")
            return

        max_votes = max(vote_counts.values())
        candidates = [tid for tid, count in vote_counts.items() if count == max_votes]

        if len(candidates) == 1:
            eliminated_id = candidates[0]
            eliminated = self.player_manager.get_player(eliminated_id)
            if eliminated:
                self.player_manager.kill_player(eliminated_id)
                print(f"{eliminated.name}({eliminated.role.value}) 被投票出局")
                self._log_event("vote_eliminate", self.current_phase, {
                    "player_id": eliminated_id,
                    "role": eliminated.role.value,
                    "votes": max_votes
                })
        else:
            print("平票，无人出局")
            self._log_event("vote_tie", self.current_phase, {"candidates": candidates})

    def _initialize_agents(self, players: list):
        self.agents.clear()

        for player in players:
            agent = self._create_agent_for_role(player.role, player.id)
            self.agents[player.id] = agent
            print(f"{player.name} 的角色是: {player.role.value}")

    def _create_agent_for_role(self, role: Role, player_id: str):
        from src.agents.werewolf_agent import WerewolfAgent
        from src.agents.seer_agent import SeerAgent
        from src.agents.witch_agent import WitchAgent
        from src.agents.hunter_agent import HunterAgent
        from src.agents.guard_agent import GuardAgent
        from src.agents.villager_agent import VillagerAgent

        agent_map = {
            Role.WEREWOLF: WerewolfAgent,
            Role.SEER: SeerAgent,
            Role.WITCH: WitchAgent,
            Role.HUNTER: HunterAgent,
            Role.GUARD: GuardAgent,
            Role.VILLAGER: VillagerAgent,
        }
        
        agent_class = agent_map.get(role, VillagerAgent)
        return agent_class(player_id)

    def _end_game(self):
        print("\n=== 游戏结束 ===")
        if self.winner:
            winner_name = "狼人" if self.winner == Team.WEREWOLF else "好人"
            print(f"获胜方: {winner_name}")
            self.logger.log_game_result(self.winner.value, self.current_round)

        final_state = {
            "winner": self.winner.value if self.winner else None,
            "rounds": self.current_round,
            "players": [
                {
                    "name": p.name,
                    "role": p.role.value,
                    "survived": p.status != PlayerStatus.DEAD
                }
                for p in self.player_manager.get_players()
            ]
        }

        print("\n最终状态:", final_state)
        self._log_event("game_over", GamePhase.GAME_OVER, final_state)

    def _log_event(self, event_type: str, phase: GamePhase, data: dict):
        self.logger.log_game_event(GameEvent(
            type=event_type,
            phase=phase,
            data=data,
            timestamp=asyncio.get_event_loop().time()
        ))

    def _get_default_config(self, player_count: int) -> GameConfig:
        distribution = {
            Role.WEREWOLF: 3,
            Role.SEER: 1,
            Role.WITCH: 1,
            Role.HUNTER: 1,
            Role.GUARD: 1,
            Role.VILLAGER: max(1, player_count - 7)
        }

        return GameConfig(
            player_count=player_count,
            role_distribution=distribution,
            enable_human=False
        )
