import sys
from pathlib import Path
if not any(str(Path(__file__).parent.parent) in p for p in sys.path):
    sys.path.insert(0, str(Path(__file__).parent.parent))

import uuid
from typing import List, Dict, Optional
from game_types import Player, Role, Team, PlayerStatus, GameConfig


class PlayerManager:
    def __init__(self):
        self.players: Dict[str, Player] = {}

    def initialize_players(self, config: GameConfig) -> List[Player]:
        self.players.clear()
        role_list = self._generate_role_list(config.role_distribution)
        shuffled = self._shuffle_array(role_list)

        for i in range(config.player_count):
            player = Player(
                id=str(uuid.uuid4()),
                name=f"Player_{i + 1}",
                role=shuffled[i],
                team=self._get_team_for_role(shuffled[i]),
                status=PlayerStatus.ALIVE,
                is_human=config.enable_human and config.human_role == shuffled[i] and i == 0
            )
            self.players[player.id] = player

        return self.get_alive_players()

    def get_player(self, player_id: str) -> Optional[Player]:
        return self.players.get(player_id)

    def get_players(self) -> List[Player]:
        return list(self.players.values())

    def get_alive_players(self) -> List[Player]:
        return [p for p in self.players.values() if p.status == PlayerStatus.ALIVE]

    def get_players_by_role(self, role: Role) -> List[Player]:
        return [p for p in self.players.values() if p.role == role]

    def get_players_by_team(self, team: Team) -> List[Player]:
        return [p for p in self.players.values() if p.team == team]

    def get_alive_players_by_team(self, team: Team) -> List[Player]:
        return [p for p in self.get_alive_players() if p.team == team]

    def kill_player(self, player_id: str):
        player = self.players.get(player_id)
        if player:
            player.status = PlayerStatus.DEAD

    def protect_player(self, player_id: str):
        player = self.players.get(player_id)
        if player:
            player.status = PlayerStatus.PROTECTED

    def reset_protection(self, player_id: str):
        player = self.players.get(player_id)
        if player and player.status == PlayerStatus.PROTECTED:
            player.status = PlayerStatus.ALIVE

    def is_alive(self, player_id: str) -> bool:
        player = self.players.get(player_id)
        return player is not None and player.status in [PlayerStatus.ALIVE, PlayerStatus.PROTECTED]

    def check_win_condition(self) -> Optional[Team]:
        alive_werewolves = self.get_alive_players_by_team(Team.WEREWOLF)
        alive_good = self.get_alive_players_by_team(Team.GOOD)

        if len(alive_werewolves) == 0:
            return Team.GOOD

        if len(alive_werewolves) >= len(alive_good):
            return Team.WEREWOLF

        return None

    def _generate_role_list(self, distribution: Dict[Role, int]) -> List[Role]:
        roles = []
        for role, count in distribution.items():
            roles.extend([role] * count)
        return roles

    def _get_team_for_role(self, role: Role) -> Team:
        if role == Role.WEREWOLF:
            return Team.WEREWOLF
        return Team.GOOD

    def _shuffle_array(self, array: list) -> list:
        import random
        shuffled = array.copy()
        random.shuffle(shuffled)
        return shuffled
