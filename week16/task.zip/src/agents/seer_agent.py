import sys
from pathlib import Path
if not any(str(Path(__file__).parent.parent) in p for p in sys.path):
    sys.path.insert(0, str(Path(__file__).parent.parent))

from typing import Optional, List
from game_types import Player, Role, Team
from agents.base_agent import BaseAgent
from communication.message_bus import MessageBus


class SeerAgent(BaseAgent):
    def __init__(self, player_id: str):
        super().__init__(player_id)
        self.checked_players: dict = {}

    def get_role(self) -> Role:
        return Role.SEER

    def get_team(self) -> Team:
        return Team.GOOD

    async def night_action(
        self,
        self_player: Player,
        available_targets: List[Player],
        message_bus: MessageBus,
        extra_info=None
    ) -> Optional[str]:
        unchecked = [p for p in available_targets if p.id not in self.checked_players]

        if not unchecked:
            return self.get_random_alive(available_targets)

        strategy = self.get_strategy()

        if strategy.get("priority_suspicious"):
            suspicious = [p for p in unchecked if f"suspicious_{p.id}" in self.memory]
            if suspicious:
                return suspicious[0].id

        return unchecked[0].id

    async def receive_information(self, self_player: Player, info: dict):
        await super().receive_information(self_player, info)
        if info.get("target_id") and "is_werewolf" in info:
            self.checked_players[info["target_id"]] = info["is_werewolf"]
            self.memory[f"check_{info['target_id']}"] = info["is_werewolf"]

    async def generate_speech(
        self,
        self_player: Player,
        alive_players: List[Player],
        message_bus: MessageBus,
        round_num: int
    ) -> str:
        strategy = self.get_strategy()
        known_werewolves = [
            alive_players[i] for i, pid in enumerate([p.id for p in alive_players])
            if self.checked_players.get(pid) is True
        ]

        if strategy.get("reveal_identity") and known_werewolves:
            werewolf = known_werewolves[0]
            return f"我是预言家，我查验了{werewolf.name}，他是狼人！请大家相信我，跟我投票。"

        if known_werewolves:
            werewolf = known_werewolves[0]
            return f"{werewolf.name}的发言有些问题，我觉得我们应该重点关注他。"

        known_good = [
            p for p in alive_players 
            if self.checked_players.get(p.id) is False
        ]

        if known_good:
            return f"{known_good[0].name}是好人，我可以为他担保。"

        return "我目前还没有太多信息，需要继续观察大家的发言。"

    async def vote(
        self,
        self_player: Player,
        candidates: List[Player],
        message_bus: MessageBus
    ) -> Optional[str]:
        known_werewolves = [p for p in candidates if self.checked_players.get(p.id) is True]

        if known_werewolves:
            return known_werewolves[0].id

        return self.get_random_alive(candidates)
