import sys
from pathlib import Path
if not any(str(Path(__file__).parent.parent) in p for p in sys.path):
    sys.path.insert(0, str(Path(__file__).parent.parent))

from typing import Optional, List, Set
from game_types import Player, Role, Team, SpeechRecord
from agents.base_agent import BaseAgent
from communication.message_bus import MessageBus


class WerewolfAgent(BaseAgent):
    def __init__(self, player_id: str):
        super().__init__(player_id)
        self.werewolf_partners: Set[str] = set()

    def get_role(self) -> Role:
        return Role.WEREWOLF

    def get_team(self) -> Team:
        return Team.WEREWOLF

    async def night_action(
        self,
        self_player: Player,
        available_targets: List[Player],
        message_bus: MessageBus,
        extra_info=None
    ) -> Optional[str]:
        strategy = self.get_strategy()

        if strategy.get("target_preference") == "seer":
            seers = [t for t in available_targets if f"check_{t.id}" in self.memory]
            if seers:
                return seers[0].id

        if strategy.get("avoid_repeat") and "last_kill" in self.memory:
            last_kill = self.memory["last_kill"]
            filtered = [t for t in available_targets if t.id != last_kill]
            if filtered:
                return self.get_random_alive(filtered)

        return self.get_random_alive(available_targets)

    async def generate_speech(
        self,
        self_player: Player,
        alive_players: List[Player],
        message_bus: MessageBus,
        round_num: int
    ) -> str:
        strategy = self.get_strategy()
        non_werewolves = [p for p in alive_players if p.team != Team.WEREWOLF]

        if strategy.get("aggressive"):
            import random
            target = random.choice(non_werewolves) if non_werewolves else None
            return f"我怀疑{target.name if target else '某人'}是狼人，他的发言很有问题。我是好人，希望大家能相信我。"

        if strategy.get("defensive"):
            return "我是平民，昨晚什么信息也没有。我觉得我们应该多听听大家的发言再做决定。"

        import random
        target = random.choice(non_werewolves) if non_werewolves else None
        return f"{target.name if target else '某人'}的发言有些可疑，但我还不能确定。我们先继续讨论吧。"

    async def vote(
        self,
        self_player: Player,
        candidates: List[Player],
        message_bus: MessageBus
    ) -> Optional[str]:
        strategy = self.get_strategy()
        non_werewolves = [p for p in candidates if p.team != Team.WEREWOLF]

        if strategy.get("vote_out_seer"):
            suspected_seers = [p for p in non_werewolves 
                             if f"suspected_seer_{p.id}" in self.memory]
            if suspected_seers:
                return suspected_seers[0].id

        return self.get_random_alive(non_werewolves)

    def add_werewolf_partner(self, partner_id: str):
        self.werewolf_partners.add(partner_id)

    def is_werewolf_partner(self, player_id: str) -> bool:
        return player_id in self.werewolf_partners
