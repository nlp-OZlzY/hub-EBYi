import sys
from pathlib import Path
if not any(str(Path(__file__).parent.parent) in p for p in sys.path):
    sys.path.insert(0, str(Path(__file__).parent.parent))

from typing import Optional, List
from game_types import Player, Role, Team
from agents.base_agent import BaseAgent
from communication.message_bus import MessageBus


class GuardAgent(BaseAgent):
    def __init__(self, player_id: str):
        super().__init__(player_id)
        self.last_protected: Optional[str] = None

    def get_role(self) -> Role:
        return Role.GUARD

    def get_team(self) -> Team:
        return Team.GOOD

    async def night_action(
        self,
        self_player: Player,
        available_targets: List[Player],
        message_bus: MessageBus,
        extra_info=None
    ) -> Optional[str]:
        valid_targets = [p for p in available_targets if p.id != self.last_protected]

        if not valid_targets:
            return self.get_random_alive(available_targets)

        strategy = self.get_strategy()

        if strategy.get("protect_self"):
            if self.last_protected != self_player.id:
                self.last_protected = self_player.id
                return self_player.id

        if strategy.get("protect_important"):
            important = [p for p in valid_targets 
                       if f"important_{p.id}" in self.memory]
            if important:
                self.last_protected = important[0].id
                return important[0].id

        import random
        target = random.choice(valid_targets)
        self.last_protected = target.id
        return target.id

    async def generate_speech(
        self,
        self_player: Player,
        alive_players: List[Player],
        message_bus: MessageBus,
        round_num: int
    ) -> str:
        return "昨晚我守了一个人，希望大家都能平安。我觉得我们应该仔细分析一下发言。"

    async def vote(
        self,
        self_player: Player,
        candidates: List[Player],
        message_bus: MessageBus
    ) -> Optional[str]:
        return self.get_random_alive(candidates)
