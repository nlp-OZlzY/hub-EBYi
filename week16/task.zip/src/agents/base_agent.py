import sys
from pathlib import Path
if not any(str(Path(__file__).parent.parent) in p for p in sys.path):
    sys.path.insert(0, str(Path(__file__).parent.parent))

from typing import Optional, Dict, Any, List
from abc import ABC, abstractmethod
from game_types import Player, Role, Team, SpeechRecord
from communication.message_bus import MessageBus


class BaseAgent(ABC):
    def __init__(self, player_id: str):
        self.player_id = player_id
        self.memory: Dict[str, Any] = {}
        self.strategy: Dict[str, Any] = {}

    @abstractmethod
    def get_role(self) -> Role:
        pass

    @abstractmethod
    def get_team(self) -> Team:
        pass

    @abstractmethod
    async def night_action(
        self,
        self_player: Player,
        available_targets: List[Player],
        message_bus: MessageBus,
        extra_info: Optional[Any] = None
    ) -> Optional[str]:
        pass

    @abstractmethod
    async def generate_speech(
        self,
        self_player: Player,
        alive_players: List[Player],
        message_bus: MessageBus,
        round_num: int
    ) -> str:
        pass

    @abstractmethod
    async def vote(
        self,
        self_player: Player,
        candidates: List[Player],
        message_bus: MessageBus
    ) -> Optional[str]:
        pass

    async def receive_information(self, self_player: Player, info: Dict[str, Any]):
        key = info.get("target_id", "last_check")
        self.memory[key] = info

    def get_memory(self, key: str) -> Any:
        return self.memory.get(key)

    def set_memory(self, key: str, value: Any):
        self.memory[key] = value

    def analyze_suspicion(self, target: Player, speeches: List[SpeechRecord]) -> float:
        target_speeches = [s for s in speeches if s.speaker_id == target.id]
        if not target_speeches:
            return 0.5

        suspicion = 0.5

        for speech in target_speeches:
            content = speech.content.lower()

            if "怀疑" in content or "狼人" in content:
                suspicion += 0.1
            if "我是好人" in content or "村民" in content:
                suspicion -= 0.05
            if "预言家" in content or "查验" in content:
                suspicion -= 0.1

        return max(0, min(1, suspicion))

    def select_target_by_suspicion(
        self, 
        candidates: List[Player], 
        suspicion_scores: Dict[str, float]
    ) -> Optional[str]:
        if not candidates:
            return None

        max_suspicion = -1
        selected = None

        for candidate in candidates:
            score = suspicion_scores.get(candidate.id, 0.5)
            if score > max_suspicion:
                max_suspicion = score
                selected = candidate.id

        return selected

    def get_random_alive(self, candidates: List[Player]) -> Optional[str]:
        import random
        if not candidates:
            return None
        return random.choice(candidates).id

    def update_strategy(self, new_strategy: Dict[str, Any]):
        self.strategy.update(new_strategy)

    def get_strategy(self) -> Dict[str, Any]:
        return self.strategy

    def export_state(self) -> Dict[str, Any]:
        return {
            "player_id": self.player_id,
            "role": self.get_role().value,
            "team": self.get_team().value,
            "memory": self.memory,
            "strategy": self.strategy
        }

    def import_state(self, state: Dict[str, Any]):
        if "memory" in state:
            self.memory = state["memory"]
        if "strategy" in state:
            self.strategy = state["strategy"]
