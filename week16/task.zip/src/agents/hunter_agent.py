import sys
from pathlib import Path
if not any(str(Path(__file__).parent.parent) in p for p in sys.path):
    sys.path.insert(0, str(Path(__file__).parent.parent))

from typing import Optional, List
from game_types import Player, Role, Team
from agents.base_agent import BaseAgent
from communication.message_bus import MessageBus


class HunterAgent(BaseAgent):
    def get_role(self) -> Role:
        return Role.HUNTER

    def get_team(self) -> Team:
        return Team.GOOD

    async def night_action(
        self,
        self_player: Player,
        available_targets: List[Player],
        message_bus: MessageBus,
        extra_info=None
    ) -> Optional[str]:
        return None

    async def on_death(
        self,
        self_player: Player,
        alive_players: List[Player],
        message_bus: MessageBus
    ) -> Optional[str]:
        strategy = self.get_strategy()

        if strategy.get("shoot_suspicious"):
            suspicious = [p for p in alive_players 
                        if f"suspicious_{p.id}" in self.memory]
            if suspicious:
                return suspicious[0].id

        import random
        werewolves = [p for p in alive_players if p.team == Team.WEREWOLF]
        if werewolves and random.random() > 0.5:
            return werewolves[0].id

        return self.get_random_alive(alive_players)

    async def generate_speech(
        self,
        self_player: Player,
        alive_players: List[Player],
        message_bus: MessageBus,
        round_num: int
    ) -> str:
        return "我是猎人，大家不要乱投票。如果我被票出去，我会带走一个可疑的人。"

    async def vote(
        self,
        self_player: Player,
        candidates: List[Player],
        message_bus: MessageBus
    ) -> Optional[str]:
        suspicious = [p for p in candidates if f"suspicious_{p.id}" in self.memory]

        if suspicious:
            return suspicious[0].id

        return self.get_random_alive(candidates)
