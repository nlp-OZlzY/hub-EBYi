import sys
from pathlib import Path
if not any(str(Path(__file__).parent.parent) in p for p in sys.path):
    sys.path.insert(0, str(Path(__file__).parent.parent))

from typing import Optional, List
from game_types import Player, Role, Team
from agents.base_agent import BaseAgent
from communication.message_bus import MessageBus


class WitchAgent(BaseAgent):
    def __init__(self, player_id: str):
        super().__init__(player_id)
        self.has_used_save = False
        self.has_used_poison = False

    def get_role(self) -> Role:
        return Role.WITCH

    def get_team(self) -> Team:
        return Team.GOOD

    async def night_action(
        self,
        self_player: Player,
        available_targets: List[Player],
        message_bus: MessageBus,
        extra_info=None
    ) -> Optional[str]:
        killed_target = extra_info

        if killed_target and not self.has_used_save:
            strategy = self.get_strategy()

            if strategy.get("save_always"):
                self.has_used_save = True
                return "save"

            if strategy.get("save_important"):
                is_important = f"important_{killed_target}" in self.memory
                if is_important:
                    self.has_used_save = True
                    return "save"

            import random
            if random.random() > 0.5:
                self.has_used_save = True
                return "save"

        if not self.has_used_poison and available_targets:
            strategy = self.get_strategy()

            if strategy.get("poison_aggressive"):
                suspicious = [p for p in available_targets 
                            if f"suspicious_{p.id}" in self.memory]
                if suspicious:
                    self.has_used_poison = True
                    return suspicious[0].id

            import random
            if random.random() > 0.7:
                self.has_used_poison = True
                return self.get_random_alive(available_targets)

        return None

    async def generate_speech(
        self,
        self_player: Player,
        alive_players: List[Player],
        message_bus: MessageBus,
        round_num: int
    ) -> str:
        strategy = self.get_strategy()

        if strategy.get("reveal_identity"):
            save_status = "已经" if self.has_used_save else "还没"
            poison_status = "已经" if self.has_used_poison else "还没"
            return f"我是女巫，解药{save_status}用，毒药{poison_status}用。"

        return "我觉得我们应该多分析一下昨晚的情况，不要急于下结论。"

    async def vote(
        self,
        self_player: Player,
        candidates: List[Player],
        message_bus: MessageBus
    ) -> Optional[str]:
        suspicious = [p for p in candidates if f"suspicious_{p.id}" in self.memory]

        if suspicious:
            return suspicious[0].id

        return self.get_random_alive(candidates)

    def has_save_potion(self) -> bool:
        return not self.has_used_save

    def has_poison_potion(self) -> bool:
        return not self.has_used_poison
