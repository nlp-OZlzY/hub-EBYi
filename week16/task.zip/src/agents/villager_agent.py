import sys
from pathlib import Path
if not any(str(Path(__file__).parent.parent) in p for p in sys.path):
    sys.path.insert(0, str(Path(__file__).parent.parent))

from typing import Optional, List
from game_types import Player, Role, Team
from agents.base_agent import BaseAgent
from communication.message_bus import MessageBus


class VillagerAgent(BaseAgent):
    def get_role(self) -> Role:
        return Role.VILLAGER

    def get_team(self) -> Team:
        return Team.GOOD

    async def night_action(
        self,
        self_player: Player,
        available_targets: List[Player],
        message_bus: MessageBus,
        extra_info=None
    ) -> Optional[str]:
        return None

    async def generate_speech(
        self,
        self_player: Player,
        alive_players: List[Player],
        message_bus: MessageBus,
        round_num: int
    ) -> str:
        strategy = self.get_strategy()

        if strategy.get("analytical"):
            return "我仔细听了大家的发言，我觉得有些人的逻辑不太通顺。我们需要更多的证据。"

        if strategy.get("cooperative"):
            return "我是平民，没有特殊信息。但我愿意和大家一起找出狼人。"

        return "我觉得我们需要多讨论一下，不要急于投票。"

    async def vote(
        self,
        self_player: Player,
        candidates: List[Player],
        message_bus: MessageBus
    ) -> Optional[str]:
        suspicious = [p for p in candidates if f"suspicious_{p.id}" in self.memory]

        if suspicious:
            return suspicious[0].id

        return self.get_random_alive(candidates)
