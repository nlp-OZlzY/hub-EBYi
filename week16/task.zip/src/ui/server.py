import asyncio
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))

from aiohttp import web
from core.game_engine import GameEngine


class GameServer:
    def __init__(self):
        self.app = web.Application()
        self.app.router.add_get('/', self.handle_index)
        self.app.router.add_static('/ui/', path='ui', name='ui')
        self.app.router.add_post('/api/start', self.handle_start)
        self.clients = []

    async def handle_index(self, request):
        return web.FileResponse('ui/index.html')

    async def handle_start(self, request):
        data = await request.json()
        player_count = data.get('player_count', 12)

        engine = GameEngine()
        asyncio.create_task(self._run_game(engine, player_count))

        return web.json_response({"status": "game_started"})

    async def _run_game(self, engine, player_count):
        await engine.start_game(player_count)


def main():
    server = GameServer()
    web.run_app(server.app, host='localhost', port=3001)


if __name__ == "__main__":
    main()
