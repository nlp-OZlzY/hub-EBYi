import sys
from pathlib import Path
if not any(str(Path(__file__).parent) in p for p in sys.path):
    sys.path.insert(0, str(Path(__file__).parent))

import os
import json
from datetime import datetime
from typing import Dict, List
from loguru import logger
from game_types import GameEvent, SpeechRecord, GamePhase


class StructuredLogger:
    def __init__(self):
        self.events: List[GameEvent] = []
        self.speeches: List[SpeechRecord] = []

        os.makedirs("logs", exist_ok=True)

        logger.add(
            "logs/game.log",
            rotation="10 MB",
            level="INFO",
            format="{time:YYYY-MM-DD HH:mm:ss} | {level} | {message}"
        )

        logger.add(
            "logs/events.log",
            rotation="10 MB",
            level="INFO",
            format="{time:YYYY-MM-DD HH:mm:ss} | {message}"
        )

    def log_game_event(self, event: GameEvent):
        self.events.append(event)
        logger.info(f"Game Event: {event.type} | Phase: {event.phase.value} | Data: {event.data}")

    def log_speech(self, speech_data: Dict):
        speech = SpeechRecord(
            speaker_id=speech_data["speaker_id"],
            content=speech_data["content"],
            phase=speech_data.get("phase", GamePhase.DISCUSSION),
            round=speech_data.get("round", 0)
        )
        self.speeches.append(speech)
        content_preview = speech.content[:100] + "..." if len(speech.content) > 100 else speech.content
        logger.info(f"Speech: {speech.speaker_id} | {content_preview}")

    def log_phase_transition(self, from_phase: GamePhase, to_phase: GamePhase):
        logger.info(f"Phase Transition: {from_phase.value} -> {to_phase.value}")

    def log_player_action(self, player_id: str, action: str, target: str = None):
        logger.info(f"Player Action: {player_id} | {action} | Target: {target}")

    def log_game_result(self, winner: str, rounds: int):
        logger.info(f"Game Result: Winner: {winner} | Rounds: {rounds}")

    def get_events(self) -> List[GameEvent]:
        return self.events

    def get_speeches(self) -> List[SpeechRecord]:
        return self.speeches

    def export_game_log(self) -> Dict:
        return {
            "events": [
                {
                    "type": e.type,
                    "phase": e.phase.value,
                    "data": e.data,
                    "timestamp": e.timestamp
                }
                for e in self.events
            ],
            "speeches": [
                {
                    "speaker_id": s.speaker_id,
                    "content": s.content,
                    "phase": s.phase.value,
                    "round": s.round
                }
                for s in self.speeches
            ],
            "exported_at": datetime.now().isoformat()
        }
