from typing import Optional, List, Callable, Dict
from dataclasses import dataclass, field
import time


@dataclass
class Message:
    from_id: str
    to_id: str
    content: any
    type: str
    timestamp: float = field(default_factory=time.time)


class MessageBus:
    def __init__(self):
        self.messages: List[Message] = []
        self.subscribers: Dict[str, List[Callable]] = {}

    def send_message(self, message: Message):
        self.messages.append(message)

        if message.to_id == "broadcast":
            for handlers in self.subscribers.values():
                for handler in handlers:
                    handler(message)
        else:
            handlers = self.subscribers.get(message.to_id)
            if handlers:
                for handler in handlers:
                    handler(message)

    def subscribe(self, player_id: str, handler: Callable):
        if player_id not in self.subscribers:
            self.subscribers[player_id] = []
        self.subscribers[player_id].append(handler)

    def unsubscribe(self, player_id: str, handler: Callable):
        handlers = self.subscribers.get(player_id)
        if handlers:
            self.subscribers[player_id] = [h for h in handlers if h != handler]

    def get_messages_for_player(self, player_id: str, type_filter: Optional[str] = None) -> List[Message]:
        messages = [
            m for m in self.messages
            if m.to_id == player_id or m.to_id == "broadcast" or m.from_id == player_id
        ]
        if type_filter:
            messages = [m for m in messages if m.type == type_filter]
        return messages

    def get_recent_messages(self, player_id: str, count: int = 10) -> List[Message]:
        return self.get_messages_for_player(player_id)[-count:]

    def clear(self):
        self.messages.clear()
        self.subscribers.clear()
