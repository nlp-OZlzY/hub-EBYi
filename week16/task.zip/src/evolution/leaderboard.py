import sys
from pathlib import Path
if not any(str(Path(__file__).parent.parent) in p for p in sys.path):
    sys.path.insert(0, str(Path(__file__).parent.parent))

from typing import Dict, List
from game_types import EvolutionRecord, PlayerStat


class PlayerScore:
    def __init__(self, player_id: str):
        self.player_id = player_id
        self.total_score = 0.0
        self.games_played = 0
        self.wins = 0
        self.win_rate = 0.0
        self.avg_score = 0.0


class Leaderboard:
    def __init__(self):
        self.player_scores: Dict[str, PlayerScore] = {}
        self.game_history: List[EvolutionRecord] = []

    def add_game_result(self, record: EvolutionRecord):
        self.game_history.append(record)

        for player_id, stats in record.player_stats.items():
            if player_id not in self.player_scores:
                self.player_scores[player_id] = PlayerScore(player_id)

            existing = self.player_scores[player_id]
            existing.games_played += 1
            if stats.win_rate > 0:
                existing.wins += 1
            existing.total_score += self._calculate_score(stats)
            existing.win_rate = existing.wins / existing.games_played
            existing.avg_score = existing.total_score / existing.games_played

    def get_top_players(self, count: int = 10) -> List[PlayerScore]:
        return sorted(
            self.player_scores.values(),
            key=lambda x: x.avg_score,
            reverse=True
        )[:count]

    def print_top(self, count: int = 10):
        top = self.get_top_players(count)
        print("\n排名 | 玩家ID | 场次 | 胜率 | 平均分")
        print("-" * 50)
        for i, p in enumerate(top, 1):
            print(f"{i:4d} | {p.player_id[:8]} | {p.games_played:4d} | {p.win_rate * 100:5.1f}% | {p.avg_score:.1f}")

    def get_game_history(self) -> List[EvolutionRecord]:
        return self.game_history

    def _calculate_score(self, stats: PlayerStat) -> float:
        score = 0.0
        if stats.survived:
            score += 30
        if stats.win_rate > 0:
            score += 50
        if stats.total_predictions > 0:
            score += (stats.correct_predictions / stats.total_predictions) * 20
        return score
