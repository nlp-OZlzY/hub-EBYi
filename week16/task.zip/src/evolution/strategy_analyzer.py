import sys
from pathlib import Path
if not any(str(Path(__file__).parent.parent) in p for p in sys.path):
    sys.path.insert(0, str(Path(__file__).parent.parent))

from typing import Dict, List
from game_types import PlayerStat, Role, Team


class StrategyAnalyzer:
    def analyze_player_performance(self, stats: PlayerStat) -> float:
        score = 0.0

        if stats.survived:
            score += 20
        if stats.win_rate > 0:
            score += 30

        if stats.total_predictions > 0:
            accuracy = stats.correct_predictions / stats.total_predictions
            score += accuracy * 20

        if stats.votes_given > 0 and stats.votes_received < 3:
            score += 10

        return score

    def analyze_team_balance(self, records: List) -> Dict:
        werewolf_wins = len([r for r in records if r.winner == Team.WEREWOLF])
        total = len(records)

        return {
            "werewolf_win_rate": werewolf_wins / total if total > 0 else 0,
            "good_win_rate": (total - werewolf_wins) / total if total > 0 else 0,
            "is_balanced": abs(werewolf_wins / total - 0.5) < 0.2 if total > 0 else False
        }

    def generate_optimization_suggestions(self, records: List) -> Dict:
        balance = self.analyze_team_balance(records)
        suggestions = {}

        if not balance["is_balanced"]:
            if balance["werewolf_win_rate"] > 0.6:
                suggestions["werewolf"] = {
                    "nerf": True,
                    "suggestions": ["减少夜间信息", "增加好人阵营协作"]
                }
            else:
                suggestions["good"] = {
                    "nerf": True,
                    "suggestions": ["减少预言家信息", "增加狼人伪装能力"]
                }

        return suggestions
