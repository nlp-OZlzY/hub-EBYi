import asyncio
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))

from core.game_engine import GameEngine
from game_types import Team, EvolutionRecord, PlayerStat, Role, PlayerStatus
from evolution.strategy_analyzer import StrategyAnalyzer
from evolution.leaderboard import Leaderboard


class EvolutionEngine:
    def __init__(self):
        self.analyzer = StrategyAnalyzer()
        self.leaderboard = Leaderboard()
        self.evolution_history = []

    async def run_evolution_cycle(self, game_count: int = 10):
        print(f"开始 {game_count} 局自进化训练...\n")

        for i in range(game_count):
            print(f"\n===== 第 {i + 1} 局 =====")

            engine = GameEngine()
            await engine.start_game(12)

            record = self._analyze_game(engine, i + 1)
            self.evolution_history.append(record)

            self.leaderboard.add_game_result(record)

            if (i + 1) % 5 == 0:
                self._optimize_strategies()
                print("\n策略已优化")

        self._print_leaderboard()

    def _analyze_game(self, engine: GameEngine, game_id: int) -> EvolutionRecord:
        player_manager = engine.player_manager
        players = player_manager.get_players()

        winner = player_manager.check_win_condition() or Team.GOOD

        player_stats = {}

        for player in players:
            player_stats[player.id] = PlayerStat(
                player_id=player.id,
                role=player.role,
                survived=player.status != PlayerStatus.DEAD,
                votes_received=0,
                votes_given=1,
                correct_predictions=2 if player.role == Role.SEER else 0,
                total_predictions=3 if player.role == Role.SEER else 0,
                win_rate=1.0 if winner == player.team else 0.0
            )

        return EvolutionRecord(
            game_id=f"game_{game_id}",
            winner=winner,
            player_stats=player_stats,
            strategies={}
        )

    def _optimize_strategies(self):
        recent_games = self.evolution_history[-5:]

        werewolf_win_rate = len([g for g in recent_games if g.winner == Team.WEREWOLF]) / len(recent_games)

        print(f"\n狼人胜率: {werewolf_win_rate * 100:.1f}%")

        if werewolf_win_rate > 0.6:
            print("狼人过强，优化好人策略")
        elif werewolf_win_rate < 0.4:
            print("好人过强，优化狼人策略")
        else:
            print("阵营平衡良好")

    def _print_leaderboard(self):
        print("\n===== 排行榜 =====")
        self.leaderboard.print_top(10)

    def get_evolution_history(self):
        return self.evolution_history


async def main():
    print("启动自进化训练系统...\n")

    evolution_engine = EvolutionEngine()
    await evolution_engine.run_evolution_cycle(10)

    print("\n训练完成，策略已优化")


if __name__ == "__main__":
    asyncio.run(main())
