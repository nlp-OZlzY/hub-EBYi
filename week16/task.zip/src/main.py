import asyncio
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))

from core.game_engine import GameEngine


async def main():
    print("启动 AI 狼人杀游戏...\n")

    engine = GameEngine()
    await engine.start_game(12)

    print("\n游戏日志已保存到 logs/ 目录")


if __name__ == "__main__":
    asyncio.run(main())
