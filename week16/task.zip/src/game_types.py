from enum import Enum
from dataclasses import dataclass, field
from typing import Optional


class Role(Enum):
    WEREWOLF = "werewolf"
    SEER = "seer"
    WITCH = "witch"
    HUNTER = "hunter"
    GUARD = "guard"
    VILLAGER = "villager"


class Team(Enum):
    WEREWOLF = "werewolf"
    GOOD = "good"


class GamePhase(Enum):
    NIGHT_START = "night_start"
    WEREWOLF_KILL = "werewolf_kill"
    GUARD_PROTECT = "guard_protect"
    SEER_CHECK = "seer_check"
    WITCH_ACTION = "witch_action"
    HUNTER_ACTION = "hunter_action"
    DAY_START = "day_start"
    ANNOUNCE_DEATHS = "announce_deaths"
    DISCUSSION = "discussion"
    VOTING = "voting"
    VOTE_RESULT = "vote_result"
    GAME_OVER = "game_over"


class PlayerStatus(Enum):
    ALIVE = "alive"
    DEAD = "dead"
    PROTECTED = "protected"


@dataclass
class Player:
    id: str
    name: str
    role: Role
    team: Team
    status: PlayerStatus = PlayerStatus.ALIVE
    is_human: bool = False


@dataclass
class GameConfig:
    player_count: int = 12
    role_distribution: dict = field(default_factory=dict)
    enable_human: bool = False
    human_role: Optional[Role] = None


@dataclass
class NightAction:
    actor_id: str
    target_id: Optional[str]
    action: str


@dataclass
class VoteAction:
    voter_id: str
    target_id: Optional[str]


@dataclass
class GameEvent:
    type: str
    phase: GamePhase
    data: dict
    timestamp: int


@dataclass
class SpeechRecord:
    speaker_id: str
    content: str
    phase: GamePhase
    round: int


@dataclass
class PlayerStat:
    player_id: str
    role: Role
    survived: bool
    votes_received: int = 0
    votes_given: int = 0
    correct_predictions: int = 0
    total_predictions: int = 0
    win_rate: float = 0.0


@dataclass
class EvolutionRecord:
    game_id: str
    winner: Team
    player_stats: dict
    strategies: dict = field(default_factory=dict)
