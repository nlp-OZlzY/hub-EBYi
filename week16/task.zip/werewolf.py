"""
AI 狼人杀 - 多智能体协作与博弈系统
简化版 - 单文件可运行版本
"""

import asyncio
import random
import uuid
import os
from enum import Enum
from dataclasses import dataclass, field
from typing import Optional, List, Dict, Any
from datetime import datetime


class Role(Enum):
    WEREWOLF = "狼人"
    SEER = "预言家"
    WITCH = "女巫"
    HUNTER = "猎人"
    GUARD = "守卫"
    VILLAGER = "平民"


class Team(Enum):
    WEREWOLF = "狼人阵营"
    GOOD = "好人阵营"


class PlayerStatus(Enum):
    ALIVE = "存活"
    DEAD = "死亡"
    PROTECTED = "被守护"


@dataclass
class Player:
    id: str
    name: str
    role: Role
    team: Team
    status: PlayerStatus = PlayerStatus.ALIVE


class GameLogger:
    def __init__(self):
        os.makedirs("logs", exist_ok=True)
        self.log_file = open("logs/game.log", "w", encoding="utf-8")

    def log(self, message: str):
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        log_msg = f"[{timestamp}] {message}"
        print(log_msg)
        self.log_file.write(log_msg + "\n")
        self.log_file.flush()

    def close(self):
        self.log_file.close()


class WerewolfGame:
    def __init__(self, player_count: int = 12):
        self.players: List[Player] = []
        self.logger = GameLogger()
        self.current_round = 1
        self.winner = None
        self.player_count = player_count

    def setup_game(self):
        self.logger.log("=" * 50)
        self.logger.log("AI 狼人杀游戏开始")
        self.logger.log("=" * 50)

        role_distribution = self._get_role_distribution()
        roles = []
        for role, count in role_distribution.items():
            roles.extend([role] * count)

        random.shuffle(roles)

        for i in range(self.player_count):
            player = Player(
                id=str(uuid.uuid4())[:8],
                name=f"玩家{i+1}",
                role=roles[i],
                team=Team.WEREWOLF if roles[i] == Role.WEREWOLF else Team.GOOD
            )
            self.players.append(player)

        self.logger.log(f"\n游戏配置: {self.player_count} 人局")
        for player in self.players:
            self.logger.log(f"{player.name} - {player.role.value}")

    def _get_role_distribution(self) -> Dict[Role, int]:
        return {
            Role.WEREWOLF: 3,
            Role.SEER: 1,
            Role.WITCH: 1,
            Role.HUNTER: 1,
            Role.GUARD: 1,
            Role.VILLAGER: max(1, self.player_count - 7)
        }

    async def run_game(self):
        self.setup_game()

        while self.winner is None and self.current_round <= 20:
            self.logger.log(f"\n{'='*50}")
            self.logger.log(f"第 {self.current_round} 天")
            self.logger.log(f"{'='*50}")

            await self._night_phase()
            await self._day_phase()

            self._check_win_condition()
            self.current_round += 1

        self._end_game()

    async def _night_phase(self):
        self.logger.log("\n--- 夜晚阶段 ---")

        await self._werewolf_action()
        await self._guard_action()
        await self._seer_action()
        await self._witch_action()

    async def _werewolf_action(self):
        werewolves = [p for p in self.players if p.role == Role.WEREWOLF and p.status == PlayerStatus.ALIVE]
        if not werewolves:
            return

        targets = [p for p in self.players if p.team == Team.GOOD and p.status == PlayerStatus.ALIVE]
        if not targets:
            return

        target = random.choice(targets)
        self.logger.log(f"[狼人行动] 狼人选择了 {target.name}")

        target._night_target = True

    async def _guard_action(self):
        guards = [p for p in self.players if p.role == Role.GUARD and p.status == PlayerStatus.ALIVE]
        if not guards:
            return

        targets = [p for p in self.players if p.status == PlayerStatus.ALIVE]
        if not targets:
            return

        guard = guards[0]
        protected = random.choice(targets)
        protected.status = PlayerStatus.PROTECTED
        self.logger.log(f"[守卫行动] 守卫守护了 {protected.name}")

    async def _seer_action(self):
        seers = [p for p in self.players if p.role == Role.SEER and p.status == PlayerStatus.ALIVE]
        if not seers:
            return

        targets = [p for p in self.players if p.status == PlayerStatus.ALIVE and p != seers[0]]
        if not targets:
            return

        seer = seers[0]
        target = random.choice(targets)
        is_werewolf = target.team == Team.WEREWOLF
        self.logger.log(f"[预言家行动] 预言家查验了 {target.name}，结果是: {'狼人' if is_werewolf else '好人'}")

        seer._check_result = {target.name: is_werewolf}

    async def _witch_action(self):
        witches = [p for p in self.players if p.role == Role.WITCH and p.status == PlayerStatus.ALIVE]
        if not witches:
            return

        witch = witches[0]

        if not hasattr(self, '_witch_used_save'):
            self._witch_used_save = False
        if not hasattr(self, '_witch_used_poison'):
            self._witch_used_poison = False

        targeted_players = [p for p in self.players if hasattr(p, '_night_target')]

        if targeted_players and not self._witch_used_save:
            if random.random() > 0.3:
                target = targeted_players[0]
                if target.status == PlayerStatus.PROTECTED:
                    self.logger.log(f"[女巫行动] 女巫使用解药救了 {target.name}，但守卫已经守护")
                else:
                    target.status = PlayerStatus.ALIVE
                    if hasattr(target, '_night_target'):
                        del target._night_target
                    self._witch_used_save = True
                    self.logger.log(f"[女巫行动] 女巫使用解药救了 {target.name}")
            else:
                self.logger.log("[女巫行动] 女巫没有使用解药")

        if not self._witch_used_poison and random.random() > 0.7:
            targets = [p for p in self.players if p.status == PlayerStatus.ALIVE and p != witch]
            if targets:
                poison_target = random.choice(targets)
                poison_target.status = PlayerStatus.DEAD
                self._witch_used_poison = True
                self.logger.log(f"[女巫行动] 女巫毒杀了 {poison_target.name}")

    async def _day_phase(self):
        self.logger.log("\n--- 白天阶段 ---")

        await self._announce_deaths()
        await self._discussion_phase()
        await self._voting_phase()

    async def _announce_deaths(self):
        dead_players = [p for p in self.players if p.status == PlayerStatus.DEAD]
        protected_players = [p for p in self.players if p.status == PlayerStatus.PROTECTED]

        for p in protected_players:
            if hasattr(p, '_night_target'):
                del p._night_target
            p.status = PlayerStatus.ALIVE

        targeted_players = [p for p in self.players if hasattr(p, '_night_target') and p.status != PlayerStatus.DEAD]

        for p in targeted_players:
            p.status = PlayerStatus.DEAD

        newly_dead = [p for p in self.players if p.status == PlayerStatus.DEAD and not hasattr(p, '_announced')]

        if not newly_dead:
            self.logger.log("\n[宣布] 昨晚是平安夜")
        else:
            self.logger.log("\n[宣布] 昨晚死亡:")
            for p in newly_dead:
                self.logger.log(f"  - {p.name} ({p.role.value})")
                p._announced = True

    async def _discussion_phase(self):
        alive_players = [p for p in self.players if p.status == PlayerStatus.ALIVE]

        self.logger.log("\n[讨论阶段]")
        for player in alive_players:
            speech = self._generate_speech(player)
            self.logger.log(f"[{player.name}]: {speech}")

    def _generate_speech(self, player: Player) -> str:
        speeches = {
            Role.WEREWOLF: [
                "我是好人，我觉得我们应该多观察。",
                "我怀疑某人发言有问题。",
                "我是平民，没有太多信息。"
            ],
            Role.SEER: [
                "我是预言家，我有一些信息。",
                "我查验过一个人，是好人。",
                "大家相信我，我是真预言家。"
            ],
            Role.WITCH: [
                "我是女巫，药还在。",
                "我觉得我们应该谨慎投票。"
            ],
            Role.HUNTER: [
                "我是猎人，不要乱票我。",
                "我会带走一个狼人。"
            ],
            Role.GUARD: [
                "我守了一个人，希望是平安夜。",
                "我是好人阵营的。"
            ],
            Role.VILLAGER: [
                "我是平民，没有特殊信息。",
                "我觉得我们应该多分析发言。",
                "我跟着大家投票。"
            ]
        }

        return random.choice(speeches.get(player.role, ["我是好人。"]))

    async def _voting_phase(self):
        alive_players = [p for p in self.players if p.status == PlayerStatus.ALIVE]

        self.logger.log("\n[投票阶段]")
        votes = {}

        for voter in alive_players:
            candidates = [p for p in alive_players if p != voter]
            if candidates:
                target = random.choice(candidates)
                votes[voter.name] = target.name
                self.logger.log(f"[{voter.name}] 投票给 {target.name}")

        vote_counts = {}
        for target in votes.values():
            vote_counts[target] = vote_counts.get(target, 0) + 1

        if vote_counts:
            max_votes = max(vote_counts.values())
            eliminated = [name for name, count in vote_counts.items() if count == max_votes]

            if len(eliminated) == 1:
                eliminated_player = next(p for p in self.players if p.name == eliminated[0])
                eliminated_player.status = PlayerStatus.DEAD
                self.logger.log(f"\n[投票结果] {eliminated_player.name}({eliminated_player.role.value}) 被投票出局")
            else:
                self.logger.log(f"\n[投票结果] 平票，无人出局")

    def _check_win_condition(self):
        alive_werewolves = [p for p in self.players if p.team == Team.WEREWOLF and p.status == PlayerStatus.ALIVE]
        alive_good = [p for p in self.players if p.team == Team.GOOD and p.status == PlayerStatus.ALIVE]

        if len(alive_werewolves) == 0:
            self.winner = Team.GOOD
        elif len(alive_werewolves) >= len(alive_good):
            self.winner = Team.WEREWOLF

    def _end_game(self):
        self.logger.log(f"\n{'='*50}")
        if self.winner:
            self.logger.log(f"游戏结束! 获胜方: {self.winner.value}")
        else:
            self.logger.log("游戏结束! 平局")

        self.logger.log("\n最终状态:")
        for player in self.players:
            status = "存活" if player.status == PlayerStatus.ALIVE else "死亡"
            self.logger.log(f"  {player.name} - {player.role.value} - {status}")

        self.logger.close()


async def main():
    game = WerewolfGame(player_count=12)
    await game.run_game()


if __name__ == "__main__":
    asyncio.run(main())
