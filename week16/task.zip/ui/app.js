const socket = io('http://localhost:3001');

const startBtn = document.getElementById('startBtn');
const pauseBtn = document.getElementById('pauseBtn');
const speedBtn = document.getElementById('speedBtn');
const gameStatus = document.getElementById('gameStatus');
const currentPhase = document.getElementById('currentPhase');
const currentRound = document.getElementById('currentRound');
const werewolfCount = document.getElementById('werewolfCount');
const goodCount = document.getElementById('goodCount');
const playerGrid = document.getElementById('playerGrid');
const gameLog = document.getElementById('gameLog');
const speechLog = document.getElementById('speechLog');

let gameSpeed = 1;
let isPaused = false;

startBtn.addEventListener('click', () => {
  socket.emit('start_game', { playerCount: 12 });
  startBtn.disabled = true;
  pauseBtn.disabled = false;
});

pauseBtn.addEventListener('click', () => {
  isPaused = !isPaused;
  pauseBtn.textContent = isPaused ? '继续' : '暂停';
});

speedBtn.addEventListener('click', () => {
  gameSpeed = gameSpeed === 1 ? 2 : gameSpeed === 2 ? 4 : 1;
  speedBtn.textContent = `速度: ${gameSpeed}x`;
});

socket.on('game_status', (data) => {
  gameStatus.textContent = data.status === 'starting' ? '游戏开始中...' : '游戏进行中';
});

socket.on('game_init', (data) => {
  renderPlayers(data.players);
  currentRound.textContent = `第 ${data.round} 天`;
  updateCounts(data.players);
});

socket.on('phase_update', (data) => {
  currentPhase.textContent = data.phase;
  addLogEntry(data.phase, data.message);
});

socket.on('speech', (data) => {
  addSpeechEntry(data.speaker, data.content);
});

socket.on('player_death', (data) => {
  updatePlayerStatus(data.playerId, 'dead');
  addLogEntry('死亡', `${data.playerName}(${data.role}) 死亡`);
});

socket.on('game_over', (data) => {
  gameStatus.textContent = `游戏结束 - ${data.winner} 获胜`;
  startBtn.disabled = false;
  pauseBtn.disabled = true;
});

function renderPlayers(players) {
  playerGrid.innerHTML = '';
  players.forEach(player => {
    const card = document.createElement('div');
    card.className = `player-card ${player.isAlive ? 'alive' : 'dead'}`;
    card.id = `player-${player.id}`;
    card.innerHTML = `
      <div class="name">${player.name}</div>
      <div class="role">${getRoleName(player.role)}</div>
      <div class="status-icon">${player.isAlive ? '✅' : '❌'}</div>
    `;
    playerGrid.appendChild(card);
  });
}

function updatePlayerStatus(playerId, status) {
  const card = document.getElementById(`player-${playerId}`);
  if (card) {
    card.className = `player-card ${status}`;
    card.querySelector('.status-icon').textContent = status === 'alive' ? '✅' : '❌';
  }
}

function updateCounts(players) {
  const alive = players.filter(p => p.isAlive);
  const werewolves = alive.filter(p => p.role === 'werewolf').length;
  const good = alive.length - werewolves;
  werewolfCount.textContent = werewolves;
  goodCount.textContent = good;
}

function addLogEntry(event, message) {
  const entry = document.createElement('div');
  entry.className = 'log-entry';
  entry.innerHTML = `
    <span class="time">${new Date().toLocaleTimeString()}</span>
    <span class="event">[${event}]</span>
    <span>${message}</span>
  `;
  gameLog.appendChild(entry);
  gameLog.scrollTop = gameLog.scrollHeight;
}

function addSpeechEntry(speaker, content) {
  const entry = document.createElement('div');
  entry.className = 'speech-entry';
  entry.innerHTML = `
    <span class="speaker">${speaker}</span>
    <div class="content">${content}</div>
  `;
  speechLog.appendChild(entry);
  speechLog.scrollTop = speechLog.scrollHeight;
}

function getRoleName(role) {
  const roleNames = {
    werewolf: '狼人',
    seer: '预言家',
    witch: '女巫',
    hunter: '猎人',
    guard: '守卫',
    villager: '平民'
  };
  return roleNames[role] || role;
}
