"""CLIP multimodal encoder for text and image encoding."""

from typing import List, Optional

import torch
from PIL import Image
from transformers import CLIPModel, CLIPProcessor


class CLIPEncoder:
    """CLIP encoder for text and image embeddings (1024-dim)."""

    DIM = 1024

    def __init__(self, model_path: Optional[str] = None):
        if model_path is None:
            from utils.config_loader import get_config
            config = get_config()
            model_path = config.models.clip.url

        self.device = "cuda" if torch.cuda.is_available() else "cpu"
        self.model = CLIPModel.from_pretrained(model_path).to(self.device)
        self.processor = CLIPProcessor.from_pretrained(model_path)

    def encode_text(self, texts: List[str], batch_size: int = 32, max_length: int = 77) -> List[List[float]]:
        """Encode texts into 1024-dim vectors."""
        if not texts:
            return []

        # Filter out empty texts
        texts = [t if t else " " for t in texts]

        all_embeddings = []
        for i in range(0, len(texts), batch_size):
            batch = texts[i:i + batch_size]
            inputs = self.processor(
                text=batch,
                return_tensors="pt",
                padding=True,
                truncation=True,
                max_length=max_length,
            )
            inputs = {k: v.to(self.device) for k, v in inputs.items()}

            with torch.no_grad():
                outputs = self.model.get_text_features(**inputs)
                embeddings = outputs / outputs.norm(dim=-1, keepdim=True)

            all_embeddings.extend(embeddings.cpu().numpy().tolist())

        return all_embeddings

    def encode_image(self, image_paths: List[str], batch_size: int = 32) -> List[List[float]]:
        """Encode images into 1024-dim vectors."""
        if not image_paths:
            return []

        all_embeddings = []
        for i in range(0, len(image_paths), batch_size):
            batch_paths = image_paths[i:i + batch_size]
            images = [Image.open(path).convert("RGB") for path in batch_paths]

            inputs = self.processor(images=images, return_tensors="pt")
            inputs = {k: v.to(self.device) for k, v in inputs.items()}

            with torch.no_grad():
                outputs = self.model.get_image_features(**inputs)
                embeddings = outputs / outputs.norm(dim=-1, keepdim=True)

            all_embeddings.extend(embeddings.cpu().numpy().tolist())

        return all_embeddings

    def encode_text_single(self, text: str) -> List[float]:
        """Encode a single text."""
        return self.encode_text([text])[0]

    def encode_image_single(self, image_path: str) -> List[float]:
        """Encode a single image."""
        return self.encode_image([image_path])[0]