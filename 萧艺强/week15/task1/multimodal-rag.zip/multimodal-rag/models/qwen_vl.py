"""Qwen-VL model for multimodal answer generation via OpenAI client."""

import base64
import os
from dataclasses import dataclass
from typing import List, Optional

from openai import OpenAI


@dataclass
class Source:
    """Source citation for an answer."""
    file_name: str
    file_path: str
    page: Optional[int]
    text: str
    image_path: Optional[str] = None


@dataclass
class GenerationResult:
    """Result from Qwen-VL generation."""
    answer: str
    sources: List[Source]


class QwenVL:
    """Qwen-VL multimodal model via OpenAI-compatible API."""

    def __init__(
        self,
        model_name: str = "qwen-vl-plus",
        api_key: Optional[str] = None,
        base_url: str = "https://dashscope.aliyuncs.com/compatible-mode/v1",
    ):
        self.model_name = model_name
        self.api_key = api_key or os.environ.get("OPENAI_API_KEY", "")
        self.base_url = base_url
        self.client = OpenAI(api_key=self.api_key, base_url=self.base_url)

    def generate(
        self,
        query: str,
        context_texts: List[str],
        context_images: Optional[List[str]] = None,
    ) -> GenerationResult:
        """Generate answer from query and context."""
        context_images = context_images or []

        # Build messages
        content = [
            {
                "type": "text",
                "text": f"Based on the following information, answer the question.\n\nQuestion: {query}\n\nContext:\n"
            }
        ]

        # Add context texts
        context_str = "\n".join([f"[Text {i+1}]: {text}" for i, text in enumerate(context_texts)])
        content.append({
            "type": "text",
            "text": context_str,
        })

        # Add context images (base64 encoded)
        for img_path in context_images:
            if os.path.exists(img_path):
                with open(img_path, "rb") as f:
                    img_base64 = base64.b64encode(f.read()).decode("utf-8")
                content.append({
                    "type": "image_url",
                    "image_url": {
                        "url": f"data:image/jpeg;base64,{img_base64}"
                    }
                })

        messages = [
            {
                "role": "user",
                "content": content,
            }
        ]

        # Call OpenAI-compatible API
        try:
            response = self.client.chat.completions.create(
                model=self.model_name,
                messages=messages,
                max_tokens=512,
            )
            answer = response.choices[0].message.content
        except Exception as e:
            answer = f"Error: {str(e)}"

        # Build sources from context
        sources = []
        for i, text in enumerate(context_texts[:5]):
            sources.append(Source(
                file_name="",
                file_path="",
                page=None,
                text=text[:200] + "..." if len(text) > 200 else text,
                image_path=context_images[i] if i < len(context_images) else None,
            ))

        return GenerationResult(answer=answer, sources=sources)

    def generate_with_images(
        self,
        query: str,
        images: List[str],
        texts: List[str],
    ) -> GenerationResult:
        """Generate answer with explicit image and text context."""
        context_images = images[:10]
        context_texts = texts[:20]

        return self.generate(query, context_texts, context_images)