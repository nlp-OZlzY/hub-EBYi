"""BGE text encoder for semantic search."""

from typing import List, Optional

import torch
from sentence_transformers import SentenceTransformer


class BGEEncoder:
    """BGE text encoder for generating 512-dim embeddings."""

    DIM = 512

    def __init__(self, model_path: Optional[str] = None):
        if model_path is None:
            from utils.config_loader import get_config
            config = get_config()
            model_path = config.models.bge.url

        self.model = SentenceTransformer(model_path, device="cuda" if torch.cuda.is_available() else "cpu")

    def encode(self, texts: List[str], batch_size: int = 32) -> List[List[float]]:
        """Encode texts into 512-dim vectors."""
        if not texts:
            return []

        embeddings = self.model.encode(texts, batch_size=batch_size, normalize_embeddings=True)
        return embeddings.tolist()

    def encode_single(self, text: str) -> List[float]:
        """Encode a single text."""
        return self.encode([text])[0]