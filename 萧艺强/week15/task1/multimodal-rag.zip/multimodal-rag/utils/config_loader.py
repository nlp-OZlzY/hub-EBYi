"""Configuration loader for multimodal RAG system."""

import os
from dataclasses import dataclass
from typing import Optional

import yaml


@dataclass
class BGEConfig:
    url: str


@dataclass
class CLIPConfig:
    url: str


@dataclass
class MilvusConfig:
    uri: str
    token: str


@dataclass
class KafkaConfig:
    servers: str
    topic: str
    group_id: str


@dataclass
class StorageConfig:
    uploads_dir: str
    processed_dir: str


@dataclass
class ModelsConfig:
    bge: BGEConfig
    clip: CLIPConfig


@dataclass
class DatabaseConfig:
    milvus: MilvusConfig


@dataclass
class Config:
    models: ModelsConfig
    database: DatabaseConfig
    kafka: KafkaConfig
    storage: StorageConfig

    @classmethod
    def load(cls, config_path: str = "config.yaml") -> "Config":
        """Load configuration from YAML file."""
        with open(config_path, "r", encoding="utf-8") as f:
            data = yaml.safe_load(f)

        models_cfg = data.get("models", {})
        database_cfg = data.get("database", {})
        kafka_cfg = data.get("kafka", {})
        storage_cfg = data.get("storage", {})

        return cls(
            models=ModelsConfig(
                bge=BGEConfig(url=models_cfg.get("bge", {}).get("url", "")),
                clip=CLIPConfig(url=models_cfg.get("clip", {}).get("url", "")),
            ),
            database=DatabaseConfig(
                milvus=MilvusConfig(
                    uri=database_cfg.get("milvus", {}).get("uri", ""),
                    token=database_cfg.get("milvus", {}).get("token", ""),
                )
            ),
            kafka=KafkaConfig(
                servers=kafka_cfg.get("servers", "localhost:9092"),
                topic=kafka_cfg.get("topic", "rag-data"),
                group_id=kafka_cfg.get("group_id", "rag-consumer-group"),
            ),
            storage=StorageConfig(
                uploads_dir=storage_cfg.get("uploads_dir", "./uploads"),
                processed_dir=storage_cfg.get("processed_dir", "./processed"),
            ),
        )


_config: Optional[Config] = None


def get_config() -> Config:
    """Get global config instance."""
    global _config
    if _config is None:
        _config = Config.load()
    return _config


def reload_config(config_path: str = "config.yaml") -> Config:
    """Reload config from file."""
    global _config
    _config = Config.load(config_path)
    return _config