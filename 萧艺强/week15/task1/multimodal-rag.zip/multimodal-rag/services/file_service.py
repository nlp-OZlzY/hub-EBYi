"""File service for upload and management."""

import os
import shutil
from typing import Optional, List

from database.kafka_client import KafkaProducerClient
from orm_model import add_file, get_all_files, get_file_by_id, delete_file as db_delete_file
from utils.config_loader import get_config


class FileService:
    """Service for file upload and management."""

    def __init__(self):
        config = get_config()
        self.uploads_dir = config.storage.uploads_dir
        self.kafka_producer = KafkaProducerClient()
        os.makedirs(self.uploads_dir, exist_ok=True)

    def upload_file(self, uploaded_file, destination_filename: Optional[str] = None) -> dict:
        """Upload a file and send to processing queue."""
        if destination_filename is None:
            destination_filename = uploaded_file.name

        # Save to uploads directory
        destination_path = os.path.join(self.uploads_dir, destination_filename)

        # Handle duplicate filenames
        counter = 1
        base, ext = os.path.splitext(destination_filename)
        while os.path.exists(destination_path):
            destination_filename = f"{base}_{counter}{ext}"
            destination_path = os.path.join(self.uploads_dir, destination_filename)
            counter += 1

        # Save file
        with open(destination_path, "wb") as f:
            shutil.copyfileobj(uploaded_file, f)

        # Add to database (returns dict now)
        file_dict = add_file(filename=destination_filename, filepath=destination_path)

        # Send to Kafka
        self.kafka_producer.send_file_message(
            file_id=file_dict["id"],
            filename=file_dict["filename"],
            filepath=file_dict["filepath"],
        )

        return file_dict

    def get_all_files(self) -> List[dict]:
        """Get all files."""
        return get_all_files()

    def get_file(self, file_id: int) -> Optional[dict]:
        """Get a file by ID."""
        file_record = get_file_by_id(file_id)
        if file_record:
            return file_record  # Already a dict
        return None

    def delete_file(self, file_id: int, delete_from_disk: bool = True) -> bool:
        """Delete a file record and optionally the file on disk."""
        file_record = get_file_by_id(file_id)
        if not file_record:
            return False

        # Delete file on disk
        if delete_from_disk and os.path.exists(file_record["filepath"]):
            os.remove(file_record["filepath"])

        # Delete from database
        return db_delete_file(file_id)


# Global instance
_file_service: Optional[FileService] = None


def get_file_service() -> FileService:
    """Get global file service instance."""
    global _file_service
    if _file_service is None:
        _file_service = FileService()
    return _file_service