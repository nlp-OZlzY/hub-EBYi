"""Retrieval service for multimodal search."""

from typing import List, Optional

from database.milvus_client import MilvusClient, SearchResult
from models.clip_encoder import CLIPEncoder


class RetrievalService:
    """Service for multimodal retrieval from vector database."""

    def __init__(self):
        self.milvus_client = MilvusClient()
        self.clip_encoder = CLIPEncoder()

    def search(
        self,
        query: str,
        top_k: int = 5,
        use_text: bool = True,
        use_image: bool = False,
    ) -> List[SearchResult]:
        """Search for relevant chunks using text and/or image query."""
        # Encode query
        query_vector = self.clip_encoder.encode_text_single(query)

        # Search
        if use_image:
            results = self.milvus_client.search_hybrid(
                clip_text_query=query_vector,
                clip_image_query=None,  # TODO: support image queries
                top_k=top_k,
            )
        else:
            results = self.milvus_client.search_clip_text(query_vector, top_k)

        return results

    def search_text(self, query: str, top_k: int = 5) -> List[SearchResult]:
        """Search using BGE text encoding."""
        from models.bge_encoder import BGEEncoder
        bge_encoder = BGEEncoder()
        query_vector = bge_encoder.encode_single(query)
        return self.milvus_client.search_text(query_vector, top_k)

    def search_hybrid(
        self,
        query: str,
        top_k: int = 5,
        text_weight: float = 0.6,
    ) -> List[SearchResult]:
        """Hybrid search combining multiple retrieval methods."""
        # Get CLIP text results
        clip_results = self.search(query, top_k * 2)

        # Get BGE text results
        bge_results = self.search_text(query, top_k * 2)

        # Fuse results
        score_map = {}
        for r in clip_results:
            key = (r.file_id, r.text[:50])
            score_map[key] = {"result": r, "clip_score": 1 - r.score}

        for r in bge_results:
            key = (r.file_id, r.text[:50])
            if key in score_map:
                score_map[key]["bge_score"] = 1 - r.score
            else:
                score_map[key] = {"result": r, "clip_score": 0, "bge_score": 1 - r.score}

        fused = []
        for key, data in score_map.items():
            r = data["result"]
            clip_s = data.get("clip_score", 0)
            bge_s = data.get("bge_score", 0)
            fused_score = text_weight * clip_s + (1 - text_weight) * bge_s
            fused.append(SearchResult(
                text=r.text,
                file_id=r.file_id,
                file_name=r.file_name,
                file_path=r.file_path,
                score=1 - fused_score,
                image_paths=r.image_paths,
            ))

        fused.sort(key=lambda x: x.score, reverse=True)
        return fused[:top_k]


# Global instance
_retrieval_service: Optional[RetrievalService] = None


def get_retrieval_service() -> RetrievalService:
    """Get global retrieval service instance."""
    global _retrieval_service
    if _retrieval_service is None:
        _retrieval_service = RetrievalService()
    return _retrieval_service