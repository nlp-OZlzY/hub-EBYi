"""RAG service for answer generation."""

import logging
import traceback
from dataclasses import dataclass
from typing import List, Optional

from database.milvus_client import SearchResult
from models.qwen_vl import QwenVL, Source, GenerationResult
from services.retrieval_service import RetrievalService

logger = logging.getLogger(__name__)


@dataclass
class AnswerResult:
    """Result containing answer and sources."""
    answer: str
    sources: List[Source]


class RAGService:
    """RAG service combining retrieval and generation."""

    def __init__(self, retrieval_service: Optional[RetrievalService] = None, qwen_vl: Optional[QwenVL] = None):
        self.retrieval_service = retrieval_service or RetrievalService()
        self.qwen_vl = qwen_vl or QwenVL()

    def answer(self, query: str, top_k: int = 5) -> AnswerResult:
        """Answer a query using RAG."""
        try:
            # Retrieve relevant chunks
            results = self.retrieval_service.search_hybrid(query, top_k=top_k)

            if not results:
                return AnswerResult(
                    answer="抱歉，没有找到相关信息来回答您的问题。",
                    sources=[],
                )

            # Prepare context
            texts = [r.text for r in results]
            images = []
            for r in results:
                if r.image_paths:
                    images.extend(r.image_paths[:3])  # Limit images per source

            # Generate answer
            generation_result = self.qwen_vl.generate(query, texts, images[:10])

            # Build sources
            sources = []
            for r in results[:top_k]:
                sources.append(Source(
                    file_name=r.file_name,
                    file_path=r.file_path,
                    page=None,
                    text=r.text[:200] + "..." if len(r.text) > 200 else r.text,
                    image_path=r.image_paths[0] if r.image_paths else None,
                ))

            return AnswerResult(
                answer=generation_result.answer,
                sources=sources,
            )
        except Exception as e:
            logger.error(f"Error in RAG answer: {e}")
            logger.error(f"Traceback: {traceback.format_exc()}")
            return AnswerResult(
                answer=f"抱歉，生成回答时出错：{str(e)}",
                sources=[],
            )

    def answer_with_sources(self, query: str, top_k: int = 5) -> AnswerResult:
        """Answer with explicit source citations."""
        return self.answer(query, top_k)


# Global instance
_rag_service: Optional[RAGService] = None


def get_rag_service() -> RAGService:
    """Get global RAG service instance."""
    global _rag_service
    if _rag_service is None:
        _rag_service = RAGService()
    return _rag_service