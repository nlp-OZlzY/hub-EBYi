"""Chat page for Streamlit."""

import logging
import traceback

import streamlit as st
from services.rag_service import get_rag_service

logger = logging.getLogger(__name__)


def render_chat_page():
    """Render the chat page."""
    st.set_page_config(page_title="图文问答", page_icon="💬")

    st.title("💬 图文问答")

    # Initialize chat history
    if "messages" not in st.session_state:
        st.session_state.messages = []

    # Display chat history
    for message in st.session_state.messages:
        with st.chat_message(message["role"]):
            st.markdown(message["content"])
            if "sources" in message and message["sources"]:
                with st.expander("📎 参考来源"):
                    for i, source in enumerate(message["sources"], 1):
                        st.markdown(f"**来源 {i}**: {source['file_name']}")
                        st.text(f"内容: {source['text'][:150]}...")
                        if source.get("image_path"):
                            st.image(source["image_path"], width=200)

    # Chat input
    query = st.chat_input("请输入您的问题...")

    if query:
        # Add user message
        st.session_state.messages.append({"role": "user", "content": query})
        with st.chat_message("user"):
            st.markdown(query)

        # Generate response
        with st.chat_message("assistant"):
            with st.spinner("思考中..."):
                try:
                    rag_service = get_rag_service()
                    result = rag_service.answer(query, top_k=5)

                    st.markdown(result.answer)
                    sources_data = []

                    if result.sources:
                        with st.expander("📎 参考来源"):
                            for i, source in enumerate(result.sources, 1):
                                st.markdown(f"**来源 {i}**: {source.file_name}")
                                st.text(f"内容: {source.text[:200]}...")
                                if source.image_path:
                                    st.image(source.image_path, width=200)
                                sources_data.append({
                                    "file_name": source.file_name,
                                    "text": source.text,
                                    "image_path": source.image_path,
                                })

                    st.session_state.messages.append({
                        "role": "assistant",
                        "content": result.answer,
                        "sources": sources_data,
                    })

                except Exception as e:
                    logger.error(f"Error generating answer: {e}")
                    logger.error(f"Traceback: {traceback.format_exc()}")
                    st.error(f"生成回答失败: {str(e)}")


if __name__ == "__main__":
    render_chat_page()