"""File upload page for Streamlit."""

import logging
import traceback

import streamlit as st
from services.file_service import get_file_service

logger = logging.getLogger(__name__)


def render_upload_page():
    """Render the file upload page."""
    st.set_page_config(page_title="文件上传", page_icon="📁")

    st.title("📁 文件上传")

    file_service = get_file_service()

    # Display existing files
    st.subheader("已上传文件")

    files = file_service.get_all_files()
    if files:
        for file in files:
            col1, col2, col3, col4 = st.columns([3, 4, 2, 1])
            with col1:
                st.text(file["filename"])
            with col2:
                st.text(file["filepath"])
            with col3:
                state_color = {
                    "pending": "🕐",
                    "processing": "⚙️",
                    "done": "✅",
                    "failed": "❌",
                }.get(file["filestate"], "❓")
                st.write(f"{state_color} {file['filestate']}")
            with col4:
                if st.button("🗑️", key=f"delete_{file['id']}"):
                    if file_service.delete_file(file["id"]):
                        st.success(f"已删除: {file['filename']}")
                        st.rerun()
    else:
        st.info("暂无已上传文件")

    st.divider()

    # File upload
    st.subheader("上传新文件")
    uploaded_file = st.file_uploader(
        "选择PDF文件",
        type=["pdf"],
        help="支持PDF文件上传",
    )

    if uploaded_file is not None:
        if st.button("上传", type="primary"):
            with st.spinner("上传中..."):
                try:
                    file_record = file_service.upload_file(uploaded_file)
                    st.success(f"文件上传成功！ID: {file_record['id']}")
                    st.info("文件已加入解析队列，请在处理完成后进行问答。")
                    st.rerun()
                except Exception as e:
                    logger.error(f"文件上传失败: {e}")
                    logger.error(f"Traceback: {traceback.format_exc()}")
                    st.error(f"上传失败: {str(e)}")


if __name__ == "__main__":
    render_upload_page()