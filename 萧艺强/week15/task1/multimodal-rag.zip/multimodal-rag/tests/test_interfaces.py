"""Test cases for multimodal RAG system interfaces."""

import os
import sys
import tempfile
import unittest
from unittest.mock import MagicMock, patch

# Add project root to path
sys.path.insert(0, os.path.dirname(__file__))


class TestFileUploadAPI(unittest.TestCase):
    """Test file upload API."""

    def setUp(self):
        """Set up test fixtures."""
        self.upload_dir = tempfile.mkdtemp()

    @patch("services.file_service.get_config")
    @patch("database.kafka_client.KafkaProducerClient")
    @patch("orm_model.get_session")
    def test_upload_file(self, mock_session, mock_kafka, mock_config):
        """Test file upload functionality."""
        from services.file_service import FileService
        from orm_model import File

        # Mock config
        mock_config.return_value.storage.uploads_dir = self.upload_dir

        # Mock Kafka
        mock_kafka_instance = MagicMock()
        mock_kafka.return_value = mock_kafka_instance

        # Mock session
        mock_session_instance = MagicMock()
        mock_session.return_value = mock_session_instance

        # Create file service
        service = FileService()

        # Create a test file
        test_content = b"test file content"
        mock_file = MagicMock()
        mock_file.name = "test.pdf"
        mock_file.read = lambda: test_content

        # Test upload
        with patch("builtins.open", MagicMock()):
            with patch("shutil.copyfileobj", MagicMock()):
                result = service.upload_file(mock_file)

        self.assertIsNotNone(result)
        mock_kafka_instance.send_file_message.assert_called()


class TestKafkaProducer(unittest.TestCase):
    """Test Kafka producer."""

    @patch("database.kafka_client.KafkaProducer")
    @patch("utils.config_loader.get_config")
    def test_send_message(self, mock_config, mock_kafka_producer):
        """Test sending message to Kafka."""
        from database.kafka_client import KafkaProducerClient

        mock_config.return_value.kafka.servers = "localhost:9092"
        mock_config.return_value.kafka.topic = "test-topic"

        mock_producer = MagicMock()
        mock_kafka_producer.return_value = mock_producer

        client = KafkaProducerClient()
        result = client.send_file_message(
            file_id=1,
            filename="test.pdf",
            filepath="/path/to/test.pdf",
        )

        self.assertTrue(result)
        mock_producer.send.assert_called_once()


class TestMilvusClient(unittest.TestCase):
    """Test Milvus client."""

    @patch("pymilvus.connections.connect")
    @patch("pymilvus.utility.has_collection")
    @patch("utils.config_loader.get_config")
    def test_connect(self, mock_config, mock_has_collection, mock_connect):
        """Test Milvus connection."""
        from database.milvus_client import MilvusClient

        mock_config.return_value.database.milvus.uri = "http://localhost:19530"
        mock_config.return_value.database.milvus.token = "test_token"

        client = MilvusClient()
        client.connect()

        mock_connect.assert_called_once()

    @patch("pymilvus.connections.connect")
    @patch("pymilvus.utility.has_collection")
    @patch("utils.config_loader.get_config")
    def test_insert_chunks(self, mock_config, mock_has_collection, mock_connect):
        """Test inserting chunks into Milvus."""
        from database.milvus_client import MilvusClient, ChunkData

        mock_config.return_value.database.milvus.uri = "http://localhost:19530"
        mock_config.return_value.database.milvus.token = "test_token"
        mock_has_collection.return_value = True

        mock_collection = MagicMock()
        mock_connect.return_value = None

        with patch.object(MilvusClient, "_get_collection", return_value=mock_collection):
            client = MilvusClient()
            client.connect()

            chunks = [
                ChunkData(
                    text="test text",
                    text_vector=[0.1] * 512,
                    clip_text_vector=[0.2] * 1024,
                    clip_image_vector=[0.3] * 1024,
                    file_id=1,
                    file_name="test.pdf",
                    file_path="/path/test.pdf",
                )
            ]

            result = client.insert(chunks)
            self.assertTrue(result)
            mock_collection.insert.assert_called_once()
            mock_collection.flush.assert_called_once()


class TestRetrievalService(unittest.TestCase):
    """Test retrieval service."""

    @patch("models.clip_encoder.CLIPEncoder")
    @patch("database.milvus_client.MilvusClient")
    def test_search(self, mock_milvus, mock_clip):
        """Test search functionality."""
        from services.retrieval_service import RetrievalService
        from database.milvus_client import SearchResult

        mock_clip_instance = MagicMock()
        mock_clip_instance.encode_text_single.return_value = [0.1] * 1024
        mock_clip.return_value = mock_clip_instance

        mock_milvus_instance = MagicMock()
        mock_milvus_instance.search_clip_text.return_value = [
            SearchResult(
                text="test result",
                file_id=1,
                file_name="test.pdf",
                file_path="/path/test.pdf",
                score=0.9,
            )
        ]
        mock_milvus.return_value = mock_milvus_instance

        service = RetrievalService()
        results = service.search("test query", top_k=5)

        self.assertEqual(len(results), 1)
        self.assertEqual(results[0].text, "test result")


class TestRAGService(unittest.TestCase):
    """Test RAG service."""

    @patch("services.retrieval_service.RetrievalService")
    @patch("models.qwen_vl.QwenVL")
    def test_answer(self, mock_qwen, mock_retrieval):
        """Test RAG answer generation."""
        from services.rag_service import RAGService, AnswerResult
        from models.qwen_vl import GenerationResult

        mock_retrieval_instance = MagicMock()
        mock_retrieval_instance.search_hybrid.return_value = [
            MagicMock(
                text="context text",
                file_id=1,
                file_name="test.pdf",
                file_path="/path/test.pdf",
                image_paths=[],
            )
        ]
        mock_retrieval.return_value = mock_retrieval_instance

        mock_qwen_instance = MagicMock()
        mock_qwen_instance.generate.return_value = GenerationResult(
            answer="Generated answer",
            sources=[],
        )
        mock_qwen.return_value = mock_qwen_instance

        service = RAGService()
        result = service.answer("test query", top_k=5)

        self.assertIsInstance(result, AnswerResult)
        self.assertEqual(result.answer, "Generated answer")


class TestBGEEncoder(unittest.TestCase):
    """Test BGE encoder."""

    @patch("sentence_transformers.SentenceTransformer")
    def test_encode(self, mock_transformer):
        """Test text encoding."""
        from models.bge_encoder import BGEEncoder

        mock_model = MagicMock()
        mock_model.encode.return_value = [[0.1] * 512]
        mock_transformer.return_value = mock_model

        encoder = BGEEncoder(model_path="mock/path")
        result = encoder.encode(["test text"])

        self.assertEqual(len(result), 1)
        self.assertEqual(len(result[0]), 512)


class TestCLIPEncoder(unittest.TestCase):
    """Test CLIP encoder."""

    @patch("transformers.CLIPModel.from_pretrained")
    @patch("transformers.CLIPProcessor.from_pretrained")
    def test_encode_text(self, mock_processor, mock_model):
        """Test CLIP text encoding."""
        from models.clip_encoder import CLIPEncoder

        mock_clip_model = MagicMock()
        mock_clip_model.get_text_features.return_value = MagicMock(
            cpu=MagicMock(return_value=MagicMock(tolist=[[0.1] * 1024])),
            norm=MagicMock(return_value=MagicMock()),
        )
        mock_model.return_value = mock_clip_model
        mock_processor.return_value = MagicMock()

        encoder = CLIPEncoder(model_path="mock/path")
        result = encoder.encode_text(["test text"])

        self.assertEqual(len(result), 1)
        self.assertEqual(len(result[0]), 1024)


class TestMinerUParser(unittest.TestCase):
    """Test MinerU parser."""

    def test_parse_result_dataclass(self):
        """Test ParseResult structure."""
        from offline_process.mineru_parser import ParseResult

        result = ParseResult(
            markdown_files=["/path/to/file1.md", "/path/to/file2.md"],
            image_files=["/path/to/img1.png"],
            output_dir="/output",
        )

        self.assertEqual(len(result.markdown_files), 2)
        self.assertEqual(len(result.image_files), 1)
        self.assertEqual(result.output_dir, "/output")


class TestChunker(unittest.TestCase):
    """Test chunker."""

    def test_chunk_dataclass(self):
        """Test Chunk structure."""
        from offline_process.chunker import Chunk

        chunk = Chunk(
            text="test chunk content",
            image_paths=["/path/to/image.png"],
            page_number=1,
            file_name="test.pdf",
            file_path="/path/test.pdf",
        )

        self.assertEqual(chunk.text, "test chunk content")
        self.assertEqual(len(chunk.image_paths), 1)
        self.assertEqual(chunk.page_number, 1)


class TestFileService(unittest.TestCase):
    """Test file service."""

    @patch("services.file_service.KafkaProducerClient")
    @patch("services.file_service.get_config")
    def test_get_all_files(self, mock_config, mock_kafka):
        """Test getting all files."""
        from services.file_service import FileService

        mock_config.return_value.storage.uploads_dir = tempfile.mkdtemp()

        service = FileService()
        files = service.get_all_files()

        self.assertIsInstance(files, list)


if __name__ == "__main__":
    unittest.main()