## ⽬录

⽬录1. 什么是dorycli1.1. 下载dorycli2. dorycli的基础使⽤2.1. 获取dorycli帮助2.2. 配置dorycli⾃动完成3. 使⽤dorycli把项⽬定义从旧DORY迁移到新DORY

## 1. 什么是dorycli

dorycil是⼀个DORY的命令⾏管理⼯具，可以⽤于批量调整DORY中的项⽬设置

dorycli⼦命令概览:

Dory-Engine的命令⾏管理⼯具，可⽤于安装或管理Dory-Engine  
Usage:  
dorycli  
dorycli [command]  
Examples:  
# ⼦命令结构  
dorycli  
─ admin # 配置项管理，需要管理员权限  
── apply # 把⽂件、⽬录或者stdin中的配置参数应⽤到项⽬配置信息中，需要项⽬维护  
者权限  
delete # 删除项⽬配置信息，需要项⽬维护者权限  
get # 获取项⽬配置信息，需要项⽬维护者权限  
console # 项⽬控制台管理，需要项⽬维护者权限  
apply # 把⽂件、⽬录或者stdin中的配置参数应⽤到Dory-Engine的配置项中，需  
要项⽬维护者权限  
delete # 删除项⽬配置项，需要项⽬维护者权限  
get # 获取项⽬配置项，需要项⽬维护者权限  
def # 管理项⽬定义  
apply # 应⽤项⽬定义配置项  
clone # 把项⽬定义的模块复制到其他环境  
delete # 删除项⽬定义中的模块  
get # 获取项⽬定义  
patch # 通过补丁更新项⽬定义  
install # 把Dory-Engine安装在kubernetes集群或者docker主机上  
check # 检查安装的前提条件  
─ ha # 创建⾼可⽤kubernetes集群的负载均衡器  
├── print # 打印⾼可⽤kubernetes集群负载均衡器安装配置的YAML⽂件  
script # 创建负载均衡器的配置⽂件、docker-compose⽂件以及⾼可⽤  
kubernetes集群的初始化配置⽂件  
print # 打印安装配置YAML⽂件  
pull # 拉取并构建相关容器镜像

run # ⾃动安装Dory-Engine  
script # ⼿动安装Dory-Engine  
login # 登录到Dory-Engine  
logout # 从Dory-Engine注销  
pipeline # 获取或者执⾏流⽔线  
execute # 执⾏流⽔线  
get # 获取流⽔线  
project # 管理项⽬  
execute # 执⾏项⽬批处理任务  
get # 获取项⽬信息  
run # 管理流⽔线运⾏记录  
abort # 终⽌执⾏中的流⽔线  
get # 查看流⽔线运⾏记录  
logs # 查看流⽔线运⾏⽇志  
version # 显示版本信息

## 1.1. 下载dorycli

下载dorycli:

下载地址: https://github.com/dory-engine/dorycli/releases/tag/v1.6.6

windows版本: dorycli-v1.6.6-windows-amd64.tgz

linux(x86)版本: dorycli-v1.6.6-linux-amd64.tgz

linux(arm)版本: dorycli-v1.6.6-linux-arm64.tgz

o macos(x86)版本: dorycli-v1.6.6-darwin-amd64.tgz

o macos(arm)版本: dorycli-v1.6.6-darwin-arm64.tgz

把dorycli放到操作系统的PATH路径下即可

## 2. dorycli的基础使⽤

## 2.1. 获取dorycli帮助

dorycli以及⼦命令的帮助可以通过 --help 参数获取

# 获取login⼦命令的使⽤帮助

dorycli [⼦命令] --help

## 2.2. 配置dorycli⾃动完成

dorycli⽀持通过按键盘的tab键显示⾃动补全⼦命令和命令参数，请通过completion⼦命令获取开启帮助

dorycli⾃动完成⽀持linux、windows、macos等各种操作系统

# 获取⾃动完成帮助  
dorycli completion --help

## 3. 使⽤dorycli把项⽬定义从旧DORY迁移到新DORY

```shell
# dorycli要管理DORY中的项⽬配置，⾸先需要使⽤DORY的账号密码进⾏登陆
# 登录到旧DORY，登录过程会⾃动在DORY中创建accessToken，改命令设置accessToken的有效
期为365天
# 执⾏该命令后会提示⽤户输⼊密码
# 成功登陆后，会⽣成⼀个登录配置⽂件 ~/.dorycli/config.yaml
dorycli login --server-url https://dory.devops.itdev.local --insecure --
username xxx --expire-days 365
# 以YAML格式输出旧DORY的所有项⽬定义
# 项⽬定义包括:
# buildDefs: 模块构建定义
# packageDefs: 模块镜像打包定义
# dockerIgnoreDefs: 镜像打包忽略定义
# deployContainerDefs: 模块容器部署定义
# istioDefs: 模块服务⽹格定义
# istioGatewayDef: 模块服务⽹格⽹关定义
# pipelineDef: 流⽔线定义
# customOpsDefs: OPS操作定义
# opsBatchDefs: OPS批处理定义
# customStepDef: ⾃定义步骤模块定义
# artifactDefs: 模块制品打包定义 [部署应⽤到虚拟机才需要]
# deployArtifactDefs: 模块制品部署定义 [部署应⽤到虚拟机才需要]
# 把输出的项⽬定义复制到⽂本编辑器进⾏修改
dorycli def get ${项⽬名} all -o yaml
# 根据新DORY的实际情况，使⽤⽂本编辑器修改旧DORY的项⽬定义信息
# 重点关注以下配置:
# 搜索envName: 环境名，旧DORY使⽤test，新DORY使⽤gditsit
# 搜索harbor: harbor镜像名称，旧DORY使⽤harbor.devops.itdev.local，新DORY使⽤
harbor.gditdev.local
# 搜索nodePort: 容器部署模块的nodePort配置，根据新DORY的实际模块nodePort进⾏调整
# 以YAML格式输出旧DORY的各个环境的组件配置
# 把输出的项⽬定义的配置复制到⽂本编辑器进⾏就改
dorycli def get ${项⽬名} all -o yaml
# 以YAML格式输出旧DORY的test环境的组件配置
# 把输出的环境组件配置复制到⽂本编辑器进⾏修改
# 注意，管理控制台需要maintainer账号权限才能查看和操作
dorycli console get ${项⽬名} component --envs test -o yaml
# 根据新DORY的实际情况，使⽤⽂本编辑器修改旧DORY的环境组件配置
# 重点关注以下配置:
```

```shell
# 搜索nodePort: 组件的nodePort配置，根据新DORY的实际组件nodePort进⾏调整
# 打开新DORY的项⽬定义界⾯: https://dory.gditdev.local/#/cicd/projectDef/${项⽬
名}
# 清除以下项⽬定义: 模块构建定义 / 模块镜像打包定义 / 模块容器部署定义 / 模块服务⽹格定
义 / 模块服务⽹格⽹关定义
# 打开新DORY的项⽬管理控制台: https://dory.gditdev.local/#/console/project/${项
⽬名}
# 如果旧DORY除了develop流⽔线还有其他流⽔线，请在项⽬管理控制台创建对应的流⽔线
# dorycli退出旧DORY登录
dorycli logout
# 登录到新DORY，登录过程会⾃动在DORY中创建accessToken，改命令设置accessToken的有效
期为365天
# 执⾏该命令后会提示⽤户输⼊密码
# 成功登陆后，会⽣成⼀个登录配置⽂件 ~/.dorycli/config.yaml
dorycli login --server-url https://dory.gditdev.local --insecure --
username xxx --expire-days 365
# 把项⽬定义应⽤到新DORY，如果有错误请检查YAML⽂件
dorycli def apply -f ${项⽬定义YAML⽂件}
# 把环境组件配置应⽤到新DORY，如果有错误请检查YAML⽂件
# 注意，管理控制台需要maintainer账号权限才能查看和操作
dorycli console apply -f ${环境组件配置YAML⽂件}
```