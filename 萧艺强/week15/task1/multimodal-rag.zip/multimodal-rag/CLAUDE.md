# 多模态RAG系统

提供包含多个图文混排PDF文档的知识库，支持基于文本和图像的问答。评估答案准确性、完整性和信息来源可解释性。

## 核心能力

- 多模态信息理解：同时理解自然语言问题和知识库中的图像、文本内容
- 跨模态检索：从PDF文档中检索相关图像、图表、文本段落
- 图文关联推理：融合图像与文本进行深层逻辑推理
- 可解释答案生成：清晰指出信息来源（PDF名称、页码）

## 项目结构

```
multimodal-rag/
├── config.yaml                 # 配置文件
├── requirements.txt            # Python依赖
├── web.py                      # Streamlit主入口
├── orm_model.py                # SQLite ORM（files表）
├── utils/
│   └── config_loader.py       # YAML配置加载器
├── database/
│   ├── kafka_client.py        # Kafka生产/消费者
│   └── milvus_client.py       # Milvus向量库客户端
├── models/
│   ├── bge_encoder.py         # BGE文本编码器（512维）
│   ├── clip_encoder.py        # CLIP多模态编码器（1024维）
│   └── qwen_vl.py             # Qwen-VL云端API答案生成
├── offline_process/
│   ├── mineru_parser.py       # MinerU解析封装
│   ├── chunker.py             # Markdown分块
│   └── worker.py              # Kafka消费主进程
├── services/
│   ├── file_service.py        # 文件上传服务
│   ├── retrieval_service.py   # 多模态检索服务
│   └── rag_service.py         # RAG答案生成
├── streamlit_setup/
│   ├── web_page_upload.py     # 文件上传页面
│   └── web_page_chat.py        # 图文对话页面
├── tests/
│   └── test_interfaces.py     # 单元测试
├── uploads/                   # 用户上传文件
└── processed/                  # MinerU解析输出
```

## 技术栈

| 组件 | 技术 |
|------|------|
| 编程语言 | Python |
| 前端框架 | Streamlit |
| 文本嵌入 | BGE (BAAI/bge-small-zh-v1.5) |
| 多模态检索 | CLIP (jinaai/jina-clip-v2) |
| 答案生成 | Qwen-VL Plus (DashScope云端API) |
| 文档解析 | MinerU |
| 向量数据库 | Milvus (Zilliz Cloud) |
| 关系数据库 | SQLite |
| 消息队列 | Kafka |

## 启动方式

```bash
# 1. 安装依赖
pip install -r requirements.txt

# 2. 配置环境变量
export OPENAI_API_KEY="your_api_key"  # Qwen-VL云端API密钥

# 3. 配置config.yaml
# - bge/clip模型路径
# - milvus连接信息
# - kafka服务器地址

# 4. 启动前端（终端1）
streamlit run web.py

# 5. 启动离线处理器（终端2）
python offline_process/worker.py
```

## 测试

```bash
# 运行单元测试
python -m pytest tests/test_interfaces.py -v
```

## 数据流

### 文件上传流程
```
用户上传PDF → 保存到uploads/ → 写入SQLite → 发送消息到Kafka
```

### 离线解析流程
```
Kafka消费 → MinerU解析PDF → Markdown分块 → BGE/CLIP编码 → Milvus存储
```

### 问答流程
```
用户提问 → CLIP编码 → Milvus检索 → Qwen-VL生成答案 → 返回答案+来源
```

## 配置 (config.yaml)

```yaml
models:
  bge:
    url: "E:\\ai\\weekcode\\models\\BAAI\\bge-small-zh-v1.5"
  clip:
    url: "E:\\ai\\weekcode\\models\\jinaai\\jina-clip-v2"

database:
  milvus:
    uri: "https://in03-4c8809fa55937ab.serverless.aws-eu-central-1.cloud.zilliz.com"
    token: "your_milvus_token"

kafka:
  servers: "localhost:9092"
  topic: "rag-data"
  group_id: "rag-consumer-group"

storage:
  uploads_dir: "./uploads"
  processed_dir: "./processed"
```

## 数据库设计

### SQLite - files表

| 字段 | 类型 | 描述 |
|------|------|------|
| id | INTEGER | 主键 |
| filename | TEXT | 文件名 |
| filepath | TEXT | 完整路径 |
| filestate | TEXT | 处理状态(pending/processing/done/failed) |

### Milvus - rag_data_new集合

| 字段 | 类型 | 维度 | 描述 |
|------|------|------|------|
| text_vector | FLOAT_VECTOR | 512 | BGE编码向量 |
| clip_text_vector | FLOAT_VECTOR | 1024 | CLIP文本编码向量 |
| clip_image_vector | FLOAT_VECTOR | 1024 | CLIP图片编码向量 |
| text | VARCHAR | - | Chunk完整内容 |
| file_id | INT | - | 文件ID |
| file_name | VARCHAR | - | 文件名 |
| file_path | VARCHAR | - | 文件路径 |

## 环境变量

| 变量名 | 描述 |
|--------|------|
| OPENAI_API_KEY | Qwen-VL云端API密钥 |