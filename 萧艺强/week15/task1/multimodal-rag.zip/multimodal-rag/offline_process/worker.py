"""Kafka consumer worker for offline document processing."""

import logging
import os
import traceback
from typing import Optional

from database.kafka_client import KafkaConsumerClient
from database.milvus_client import MilvusClient, ChunkData
from models.bge_encoder import BGEEncoder
from models.clip_encoder import CLIPEncoder
from offline_process.mineru_parser import MinerUParser
from offline_process.chunker import Chunker
from orm_model import update_file_state, get_session
from utils.config_loader import get_config

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


class DocumentProcessWorker:
    """Worker that consumes Kafka messages and processes documents."""

    def __init__(self):
        self.config = get_config()
        self.kafka_consumer = KafkaConsumerClient()
        self.milvus_client = MilvusClient()
        self.bge_encoder = BGEEncoder()
        self.clip_encoder = CLIPEncoder()
        self.mineru_parser = MinerUParser()
        self.chunker = Chunker()

    def process_message(self, message: dict) -> bool:
        """Process a single file message."""
        file_id = message.get("file_id")
        filename = message.get("filename")
        filepath = message.get("filepath")

        if not all([file_id, filename, filepath]):
            logger.error(f"Invalid message: {message}")
            return False

        logger.info(f"Processing file: {file_id} - {filename}")

        try:
            # Update state to processing
            update_file_state(file_id, "processing")

            # Parse PDF with MinerU
            logger.info(f"Parsing {filepath} with MinerU...")
            parse_result = self.mineru_parser.parse(filepath, file_id)

            if not parse_result.markdown_files:
                logger.warning(f"No markdown files generated for {filename}")
                update_file_state(file_id, "failed")
                return False

            # Process each markdown file
            all_chunks = []
            for md_file in parse_result.markdown_files:
                logger.info(f"Chunking {md_file}...")
                chunks = self.chunker.chunk_markdown_file(
                    md_file_path=md_file,
                    file_id=file_id,
                    file_name=filename,
                    file_path=filepath,
                )

                # Get unique images for this file
                file_images = [img for img in parse_result.image_files
                              if os.path.dirname(img) == os.path.dirname(md_file)]

                for chunk in chunks:
                    # Associate images with chunks
                    chunk.image_paths = [img for img in file_images
                                         if self._image_belongs_to_chunk(chunk, img)]

                    all_chunks.append(chunk)

            logger.info(f"Generated {len(all_chunks)} chunks")

            # Encode chunks
            logger.info("Encoding chunks...")
            chunk_data_list = []
            failed_count = 0
            for chunk in all_chunks:
                try:
                    # Skip empty chunks
                    if not chunk.text or not chunk.text.strip():
                        continue

                    # BGE encoding
                    text_vec = self.bge_encoder.encode_single(chunk.text[:10000])

                    # CLIP text encoding
                    clip_text_vec = self.clip_encoder.encode_text_single(chunk.text[:10000])

                    # CLIP image encoding (use first image or zero vector)
                    if chunk.image_paths:
                        clip_img_vec = self.clip_encoder.encode_image_single(chunk.image_paths[0])
                    else:
                        clip_img_vec = [0.0] * 1024

                    chunk_data_list.append(ChunkData(
                        text=chunk.text,
                        text_vector=text_vec,
                        clip_text_vector=clip_text_vec,
                        clip_image_vector=clip_img_vec,
                        file_id=chunk.file_id,
                        file_name=chunk.file_name,
                        file_path=chunk.file_path,
                        image_paths=chunk.image_paths,
                    ))
                except Exception as e:
                    logger.warning(f"Failed to encode chunk: {e}")
                    failed_count += 1
                    continue

            logger.info(f"Encoded {len(chunk_data_list)} chunks, {failed_count} failed")

            # Insert into Milvus
            logger.info("Inserting into Milvus...")
            self.milvus_client.insert(chunk_data_list)

            # Update state to done
            update_file_state(file_id, "done")
            logger.info(f"Successfully processed file: {filename}")
            return True

        except Exception as e:
            logger.error(f"Error processing file {filename}: {e}")
            logger.error(f"Traceback: {traceback.format_exc()}")
            update_file_state(file_id, "failed")
            return False

    def _image_belongs_to_chunk(self, chunk, image_path) -> bool:
        """Check if an image belongs to a chunk based on position."""
        # Simple heuristic: image path contains chunk text keywords
        chunk_keywords = chunk.text[:50].split()[:3]
        image_name = os.path.basename(image_path).lower()
        return any(kw.lower() in image_name for kw in chunk_keywords if len(kw) > 3)

    def run(self):
        """Start the worker loop."""
        logger.info("Starting document process worker...")
        logger.info(f"Kafka servers: {self.config.kafka.servers}")
        logger.info(f"Kafka topic: {self.config.kafka.topic}")

        try:
            for message in self.kafka_consumer.consume():
                logger.info(f"Received message: {message}")
                self.process_message(message)
        except KeyboardInterrupt:
            logger.info("Worker stopped by user")
        finally:
            self.kafka_consumer.close()
            self.milvus_client.disconnect()
            logger.info("Worker shutdown complete")


def main():
    """Main entry point."""
    worker = DocumentProcessWorker()
    worker.run()


if __name__ == "__main__":
    main()