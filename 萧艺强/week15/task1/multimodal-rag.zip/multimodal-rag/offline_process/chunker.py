"""Text chunking for markdown documents."""

import os
import re
from dataclasses import dataclass
from typing import List, Optional


@dataclass
class Chunk:
    """A chunk of text with optional images and metadata."""
    text: str
    image_paths: List[str]
    page_number: int
    file_name: str
    file_path: str


class Chunker:
    """Splits markdown content into chunks."""

    MAX_CHUNK_LENGTH = 500  # characters

    def chunk_markdown_file(
        self,
        md_file_path: str,
        file_id: int,
        file_name: str,
        file_path: str,
    ) -> List[Chunk]:
        """Parse a markdown file and split into chunks."""
        with open(md_file_path, "r", encoding="utf-8") as f:
            content = f.read()

        # Extract page number from filename if possible
        page_number = self._extract_page_number(md_file_path)

        # Find image references in the markdown
        image_map = self._extract_image_references(content, md_file_path)

        # Split by headings
        sections = self._split_by_headings(content)

        chunks = []
        for section in sections:
            if not section.strip():
                continue

            # Find images that belong to this section
            section_images = self._get_images_for_section(section, image_map)

            # Further split if too long
            sub_chunks = self._split_long_text(section)
            for sub_chunk in sub_chunks:
                if sub_chunk.strip():
                    chunks.append(Chunk(
                        text=sub_chunk.strip(),
                        image_paths=section_images,
                        page_number=page_number,
                        file_name=file_name,
                        file_path=file_path,
                    ))

        return chunks

    def _extract_page_number(self, md_file_path: str) -> int:
        """Extract page number from markdown filename."""
        filename = os.path.basename(md_file_path)
        match = re.search(r"page[_\-]?(\d+)", filename, re.IGNORECASE)
        if match:
            return int(match.group(1))
        return 0

    def _extract_image_references(self, md_content: str, md_file_path: str) -> dict:
        """Extract image references from markdown content."""
        image_map = {}
        md_dir = os.path.dirname(md_file_path)

        # Pattern for markdown image: ![alt](path)
        pattern = r"!\[([^\]]*)\]\(([^)]+)\)"

        for match in re.finditer(pattern, md_content):
            alt_text = match.group(1)
            img_path = match.group(2)

            # Resolve relative paths
            if not os.path.isabs(img_path):
                img_path = os.path.abspath(os.path.join(md_dir, img_path))

            # Use alt text or position as key
            image_map[alt_text] = img_path

        return image_map

    def _get_images_for_section(self, section: str, image_map: dict) -> List[str]:
        """Get images that appear in this section."""
        images = []
        for alt_text, img_path in image_map.items():
            if alt_text in section and os.path.exists(img_path):
                images.append(img_path)
        return images

    def _split_by_headings(self, content: str) -> List[str]:
        """Split content by headings."""
        # Split by h1, h2, h3 headings
        pattern = r"\n#{1,3}\s+"
        parts = re.split(pattern, content)

        result = []
        for part in parts:
            if part.strip():
                result.append(part)

        return result if result else [content]

    def _split_long_text(self, text: str) -> List[str]:
        """Split long text into smaller chunks."""
        if len(text) <= self.MAX_CHUNK_LENGTH:
            return [text]

        chunks = []
        paragraphs = text.split("\n\n")

        current_chunk = ""
        for para in paragraphs:
            if len(current_chunk) + len(para) + 2 <= self.MAX_CHUNK_LENGTH:
                current_chunk += ("\n\n" if current_chunk else "") + para
            else:
                if current_chunk:
                    chunks.append(current_chunk)
                # Start new chunk with this paragraph if it's short enough
                if len(para) <= self.MAX_CHUNK_LENGTH:
                    current_chunk = para
                else:
                    # Split long paragraph by sentences
                    sentences = para.split(". ")
                    current_chunk = ""
                    for sent in sentences:
                        if len(current_chunk) + len(sent) + 2 <= self.MAX_CHUNK_LENGTH:
                            current_chunk += ("." if current_chunk else "") + sent
                        else:
                            if current_chunk:
                                chunks.append(current_chunk)
                            current_chunk = sent
                    if current_chunk:
                        current_chunk = ""

        if current_chunk:
            chunks.append(current_chunk)

        return chunks if chunks else [text]