"""MinerU PDF parser wrapper."""

import logging
import os
import subprocess
import traceback
from dataclasses import dataclass
from typing import List, Optional

from utils.config_loader import get_config

logger = logging.getLogger(__name__)


@dataclass
class ParseResult:
    """Result from MinerU parsing."""
    markdown_files: List[str]
    image_files: List[str]
    output_dir: str


class MinerUParser:
    """Wrapper for MinerU PDF parsing."""

    def __init__(self, output_dir: Optional[str] = None):
        config = get_config()
        self.output_dir = output_dir or config.storage.processed_dir
        os.makedirs(self.output_dir, exist_ok=True)

    def parse(self, pdf_path: str, file_id: Optional[int] = None) -> ParseResult:
        """Parse a PDF file using MinerU."""
        if not os.path.exists(pdf_path):
            raise FileNotFoundError(f"PDF file not found: {pdf_path}")

        # Create output subdirectory for this file
        if file_id is not None:
            file_output_dir = os.path.join(self.output_dir, f"file_{file_id}")
        else:
            import uuid
            file_output_dir = os.path.join(self.output_dir, str(uuid.uuid4()))

        os.makedirs(file_output_dir, exist_ok=True)

        # Run MinerU CLI
        cmd = [
            "mineru",
            "-p", pdf_path,
            "-o", file_output_dir,
            "-b", "pipeline",
        ]

        logger.info(f"Running MinerU: {' '.join(cmd)}")
        try:
            result = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                timeout=600,  # 10 minutes timeout
            )
            if result.returncode != 0:
                logger.error(f"MinerU failed: {result.stderr}")
                logger.error(f"Traceback: {traceback.format_exc()}")
                raise RuntimeError(f"MinerU parsing failed: {result.stderr}")
            logger.info(f"MinerU output: {result.stdout}")
        except subprocess.TimeoutExpired:
            logger.error(f"MinerU timed out: {traceback.format_exc()}")
            raise RuntimeError("MinerU parsing timed out")
        except FileNotFoundError:
            logger.error(f"MinerU not found: {traceback.format_exc()}")
            raise FileNotFoundError("MinerU CLI not found. Please install MinerU.")

        # Find output markdown and image files
        markdown_files = []
        image_files = []

        for root, dirs, files in os.walk(file_output_dir):
            for file in files:
                full_path = os.path.join(root, file)
                if file.endswith(".md"):
                    markdown_files.append(full_path)
                elif file.lower().endswith((".png", ".jpg", ".jpeg", ".gif", ".bmp")):
                    image_files.append(full_path)

        logger.info(f"Parsed {len(markdown_files)} markdown files and {len(image_files)} images")

        return ParseResult(
            markdown_files=markdown_files,
            image_files=image_files,
            output_dir=file_output_dir,
        )