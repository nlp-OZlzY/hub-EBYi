"""SQLite ORM model for file management."""

import os
from typing import Optional

from sqlalchemy import create_engine, Column, Integer, String, Text
from sqlalchemy.orm import declarative_base, sessionmaker, Session

Base = declarative_base()


class File(Base):
    """File record in SQLite database."""
    __tablename__ = "files"

    id = Column(Integer, primary_key=True, autoincrement=True)
    filename = Column(String(500), nullable=False)
    filepath = Column(String(1000), nullable=False)
    filestate = Column(String(50), default="pending")  # pending, processing, done, failed

    def to_dict(self):
        return {
            "id": self.id,
            "filename": self.filename,
            "filepath": self.filepath,
            "filestate": self.filestate,
        }


_db_path = os.path.join(os.path.dirname(__file__), "db.db")
_engine = create_engine(f"sqlite:///{_db_path}", echo=False)
_SessionLocal = sessionmaker(bind=_engine)


def init_db():
    """Initialize database tables."""
    Base.metadata.create_all(_engine)


def get_session() -> Session:
    """Get a new database session."""
    return _SessionLocal()


def add_file(filename: str, filepath: str, session: Optional[Session] = None) -> dict:
    """Add a new file record. Returns detached dict with file info."""
    should_close = session is None
    if session is None:
        session = get_session()
    file_record = File(filename=filename, filepath=filepath, filestate="pending")
    session.add(file_record)
    session.commit()
    # Refresh to load all attributes, then detach
    session.refresh(file_record)
    result = file_record.to_dict()
    if should_close:
        session.close()
    return result


def get_file_by_id(file_id: int, session: Optional[Session] = None) -> Optional[dict]:
    """Get file by ID as dict."""
    should_close = session is None
    if session is None:
        session = get_session()
    file_record = session.query(File).filter(File.id == file_id).first()
    if file_record:
        result = file_record.to_dict()
        if should_close:
            session.close()
        return result
    if should_close:
        session.close()
    return None


def get_all_files(session: Optional[Session] = None) -> list:
    """Get all file records as dicts."""
    should_close = session is None
    if session is None:
        session = get_session()
    files = session.query(File).all()
    result = [f.to_dict() for f in files]
    if should_close:
        session.close()
    return result


def update_file_state(file_id: int, new_state: str, session: Optional[Session] = None) -> bool:
    """Update file processing state."""
    if session is None:
        session = get_session()
    file_record = session.query(File).filter(File.id == file_id).first()
    if file_record:
        file_record.filestate = new_state
        session.commit()
        return True
    return False


def delete_file(file_id: int, session: Optional[Session] = None) -> bool:
    """Delete a file record."""
    if session is None:
        session = get_session()
    file_record = session.query(File).filter(File.id == file_id).first()
    if file_record:
        session.delete(file_record)
        session.commit()
        return True
    return False


# Initialize database on module import
init_db()