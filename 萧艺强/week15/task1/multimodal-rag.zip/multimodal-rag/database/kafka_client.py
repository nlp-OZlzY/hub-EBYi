"""Kafka producer and consumer for file processing messages."""

import json
import logging
import traceback
from typing import Optional, Generator

from kafka import KafkaProducer, KafkaConsumer
from kafka.errors import KafkaError

from utils.config_loader import get_config

logger = logging.getLogger(__name__)


class KafkaProducerClient:
    """Kafka producer for sending file messages."""

    def __init__(self, bootstrap_servers: Optional[str] = None, topic: Optional[str] = None):
        config = get_config()
        self.bootstrap_servers = bootstrap_servers or config.kafka.servers
        self.topic = topic or config.kafka.topic
        self._producer: Optional[KafkaProducer] = None

    def _get_producer(self) -> KafkaProducer:
        if self._producer is None:
            self._producer = KafkaProducer(
                bootstrap_servers=self.bootstrap_servers,
                value_serializer=lambda v: json.dumps(v).encode("utf-8"),
                acks="all",
                retries=3,
            )
        return self._producer

    def send_file_message(self, file_id: int, filename: str, filepath: str) -> bool:
        """Send file processing message to Kafka."""
        message = {
            "file_id": file_id,
            "filename": filename,
            "filepath": filepath,
            "action": "parse",
        }
        try:
            producer = self._get_producer()
            future = producer.send(self.topic, value=message)
            future.get(timeout=10)
            logger.info(f"Sent message to Kafka: {message}")
            return True
        except KafkaError as e:
            logger.error(f"Failed to send message to Kafka: {e}")
            logger.error(f"Traceback: {traceback.format_exc()}")
            return False

    def close(self):
        """Close the producer."""
        if self._producer:
            self._producer.close()
            self._producer = None


class KafkaConsumerClient:
    """Kafka consumer for receiving file messages."""

    def __init__(
        self,
        bootstrap_servers: Optional[str] = None,
        topic: Optional[str] = None,
        group_id: Optional[str] = None,
    ):
        config = get_config()
        self.bootstrap_servers = bootstrap_servers or config.kafka.servers
        self.topic = topic or config.kafka.topic
        self.group_id = group_id or config.kafka.group_id
        self._consumer: Optional[KafkaConsumer] = None

    def _get_consumer(self) -> KafkaConsumer:
        if self._consumer is None:
            self._consumer = KafkaConsumer(
                self.topic,
                bootstrap_servers=self.bootstrap_servers,
                group_id=self.group_id,
                value_deserializer=lambda v: json.loads(v.decode("utf-8")),
                auto_offset_reset="latest",
                enable_auto_commit=True,
            )
        return self._consumer

    def consume(self) -> Generator[dict, None, None]:
        """Consume messages from Kafka."""
        consumer = self._get_consumer()
        logger.info(f"Starting Kafka consumer for topic: {self.topic}")
        for message in consumer:
            yield message.value

    def close(self):
        """Close the consumer."""
        if self._consumer:
            self._consumer.close()
            self._consumer = None


# Global instances
_producer: Optional[KafkaProducerClient] = None
_consumer: Optional[KafkaConsumerClient] = None


def get_kafka_producer() -> KafkaProducerClient:
    """Get global Kafka producer instance."""
    global _producer
    if _producer is None:
        _producer = KafkaProducerClient()
    return _producer


def get_kafka_consumer() -> KafkaConsumerClient:
    """Get global Kafka consumer instance."""
    global _consumer
    if _consumer is None:
        _consumer = KafkaConsumerClient()
    return _consumer