"""Milvus vector database client for multimodal RAG."""

import logging
from dataclasses import dataclass
from typing import List, Optional, Tuple

from pymilvus import (
    connections,
    Collection,
    FieldSchema,
    CollectionSchema,
    DataType,
    utility,
)

from utils.config_loader import get_config

logger = logging.getLogger(__name__)


@dataclass
class ChunkData:
    """A chunk of document with vectors."""
    text: str
    text_vector: List[float]        # BGE 512-dim
    clip_text_vector: List[float]   # CLIP text 1024-dim
    clip_image_vector: List[float]  # CLIP image 1024-dim
    file_id: int
    file_name: str
    file_path: str
    image_paths: Optional[List[str]] = None


@dataclass
class SearchResult:
    """Search result with score."""
    text: str
    file_id: int
    file_name: str
    file_path: str
    score: float
    image_paths: Optional[List[str]] = None


class MilvusClient:
    """Milvus client for rag_data_new collection."""

    COLLECTION_NAME = "rag_data_new"
    DIM_BGE = 512
    DIM_CLIP = 1024

    def __init__(self, uri: Optional[str] = None, token: Optional[str] = None):
        config = get_config()
        self.uri = uri or config.database.milvus.uri
        self.token = token or config.database.milvus.token
        self._collection: Optional[Collection] = None
        self._connected = False

    def connect(self):
        """Connect to Milvus/Zilliz Cloud."""
        if self._connected:
            return

        alias = "default"
        connections.connect(
            alias=alias,
            uri=self.uri,
            token=self.token,
            secure=True,
        )
        self._connected = True
        logger.info(f"Connected to Milvus: {self.uri}")

    def disconnect(self):
        """Disconnect from Milvus."""
        if self._connected:
            connections.disconnect(alias="default")
            self._connected = False
            self._collection = None
            logger.info("Disconnected from Milvus")

    def _get_collection(self) -> Collection:
        """Get or create the collection."""
        if not self._connected:
            self.connect()

        if self._collection is not None:
            return self._collection

        if utility.has_collection(self.COLLECTION_NAME):
            self._collection = Collection(self.COLLECTION_NAME)
            self._collection.load()
            return self._collection

        # Create new collection
        return self._create_collection()

    def _create_collection(self) -> Collection:
        """Create the rag_data_new collection with schema."""
        fields = [
            FieldSchema(name="id", dtype=DataType.INT64, is_primary=True, auto_id=True),
            FieldSchema(name="text_vector", dtype=DataType.FLOAT_VECTOR, dim=self.DIM_BGE),
            FieldSchema(name="clip_text_vector", dtype=DataType.FLOAT_VECTOR, dim=self.DIM_CLIP),
            FieldSchema(name="clip_image_vector", dtype=DataType.FLOAT_VECTOR, dim=self.DIM_CLIP),
            FieldSchema(name="text", dtype=DataType.VARCHAR, max_length=65535),
            FieldSchema(name="file_id", dtype=DataType.INT64),
            FieldSchema(name="file_name", dtype=DataType.VARCHAR, max_length=500),
            FieldSchema(name="file_path", dtype=DataType.VARCHAR, max_length=1000),
        ]

        schema = CollectionSchema(fields=fields, description="Multimodal RAG data")
        collection = Collection(name=self.COLLECTION_NAME, schema=schema)

        # Create indexes
        index_params = {"metric_type": "COSINE", "index_type": "HNSW"}
        collection.create_index(field_name="text_vector", index_params=index_params)
        collection.create_index(field_name="clip_text_vector", index_params=index_params)
        collection.create_index(field_name="clip_image_vector", index_params=index_params)

        collection.load()
        self._collection = collection
        logger.info(f"Created collection: {self.COLLECTION_NAME}")
        return collection

    def insert(self, chunks: List[ChunkData]) -> bool:
        """Insert chunks into Milvus."""
        if not chunks:
            return True

        collection = self._get_collection()

        data = [
            [chunk.text_vector for chunk in chunks],
            [chunk.clip_text_vector for chunk in chunks],
            [chunk.clip_image_vector for chunk in chunks],
            [chunk.text for chunk in chunks],
            [chunk.file_id for chunk in chunks],
            [chunk.file_name for chunk in chunks],
            [chunk.file_path for chunk in chunks],
        ]

        result = collection.insert(data)
        collection.flush()
        logger.info(f"Inserted {len(chunks)} chunks into Milvus")
        return True

    def search_text(
        self,
        query_vector: List[float],
        top_k: int = 5,
        output_fields: Optional[List[str]] = None,
    ) -> List[SearchResult]:
        """Search by BGE text vector."""
        if output_fields is None:
            output_fields = ["text", "file_id", "file_name", "file_path"]

        collection = self._get_collection()
        results = collection.search(
            data=[query_vector],
            anns_field="text_vector",
            param={"metric_type": "COSINE", "params": {"ef": 128}},
            limit=top_k,
            output_fields=output_fields,
        )

        return self._parse_results(results)

    def search_clip_text(
        self,
        query_vector: List[float],
        top_k: int = 5,
    ) -> List[SearchResult]:
        """Search by CLIP text vector."""
        collection = self._get_collection()
        results = collection.search(
            data=[query_vector],
            anns_field="clip_text_vector",
            param={"metric_type": "COSINE", "params": {"ef": 128}},
            limit=top_k,
            output_fields=["text", "file_id", "file_name", "file_path"],
        )
        return self._parse_results(results)

    def search_clip_image(
        self,
        query_vector: List[float],
        top_k: int = 5,
    ) -> List[SearchResult]:
        """Search by CLIP image vector."""
        collection = self._get_collection()
        results = collection.search(
            data=[query_vector],
            anns_field="clip_image_vector",
            param={"metric_type": "COSINE", "params": {"ef": 128}},
            limit=top_k,
            output_fields=["text", "file_id", "file_name", "file_path"],
        )
        return self._parse_results(results)

    def search_hybrid(
        self,
        clip_text_query: List[float],
        clip_image_query: Optional[List[float]] = None,
        top_k: int = 5,
    ) -> List[SearchResult]:
        """Hybrid search combining text and image vectors."""
        text_results = self.search_clip_text(clip_text_query, top_k * 2)

        if clip_image_query:
            image_results = self.search_clip_image(clip_image_query, top_k * 2)
            # Fuse results with weighted scores
            return self._fuse_results(text_results, image_results, top_k)

        return text_results[:top_k]

    def _fuse_results(
        self,
        text_results: List[SearchResult],
        image_results: List[SearchResult],
        top_k: int,
    ) -> List[SearchResult]:
        """Fuse text and image search results."""
        score_map = {}
        for r in text_results:
            key = (r.file_id, r.text[:50])
            score_map[key] = {"result": r, "text_score": 1 - r.score, "image_score": 0}

        for r in image_results:
            key = (r.file_id, r.text[:50])
            if key in score_map:
                score_map[key]["image_score"] = 1 - r.score
            else:
                score_map[key] = {"result": r, "text_score": 0, "image_score": 1 - r.score}

        fused = []
        for key, data in score_map.items():
            r = data["result"]
            fused_score = 0.6 * data["text_score"] + 0.4 * data["image_score"]
            fused.append(SearchResult(
                text=r.text,
                file_id=r.file_id,
                file_name=r.file_name,
                file_path=r.file_path,
                score=1 - fused_score,
                image_paths=r.image_paths,
            ))

        fused.sort(key=lambda x: x.score, reverse=True)
        return fused[:top_k]

    def _parse_results(self, results) -> List[SearchResult]:
        """Parse Milvus search results."""
        search_results = []
        if not results or not results[0]:
            return search_results

        for hit in results[0]:
            search_results.append(SearchResult(
                text=hit.entity.get("text", ""),
                file_id=hit.entity.get("file_id", 0),
                file_name=hit.entity.get("file_name", ""),
                file_path=hit.entity.get("file_path", ""),
                score=hit.distance,
            ))
        return search_results


# Global instance
_milvus_client: Optional[MilvusClient] = None


def get_milvus_client() -> MilvusClient:
    """Get global Milvus client instance."""
    global _milvus_client
    if _milvus_client is None:
        _milvus_client = MilvusClient()
    return _milvus_client