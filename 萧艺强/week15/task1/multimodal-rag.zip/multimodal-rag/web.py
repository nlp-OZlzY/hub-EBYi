"""Main Streamlit web application."""

import streamlit as st

# Page navigation
st.set_page_config(
    page_title="多模态RAG系统",
    page_icon="🔍",
    layout="wide",
)

PAGES = {
    "📁 文件上传": "streamlit_setup.web_page_upload",
    "💬 图文问答": "streamlit_setup.web_page_chat",
}


def main():
    """Main entry point."""
    st.title("🔍 多模态RAG知识库问答系统")

    # Sidebar navigation
    st.sidebar.title("导航")
    selection = st.sidebar.radio("选择功能", list(PAGES.keys()))

    # Import and run selected page
    if selection == "📁 文件上传":
        from streamlit_setup.web_page_upload import render_upload_page
        render_upload_page()
    elif selection == "💬 图文问答":
        from streamlit_setup.web_page_chat import render_chat_page
        render_chat_page()


if __name__ == "__main__":
    main()