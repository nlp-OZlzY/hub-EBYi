#!/usr/bin/env python
"""启动离线解析 Worker。"""
import sys
import asyncio
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))

from worker.parse_document import run_worker

if __name__ == "__main__":
    asyncio.run(run_worker())
