from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.database import get_db
from app.core.config import settings
from app.models.document import Document, KnowledgeBase, Chunk, ImageRecord
from app.schemas.chat import ChatRequest, ChatResponse, RetrievedItem
from app.services.embedding import EmbeddingService
from app.services.retrieval import RetrievalService
from app.services.qa import QAService

router = APIRouter(prefix="/chat", tags=["chat"])


@router.post("", response_model=ChatResponse)
async def chat(
    req: ChatRequest,
    db: AsyncSession = Depends(get_db),
):
    """
    多模态 RAG 问答流程：
    1. 文本检索：用户提问 → bge embedding → Milvus 文本检索
    2. 图像检索：用户提问 → CLIP embedding → Milvus 图像检索
    3. 多模态问答：Qwen-VL 综合图文信息生成答案
    """
    # 验证知识库存在
    kb = await db.get(KnowledgeBase, req.knowledge_base_id)
    if not kb:
        raise HTTPException(status_code=404, detail="知识库不存在")

    # 检查是否有可用的文档
    docs_result = await db.execute(
        select(Document).where(
            Document.knowledge_base_id == req.knowledge_base_id,
            Document.parse_status == "completed",
        )
    )
    docs = docs_result.scalars().all()
    if not docs:
        raise HTTPException(status_code=400, detail="该知识库暂无已解析的文档")

    # 初始化服务
    embedding_svc = EmbeddingService(settings.clip_model, settings.bge_model)
    retrieval_svc = RetrievalService(
        settings.milvus_host,
        settings.milvus_port,
        settings.milvus_collection,
    )
    qa_svc = QAService(settings.qwen_vl_model)

    # 1. 文本检索
    query_vec = embedding_svc.encode_text(req.question)
    text_results = retrieval_svc.search_text(query_vec, top_k=req.top_k)

    # 2. 图像检索 (CLIP)
    image_results = retrieval_svc.search_image(query_vec, top_k=req.top_k)

    # 3. 构建检索上下文
    retrieved_texts = []
    for tr in text_results:
        doc = await db.get(Document, tr["doc_id"])
        retrieved_texts.append(
            {
                "text": tr["text"],
                "page_number": tr["page_number"],
                "doc_name": doc.filename if doc else "unknown",
            }
        )

    retrieved_images = []
    for ir in image_results:
        doc = await db.get(Document, ir["doc_id"])
        retrieved_images.append(
            {
                "image_path": ir["image_path"],
                "page_number": ir["page_number"],
                "doc_name": doc.filename if doc else "unknown",
            }
        )

    # 4. Qwen-VL 生成答案
    answer = qa_svc.answer(
        question=req.question,
        retrieved_texts=retrieved_texts,
        retrieved_images=retrieved_images,
    )

    # 5. 组装来源信息
    sources = []
    for tr in text_results:
        doc = await db.get(Document, tr["doc_id"])
        sources.append(
            RetrievedItem(
                source="text",
                content=tr["text"][:200],  # 截断避免过长
                document_name=doc.filename if doc else "unknown",
                page_number=tr["page_number"],
                score=tr["score"],
            )
        )
    for ir in image_results:
        doc = await db.get(Document, ir["doc_id"])
        sources.append(
            RetrievedItem(
                source="image",
                file_path=ir["image_path"],
                document_name=doc.filename if doc else "unknown",
                page_number=ir["page_number"],
                score=ir["score"],
            )
        )

    return ChatResponse(answer=answer, sources=sources)
