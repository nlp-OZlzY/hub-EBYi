import hashlib
from pathlib import Path
from typing import Optional

from fastapi import APIRouter, UploadFile, File, Form, Depends, HTTPException
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.database import get_db
from app.core.config import settings
from app.models.document import Document, KnowledgeBase, Chunk, ImageRecord
from app.schemas.document import (
    KnowledgeBaseCreate,
    KnowledgeBaseResponse,
    DocumentUploadResponse,
    DocumentStatusResponse,
)
from app.services.pdf_parser import PDFParser, chunk_markdown
from app.services.embedding import EmbeddingService
from app.services.retrieval import RetrievalService

router = APIRouter(prefix="/document", tags=["document"])


# ============ Knowledge Base ============


@router.post("/knowledge_base", response_model=KnowledgeBaseResponse)
async def create_knowledge_base(
    kb: KnowledgeBaseCreate,
    db: AsyncSession = Depends(get_db),
):
    """创建知识库。"""
    existing = await db.execute(
        select(KnowledgeBase).where(KnowledgeBase.name == kb.name)
    )
    if existing.scalar_one_or_none():
        raise HTTPException(status_code=409, detail="知识库名称已存在")

    db_kb = KnowledgeBase(name=kb.name, description=kb.description)
    db.add(db_kb)
    await db.commit()
    await db.refresh(db_kb)
    return db_kb


@router.get("/knowledge_base", response_model=list[KnowledgeBaseResponse])
async def list_knowledge_bases(db: AsyncSession = Depends(get_db)):
    result = await db.execute(select(KnowledgeBase).order_by(KnowledgeBase.id))
    return result.scalars().all()


# ============ Document Upload ============


def _compute_md5(file_content: bytes) -> str:
    return hashlib.md5(file_content).hexdigest()


@router.post("/upload", response_model=DocumentUploadResponse)
async def upload_document(
    knowledge_base_id: int = Form(...),
    file: UploadFile = File(...),
    db: AsyncSession = Depends(get_db),
):
    """
    上传 PDF 文档到指定知识库。
    文档存入本地后，创建 Document 记录（状态为 pending）。
    实际解析由 worker 调用 /document/parse/{document_id} 触发。
    """
    kb = await db.get(KnowledgeBase, knowledge_base_id)
    if not kb:
        raise HTTPException(status_code=404, detail="知识库不存在")

    if not file.filename.endswith(".pdf"):
        raise HTTPException(status_code=400, detail="仅支持 PDF 文件")

    content = await file.read()
    md5 = _compute_md5(content)

    # 避免重复上传
    existing = await db.execute(
        select(Document).where(
            Document.knowledge_base_id == knowledge_base_id,
            Document.md5 == md5,
        )
    )
    if existing.scalar_one_or_none():
        raise HTTPException(status_code=409, detail="该文件已上传")

    doc_dir = settings.documents_dir / str(knowledge_base_id)
    doc_dir.mkdir(parents=True, exist_ok=True)
    file_path = doc_dir / f"{md5}.pdf"
    with open(file_path, "wb") as f:
        f.write(content)

    doc = Document(
        knowledge_base_id=knowledge_base_id,
        filename=file.filename,
        file_path=str(file_path),
        md5=md5,
        parse_status="pending",
    )
    db.add(doc)
    await db.commit()
    await db.refresh(doc)

    # TODO: 发送 Kafka 消息通知 worker 开始解析
    # producer.send("pdf_parse_topic", {"document_id": doc.id})

    return DocumentUploadResponse(
        document_id=doc.id,
        filename=doc.filename,
        parse_status=doc.parse_status,
        message="文档上传成功，解析任务已提交",
    )


@router.get("/status/{document_id}", response_model=DocumentStatusResponse)
async def get_document_status(
    document_id: int,
    db: AsyncSession = Depends(get_db),
):
    doc = await db.get(Document, document_id)
    if not doc:
        raise HTTPException(status_code=404, detail="文档不存在")
    return doc


# ============ Trigger Parse (内部接口，worker 调用) ============


@router.post("/parse/{document_id}")
async def trigger_parse(
    document_id: int,
    db: AsyncSession = Depends(get_db),
):
    """
    Worker 调用此接口开始解析文档。
    1. 调用 MinerU 解析 PDF
    2. 切分 chunks，生成向量
    3. 存入 Milvus 和数据库
    """
    doc = await db.get(Document, document_id)
    if not doc:
        raise HTTPException(status_code=404, detail="文档不存在")

    doc.parse_status = "parsing"
    await db.commit()

    try:
        # 1. 解析 PDF
        parser = PDFParser(
            output_dir=settings.data_dir,
            images_dir=settings.images_dir,
            markdown_dir=settings.markdown_dir,
        )
        parse_result = parser.parse(Path(doc.file_path), document_id)

        doc.markdown_path = parse_result["markdown_path"]
        doc.page_count = parse_result["page_count"]

        # 2. 读取 markdown 元数据
        import json

        meta_path = Path(doc.markdown_path).parent / f"{Path(doc.markdown_path).stem}_meta.json"
        with open(meta_path) as f:
            meta = json.load(f)
        page_metas = meta["pages"]

        # 3. 切分 chunks
        with open(doc.markdown_path) as f:
            full_md = f.read()
        chunks = chunk_markdown(full_md, page_metas, settings.chunk_size, settings.chunk_overlap)

        # 4. 初始化 embedding / retrieval 服务
        embedding_svc = EmbeddingService(settings.clip_model, settings.bge_model)
        retrieval_svc = RetrievalService(
            settings.milvus_host,
            settings.milvus_port,
            settings.milvus_collection,
        )

        # 5. 向量化文本 chunks 并存储
        vectors = []
        texts = []
        page_nums = []
        doc_ids = []
        for chunk in chunks:
            vec = embedding_svc.encode_text(chunk["content"])
            vectors.append(vec)
            texts.append(chunk["content"])
            page_nums.append(chunk["page_number"])
            doc_ids.append(document_id)

            db_chunk = Chunk(
                document_id=document_id,
                content=chunk["content"],
                page_number=chunk["page_number"],
                chunk_index=len(texts) - 1,
            )
            db.add(db_chunk)

        vector_ids = retrieval_svc.insert_text_vectors(vectors, texts, page_nums, doc_ids)

        # 回写 vector_id
        result = await db.execute(select(Chunk).where(Chunk.document_id == document_id))
        db_chunks = result.scalars().all()
        for db_chunk, vid in zip(db_chunks, vector_ids):
            db_chunk.vector_id = vid

        # 6. 向量化图片并存储
        image_files = parse_result["image_files"]
        if image_files:
            img_vectors = []
            img_paths = []
            img_pages = []
            img_doc_ids = []
            for img_path in image_files:
                vec = embedding_svc.encode_image(Path(img_path))
                img_vectors.append(vec)
                img_paths.append(img_path)
                # 从文件名中提取页码 (格式: {doc_id}_{page}_{idx}.png)
                page_num = int(Path(img_path).stem.split("_")[1])
                img_pages.append(page_num)
                img_doc_ids.append(document_id)

                img_record = ImageRecord(
                    document_id=document_id,
                    page_number=page_num,
                    file_path=img_path,
                )
                db.add(img_record)

            img_vector_ids = retrieval_svc.insert_image_vectors(
                img_vectors, img_paths, img_pages, img_doc_ids
            )

            result = await db.execute(
                select(ImageRecord).where(ImageRecord.document_id == document_id)
            )
            db_images = result.scalars().all()
            for db_img, vid in zip(db_images, img_vector_ids):
                db_img.vector_id = vid

        doc.parse_status = "completed"
        await db.commit()

        return {"message": "解析完成", "chunk_count": len(chunks), "image_count": len(image_files)}

    except Exception as e:
        doc.parse_status = "failed"
        await db.commit()
        raise HTTPException(status_code=500, detail=f"解析失败: {str(e)}")
