import os
from pathlib import Path
from functools import lru_cache

import yaml
from pydantic import Field
from pydantic_settings import BaseSettings


BASE_DIR = Path(__file__).resolve().parent.parent.parent


def load_config() -> dict:
    config_path = BASE_DIR / "config.yaml"
    if config_path.exists():
        with open(config_path) as f:
            return yaml.safe_load(f)
    return {}


class Settings(BaseSettings):
    # Database
    database_url: str = Field(default="sqlite+aiosqlite:///./data/mmrag.db")

    # Milvus
    milvus_host: str = Field(default="localhost")
    milvus_port: int = Field(default=19530)
    milvus_collection: str = Field(default="multimodal_rag")

    # Storage paths
    data_dir: Path = Field(default=BASE_DIR / "data")
    documents_dir: Path = Field(default=BASE_DIR / "data" / "documents")
    images_dir: Path = Field(default=BASE_DIR / "data" / "images")
    markdown_dir: Path = Field(default=BASE_DIR / "data" / "markdown")

    # Models
    clip_model: str = Field(default="openai/clip-vit-base-patch32")
    bge_model: str = Field(default="sentence-transformers/bge-m3")
    qwen_vl_model: str = Field(default="Qwen/Qwen2-VL-7B-Instruct")

    # MinerU
    mineru_model: str = Field(default="mindware/MinerU-7B")
    chunk_size: int = Field(default=512)
    chunk_overlap: int = Field(default=50)

    class Config:
        env_file = ".env"
        extra = "allow"


@lru_cache
def get_settings() -> Settings:
    return Settings()


settings = get_settings()
