from pathlib import Path
from typing import Optional

import torch
from PIL import Image
from transformers import CLIPProcessor, CLIPModel, AutoTokenizer, AutoModel


class EmbeddingService:
    def __init__(self, clip_model: str, bge_model: str, device: Optional[str] = None):
        self.device = device or ("cuda" if torch.cuda.is_available() else "cpu")

        # CLIP for image-text retrieval
        self.clip_model = CLIPModel.from_pretrained(clip_model).to(self.device)
        self.clip_processor = CLIPProcessor.from_pretrained(clip_model)

        # BGE for text embedding
        self.bge_tokenizer = AutoTokenizer.from_pretrained(bge_model)
        self.bge_model = AutoModel.from_pretrained(bge_model).to(self.device)

    def encode_text(self, text: str) -> list[float]:
        """使用 BGE 将文本编码为向量。"""
        inputs = self.bge_tokenizer(
            text, return_tensors="pt", padding=True, truncation=True, max_length=512
        ).to(self.device)
        with torch.no_grad():
            outputs = self.bge_model(**inputs)
            # mean pooling
            embedding = outputs.last_hidden_state.mean(dim=1).squeeze().cpu().numpy()
        return embedding.tolist()

    def encode_image(self, image_path: Path) -> list[float]:
        """使用 CLIP 将图片编码为向量。"""
        image = Image.open(image_path).convert("RGB")
        inputs = self.clip_processor(text=[""], images=image, return_tensors="pt", padding=True).to(self.device)
        with torch.no_grad():
            image_features = self.clip_model.get_image_features(**inputs)
            embedding = image_features.squeeze().cpu().numpy()
        return embedding.tolist()

    def encode_image_for_retrieval(self, image_path: Path, query: str) -> list[float]:
        """使用 CLIP 做图文匹配时的双塔编码（图片侧）。"""
        image = Image.open(image_path).convert("RGB")
        inputs = self.clip_processor(text=[query], images=image, return_tensors="pt", padding=True).to(self.device)
        with torch.no_grad():
            image_features = self.clip_model.get_image_features(**inputs)
            embedding = image_features.squeeze().cpu().numpy()
        return embedding.tolist()
