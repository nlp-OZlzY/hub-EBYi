from typing import Optional

from pymilvus import MilvusClient, Collection

from app.core.config import settings


class RetrievalService:
    def __init__(self, milvus_host: str, milvus_port: int, collection_name: str):
        self.client = MilvusClient(uri=f"http://{milvus_host}:{milvus_port}")
        self.collection_name = collection_name
        self._ensure_collection()

    def _ensure_collection(self):
        if self.client.has_collection(self.collection_name):
            return
        self.client.create_collection(
            collection_name=self.collection_name,
            dimension=512,  # CLIP/BGE output dimension
            metric_type="IP",
            description="multimodal RAG vectors",
        )

    def insert_text_vectors(self, vectors: list[list[float]], texts: list[str], page_numbers: list[int], doc_ids: list[int]) -> list[int]:
        """插入文本向量，返回 vector_ids。"""
        from pymilvus import DataType
        import numpy as np

        # 使用 upsert 确保幂等性
        data = [
            [f"text_{i}" for i in range(len(vectors))],
            [float(np.linalg.norm(v)) for v in vectors],  # norm
            texts,
            page_numbers,
            doc_ids,
            vectors,
        ]
        # Milvus Client 1.x 接口
        self.client.insert(
            collection_name=self.collection_name,
            data={
                "id": [f"text_{i}" for i in range(len(vectors))],
                "vector": vectors,
                "text": texts,
                "page_number": page_numbers,
                "doc_id": doc_ids,
                "type": ["text"] * len(vectors),
            },
        )
        self.client.flush()
        return list(range(len(vectors)))

    def insert_image_vectors(
        self, vectors: list[list[float]], image_paths: list[str], page_numbers: list[int], doc_ids: list[int]
    ) -> list[int]:
        """插入图片向量，返回 vector_ids。"""
        data = {
            "id": [f"image_{i}" for i in range(len(vectors))],
            "vector": vectors,
            "image_path": image_paths,
            "page_number": page_numbers,
            "doc_id": doc_ids,
            "type": ["image"] * len(vectors),
        }
        self.client.insert(collection_name=self.collection_name, data=data)
        self.client.flush()
        return list(range(len(vectors)))

    def search_text(self, query_vector: list[float], top_k: int = 5) -> list[dict]:
        """文本向量相似度检索。"""
        results = self.client.search(
            collection_name=self.collection_name,
            data=[query_vector],
            filter='type == "text"',
            limit=top_k,
            output_fields=["text", "page_number", "doc_id"],
        )
        return [
            {
                "score": r["distance"],
                "text": r["entity"]["text"],
                "page_number": r["entity"]["page_number"],
                "doc_id": r["entity"]["doc_id"],
            }
            for r in results[0]
        ]

    def search_image(self, query_vector: list[float], top_k: int = 5) -> list[dict]:
        """图片向量相似度检索。"""
        results = self.client.search(
            collection_name=self.collection_name,
            data=[query_vector],
            filter='type == "image"',
            limit=top_k,
            output_fields=["image_path", "page_number", "doc_id"],
        )
        return [
            {
                "score": r["distance"],
                "image_path": r["entity"]["image_path"],
                "page_number": r["entity"]["page_number"],
                "doc_id": r["entity"]["doc_id"],
            }
            for r in results[0]
        ]
