import hashlib
import json
import re
from pathlib import Path
from typing import Optional

from mineru import MagicPDF


class PDFParser:
    def __init__(self, output_dir: Path, images_dir: Path, markdown_dir: Path):
        self.output_dir = Path(output_dir)
        self.images_dir = Path(images_dir)
        self.markdown_dir = Path(markdown_dir)
        self.images_dir.mkdir(parents=True, exist_ok=True)
        self.markdown_dir.mkdir(parents=True, exist_ok=True)

    def compute_md5(self, file_path: Path) -> str:
        h = hashlib.md5()
        with open(file_path, "rb") as f:
            for chunk in iter(lambda: f.read(8192), b""):
                h.update(chunk)
        return h.hexdigest()

    def parse(
        self,
        pdf_path: Path,
        document_id: int,
    ) -> dict:
        """
        使用 MinerU 解析 PDF，返回元信息。
        解析产物:
          - markdown 文件
          - 图片文件
          - 页面级 JSON 元数据
        """
        md5 = self.compute_md5(pdf_path)
        doc_images_dir = self.images_dir / str(document_id)
        doc_markdown_dir = self.markdown_dir / str(document_id)
        doc_images_dir.mkdir(parents=True, exist_ok=True)
        doc_markdown_dir.mkdir(parents=True, exist_ok=True)

        result = MagicPDF.parse(pdf_path, str(doc_images_dir), str(doc_markdown_dir))

        markdown_path = doc_markdown_dir / f"{md5}.md"

        # 提取图片列表
        image_files = sorted(doc_images_dir.glob("*.png")) + sorted(
            doc_images_dir.glob("*.jpg")
        )

        # 合并所有页面的 markdown 内容
        combined_md = ""
        page_metas = []
        for page_idx, page_result in enumerate(result):
            page_md = page_result.get("markdown", "")
            combined_md += f"\n\n<!-- page {page_idx + 1} -->\n\n{page_md}"
            page_metas.append(
                {
                    "page": page_idx + 1,
                    "markdown": page_md,
                    "images": [
                        str(img.name) for img in page_result.get("images", [])
                    ],
                }
            )

        with open(markdown_path, "w", encoding="utf-8") as f:
            f.write(combined_md.strip())

        meta_path = doc_markdown_dir / f"{md5}_meta.json"
        with open(meta_path, "w", encoding="utf-8") as f:
            json.dump(
                {
                    "md5": md5,
                    "pages": page_metas,
                    "image_count": len(image_files),
                },
                f,
                ensure_ascii=False,
                indent=2,
            )

        return {
            "markdown_path": str(markdown_path),
            "meta_path": str(meta_path),
            "page_count": len(result),
            "image_files": [str(f) for f in image_files],
        }


def chunk_markdown(
    markdown_content: str,
    page_metas: list,
    chunk_size: int = 512,
    overlap: int = 50,
) -> list[dict]:
    """
    按段落切分 markdown 内容，保持页码信息。
    返回: [{"content": str, "page_number": int}, ...]
    """
    chunks = []
    # 按页分割，每页单独处理
    for meta in page_metas:
        page_text = meta["markdown"]
        page_num = meta["page"]
        if not page_text.strip():
            continue

        paragraphs = re.split(r"\n{2,}", page_text)
        current = ""
        for para in paragraphs:
            para = para.strip()
            if not para:
                continue
            if len(current) + len(para) <= chunk_size:
                current += "\n" + para
            else:
                if current.strip():
                    chunks.append(
                        {"content": current.strip(), "page_number": page_num}
                    )
                # overlap: 保留前 overlap 个字符作为下一段的起点
                current = current[-overlap:] + "\n" + para if overlap > 0 else para

        if current.strip():
            chunks.append({"content": current.strip(), "page_number": page_num})

    return chunks
