from typing import Optional

from qwen_vl_utils import qwen_vl_utils


class QAService:
    def __init__(self, model_name: str):
        self.model_name = model_name
        self.model = None
        self.processor = None

    def _load_model(self):
        if self.model is None:
            from transformers import Qwen2VLForConditionalGeneration, AutoProcessor
            import torch

            self.model = Qwen2VLForConditionalGeneration.from_pretrained(
                self.model_name,
                torch_dtype=torch.bfloat16,
                device_map="auto",
            )
            self.processor = AutoProcessor.from_pretrained(self.model_name)

    def answer(
        self,
        question: str,
        retrieved_texts: list[dict],
        retrieved_images: list[dict],
        max_new_tokens: int = 512,
    ) -> str:
        """
        使用 Qwen-VL 进行多模态问答。
        retrieved_texts: [{"text": str, "page_number": int, "doc_name": str}, ...]
        retrieved_images: [{"image_path": str, "page_number": int, "doc_name": str}, ...]
        """
        self._load_model()

        # 构建 prompt
        context_parts = []
        for t in retrieved_texts:
            context_parts.append(
                f"[文档: {t['doc_name']} | 页码: {t['page_number']}]\n{t['text']}"
            )
        for img in retrieved_images:
            context_parts.append(
                f"[文档: {img['doc_name']} | 页码: {img['page_number']} | 图片: {img['image_path']}]"
            )

        context = "\n\n".join(context_parts)
        prompt = (
            f"你是一个专业的知识库问答助手。请根据以下参考资料回答用户问题。\n"
            f"如果参考资料中有相关信息，请基于这些内容回答，并注明信息来源。\n"
            f"如果参考资料中没有相关信息，请如实说明你无法回答。\n\n"
            f"【参考资料】\n{context}\n\n"
            f"【用户问题】\n{question}\n\n"
            f"【回答】（请注明信息来源）："
        )

        # 收集图片路径
        image_paths = [img["image_path"] for img in retrieved_images if img.get("image_path")]

        # 构建 messages
        content = [{"type": "text", "text": prompt}]
        for img_path in image_paths:
            content.append({"type": "image", "image": f"file://{img_path}"})

        messages = [
            {
                "role": "user",
                "content": content,
            }
        ]

        text = self.processor.apply_chat_template(messages, tokenize=False, add_generation_prompt=True)
        image_inputs, video_inputs = qwen_vl_utils.process_vision_info(messages)

        inputs = self.processor(
            text=[text],
            images=image_inputs,
            videos=video_inputs,
            return_tensors="pt",
            padding=True,
        ).to("cuda")

        with self.no_truncation():
            generated_ids = self.model.generate(
                **inputs,
                max_new_tokens=max_new_tokens,
            )
        generated_ids_trimmed = [
            out_ids[len(in_ids) :] for in_ids, out_ids in zip(inputs.input_ids, generated_ids)
        ]
        answer = self.processor.batch_decode(
            generated_ids_trimmed, skip_special_tokens=True, clean_up_tokenization_spaces=False
        )[0]

        return answer

    def no_truncation(self):
        """Context manager to disable token truncation for generation."""
        import contextlib
        return contextlib.nullcontext()
