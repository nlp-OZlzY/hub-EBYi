from datetime import datetime
from typing import Optional

from pydantic import BaseModel, Field


class KnowledgeBaseCreate(BaseModel):
    name: str = Field(..., max_length=255)
    description: Optional[str] = None


class KnowledgeBaseResponse(BaseModel):
    id: int
    name: str
    description: Optional[str]
    created_at: datetime

    class Config:
        from_attributes = True


class DocumentUploadResponse(BaseModel):
    document_id: int
    filename: str
    parse_status: str
    message: str


class DocumentStatusResponse(BaseModel):
    id: int
    filename: str
    parse_status: str
    page_count: Optional[int]
    markdown_path: Optional[str]


class ChunkResponse(BaseModel):
    id: int
    content: str
    page_number: Optional[int]
    chunk_index: int

    class Config:
        from_attributes = True
