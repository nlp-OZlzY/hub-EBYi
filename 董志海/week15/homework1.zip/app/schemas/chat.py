from typing import Optional

from pydantic import BaseModel, Field


class ChatRequest(BaseModel):
    knowledge_base_id: int
    question: str = Field(..., min_length=1, max_length=2000)
    top_k: int = Field(default=5, ge=1, le=20)


class RetrievedItem(BaseModel):
    source: str  # "text" or "image"
    content: Optional[str] = None  # text content or image description
    file_path: Optional[str] = None  # image file path for VL model
    document_name: str
    page_number: Optional[int] = None
    score: float


class ChatResponse(BaseModel):
    answer: str
    sources: list[RetrievedItem]
