# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Project Overview

Multimodal RAG system for PDF document question-answering. The system parses PDF documents (text + images), stores embeddings in Milvus vector database, and uses Qwen-VL for multimodal QA.

## Architecture

```
upload API → Document record (pending) → Worker polls → MinerU parses PDF
                                                         ↓
                                               chunks + images stored locally
                                               vectors stored in Milvus
                                                         ↓
chat API ← Qwen-VL ← CLIP/bge retrieval ← Milvus ←──────┘
```

## Running the Project

```bash
# 1. Install dependencies
pip install -r requirements.txt

# 2. Copy and configure environment
cp .env.example .env
# Edit .env with your model paths / Milvus host

# 3. Start API server
python run_api.py

# 4. Start worker (separate terminal)
python run_worker.py
```

## Key Modules

| File | Purpose |
|------|---------|
| `app/services/pdf_parser.py` | MinerU PDF → markdown + images, chunking |
| `app/services/embedding.py` | CLIP (image) + BGE (text) embedding |
| `app/services/retrieval.py` | Milvus vector storage and search |
| `app/services/qa.py` | Qwen-VL multimodal answer generation |
| `app/api/routes/document.py` | Upload + parse trigger API |
| `app/api/routes/chat.py` | RAG chat API |
| `worker/parse_document.py` | Offline document parsing worker |

## Data Model

- **KnowledgeBase**: top-level container
- **Document**: PDF file + parse status
- **Chunk**: text chunk with Milvus vector_id
- **ImageRecord**: extracted image with CLIP vector_id

## Design Decisions

- MinerU PDF parsing runs offline via worker (GPU-intensive, ~1min/file)
- Worker currently polls DB for pending documents; swap for Kafka consumer in production
- All files stored locally (`./data/documents`, `./data/images`, `./data/markdown`)
- SQLite for metadata, Milvus for vectors
- Answers must cite sources (PDF name, page number)

## Evaluation

- Page match (0.25) + filename match (0.25) + answer Jaccard similarity (0.5)
