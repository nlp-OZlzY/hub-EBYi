"""
离线文档解析 Worker。

消费 Kafka topic: pdf_parse_topic
消息格式: {"document_id": int}

处理流程:
1. 从数据库读取 Document 记录
2. 调用 MinerU 解析 PDF
3. 切分 chunk，生成向量
4. 存入 Milvus + SQLite
"""

import asyncio
import json
import sys
import os
from pathlib import Path

# 添加项目根目录到 Python 路径
sys.path.insert(0, str(Path(__file__).parent.parent))

from app.core.config import settings
from app.core.database import async_session_maker, init_db
from app.models.document import Document
from app.services.pdf_parser import PDFParser, chunk_markdown
from app.services.embedding import EmbeddingService
from app.services.retrieval import RetrievalService


async def process_document(document_id: int):
    """处理单个文档解析任务。"""
    async with async_session_maker() as db:
        from sqlalchemy import select

        doc = await db.get(Document, document_id)
        if not doc:
            print(f"[Worker] Document {document_id} not found, skip.")
            return

        print(f"[Worker] Start parsing document {document_id}: {doc.filename}")
        doc.parse_status = "parsing"
        await db.commit()

        try:
            # 1. PDF 解析
            parser = PDFParser(
                output_dir=settings.data_dir,
                images_dir=settings.images_dir,
                markdown_dir=settings.markdown_dir,
            )
            parse_result = parser.parse(Path(doc.file_path), document_id)
            doc.markdown_path = parse_result["markdown_path"]
            doc.page_count = parse_result["page_count"]
            await db.commit()

            # 2. 读取元数据
            meta_path = Path(doc.markdown_path).parent / f"{Path(doc.markdown_path).stem}_meta.json"
            with open(meta_path) as f:
                meta = json.load(f)
            page_metas = meta["pages"]

            # 3. 切分 chunks
            with open(doc.markdown_path) as f:
                full_md = f.read()
            chunks = chunk_markdown(full_md, page_metas, settings.chunk_size, settings.chunk_overlap)
            print(f"[Worker] Split into {len(chunks)} chunks")

            # 4. Embedding + Retrieval
            embedding_svc = EmbeddingService(settings.clip_model, settings.bge_model)
            retrieval_svc = RetrievalService(
                settings.milvus_host,
                settings.milvus_port,
                settings.milvus_collection,
            )

            # 文本向量
            vectors = []
            texts = []
            page_nums = []
            doc_ids = []
            for chunk in chunks:
                vec = embedding_svc.encode_text(chunk["content"])
                vectors.append(vec)
                texts.append(chunk["content"])
                page_nums.append(chunk["page_number"])
                doc_ids.append(document_id)

            vector_ids = retrieval_svc.insert_text_vectors(vectors, texts, page_nums, doc_ids)

            # 回写 Chunk vector_id
            from app.models.document import Chunk
            result = await db.execute(select(Chunk).where(Chunk.document_id == document_id))
            db_chunks = result.scalars().all()
            for db_chunk, vid in zip(db_chunks, vector_ids):
                db_chunk.vector_id = vid

            # 图片向量
            image_files = parse_result["image_files"]
            if image_files:
                img_vectors = []
                img_paths = []
                img_pages = []
                img_doc_ids = []
                from app.models.document import ImageRecord
                for img_path in image_files:
                    vec = embedding_svc.encode_image(Path(img_path))
                    img_vectors.append(vec)
                    img_paths.append(img_path)
                    page_num = int(Path(img_path).stem.split("_")[1])
                    img_pages.append(page_num)
                    img_doc_ids.append(document_id)
                    img_record = ImageRecord(
                        document_id=document_id,
                        page_number=page_num,
                        file_path=img_path,
                    )
                    db.add(img_record)

                img_vector_ids = retrieval_svc.insert_image_vectors(
                    img_vectors, img_paths, img_pages, img_doc_ids
                )
                result = await db.execute(
                    select(ImageRecord).where(ImageRecord.document_id == document_id)
                )
                db_images = result.scalars().all()
                for db_img, vid in zip(db_images, img_vector_ids):
                    db_img.vector_id = vid

            doc.parse_status = "completed"
            await db.commit()
            print(f"[Worker] Document {document_id} completed: {len(chunks)} chunks, {len(image_files)} images")

        except Exception as e:
            doc.parse_status = "failed"
            await db.commit()
            print(f"[Worker] Document {document_id} failed: {e}")
            raise


async def run_worker():
    """
    Worker 主循环。

    生产环境中替换为真实的 Kafka Consumer:
    from kafka import KafkaConsumer
    consumer = KafkaConsumer('pdf_parse_topic', bootstrap_servers=['localhost:9092'])
    for msg in consumer:
        data = json.loads(msg.value)
        await process_document(data['document_id'])

    目前为演示模式: 轮询数据库中 pending 状态的文档。
    """
    await init_db()
    print("[Worker] Started, polling for pending documents...")

    while True:
        async with async_session_maker() as db:
            from sqlalchemy import select

            result = await db.execute(
                select(Document).where(Document.parse_status == "pending").limit(1)
            )
            pending = result.scalar_one_or_none()

        if pending:
            await process_document(pending.id)
        else:
            await asyncio.sleep(5)


if __name__ == "__main__":
    asyncio.run(run_worker())
