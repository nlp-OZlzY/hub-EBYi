import pytest
from app.services.pdf_parser import chunk_markdown


def test_chunk_markdown_basic():
    """测试 markdown 文本切分。"""
    page_metas = [
        {"page": 1, "markdown": "这是第一段内容。\n\n这是第二段内容。", "images": []},
        {"page": 2, "markdown": "第二页的内容。", "images": []},
    ]
    chunks = chunk_markdown("第一页内容", page_metas, chunk_size=10, overlap=2)
    assert len(chunks) > 0
    assert all("content" in c and "page_number" in c for c in chunks)


def test_chunk_markdown_empty():
    """测试空内容的处理。"""
    chunks = chunk_markdown("", [], chunk_size=512)
    assert chunks == []
